# Legato — système de design (version finale)

Ce document décrit **toutes** les règles visuelles. Les captures du dossier `ecrans/png/` en sont l'application exacte. En cas de doute, **la capture fait foi**.

Les valeurs exactes (couleurs, dégradés, polices) sont dans `tokens.css`.

---

## 1. Principes

1. **Fond crème partout** (`#F7F4EF`), texte vert profond (`#2C4B40`).
2. **Un seul couple de couleurs par espace**, toujours le même (voir §3). Jamais de couleur d'un autre espace sur un écran.
3. **Un seul bouton plein par écran.** Les autres actions sont des boutons au trait ou des liens soulignés.
4. **Beaucoup d'air** : marges latérales de 28 px, peu d'éléments par écran.
5. **Chiffres simples** pour les listes numérotées : 1, 2, 3. Jamais de « i. », « ii. ».
6. **Aucun émoji, aucun pictogramme décoratif.** Seules icônes : barre de navigation, flèches (← → ↗ ›), micro, coche, plus.
7. **Pas de mot isolé** en fin de ligne dans les titres : `text-wrap: balance` sur tous les titres.
8. Tout est **mobile d'abord**, largeur de référence 390 px.

---

## 2. Typographie

| Usage | Police | Taille | Détails |
|---|---|---|---|
| Titre de page | Instrument Serif | 34–38 px | interligne 1,1 ; la fin du titre en *italique* dans la couleur d'accent de l'espace |
| Titre de ligne | Instrument Serif | 21 px | interligne 1,15 |
| Intitulé de section | Instrument Serif italique | 17 px | suivi d'un tiret long : « Cette semaine — » |
| Texte courant | Instrument Sans | 14–15 px | interligne 1,55 |
| Texte secondaire | Instrument Sans | 13 px | couleur `#6F7F76` |
| Petites capitales | Space Mono | 10,5 px | majuscules, interlettrage 0,09 em |
| Grand chiffre | Instrument Serif | 56 px | ex. « 3/8 », « 14 » |

Polices Google Fonts : `Instrument Serif` (normal + italique), `Instrument Sans` (400, 500), `Space Mono` (400).

---

## 3. Couleurs par espace

| Espace | Bloc de mise en avant | Bouton principal (fond / texte) | Accent (italique des titres, chiffres) | Onglet actif |
|---|---|---|---|---|
| **Aujourd'hui** (+ espaces, compte, première ouverture) | bleu `#CFDBE8` | vert profond `#2C4B40` / menthe `#BFE3D2` | vert profond | crème |
| **Soutien** | lin `#F3EBE1` | bleu `#CFDBE8` / vert profond | vert profond | crème |
| **Démarches** | lin `#F3EBE1` | bleu `#CFDBE8` / vert profond | corail `#D9653F` (remplissages `#F4805A`) | crème |
| **Mémoire** | rose `#EBC7C4` | bordeaux `#7A2E2C` / rose | bordeaux | crème |
| **Communauté** | rose `#EBC7C4` | bordeaux `#7A2E2C` / rose | bordeaux | crème |
| **Besoin d'aide** | fond plein bordeaux | rose / bordeaux | rose | — (pas de barre) |
| **Mode nuit** (Aujourd'hui après 21 h) | `#1D342C` | menthe / vert profond | menthe | menthe |

Exceptions voulues :
- **Présence** (conversation) : bulles de Présence en menthe pâle `#E4EDE7`, bulles de l'utilisateur en bleu.
- **Mes documents** : bloc « Il manque » en bleu, bouton vert profond à texte bleu.

Interdits : orange clair / pêche, jaune, noir pur, plusieurs pastels côte à côte, boutons blancs sur fond coloré.

---

## 4. Trois types d'écrans

### 4.0 Écran d'entrée
Premier écran à l'ouverture (route `/`) : fond bleu `#D1DBE7`, symbole Legato en haut, nom LEGATO au centre (images dans `assets/`), un seul bouton au trait « Entrée » en bas. Sans barre de navigation ni « Besoin d'aide ».

### 4.1 Écran standard
- En-tête de 64 px avec filet en bas : à gauche le nom de l'espace (Instrument Serif 25 px) **ou** « ← Retour vers… » ; à droite toujours **« Besoin d'aide → »**.
- Barre de navigation flottante en bas (voir §6).

### 4.2 Questionnaire (première ouverture, créer un espace, fleurs, volontés, offrande…)
Un seul gabarit, sans barre de navigation :
1. barre d'étapes en haut (segments de 3 px, **sans libellés**) ;
2. titre (30 px) + explication ;
3. réponses = **cartes de réponse** identiques (§5), choix unique ou multiple ;
4. en bas : **bouton plein pleine largeur** (52 px), puis un **lien centré** (« Passer cette étape », « J'ai déjà un compte »…).

### 4.3 Page d'expérience (Respirer, Sons, Se poser, Bougie, Lanterne, exercice guidé)
- **Plein écran, sans barre de navigation, sans « Besoin d'aide »**.
- Fond = dégradé de l'espace : Soutien `--lg-grad-soutien` ou `--lg-grad-nuit`, Mémoire `--lg-grad-memoire`.
- En haut : « ← Retour » à gauche, « Fermer × » à droite.
- Contenu centré, un seul bouton en bas.

### 4.4 Mode nuit
Après 21 h, l'écran Aujourd'hui passe en mode nuit : fond `#243E35`, texte crème adouci, secondaire bleu, accent menthe, barre de navigation `#1D342C` avec un filet. **Aucune démarche n'est proposée le soir.**

---

## 5. Composants

| Composant | Spécification |
|---|---|
| **Ligne** | padding 18 px vertical, filet `--lg-line-1` en bas (sauf la dernière) ; titre serif 21 px + sous-titre 13 px ; chevron › à droite. Variante numérotée : chiffre serif 22 px dans la couleur d'accent, colonne de 30 px. |
| **Ligne flèche** | comme la ligne, avec « ↗ » à droite (liens vers une autre page ou une liste). |
| **Conseil numéroté** | chiffre serif 28 px + phrase serif 20 px, padding 20 px, filet entre chaque. |
| **Bloc** | aplat plein (couleur de bloc de l'espace), padding 24 px, sans arrondi ; commence par un intitulé italique « Pour aujourd'hui — », un titre serif 25 px, une ligne secondaire, puis le bouton. |
| **Bouton principal** | hauteur 46–52 px, rayon = moitié de la hauteur, couleurs selon l'espace (§3), texte 15 px. Un seul par écran. |
| **Bouton au trait** | hauteur 36 px, contour 1 px vert profond (bordeaux en Mémoire/Communauté), texte 13,5 px. |
| **Lien** | texte 13,5 px souligné (décalage 4 px). |
| **Fiche** | lignes « LIBELLÉ (petites capitales, colonne 112 px) / valeur (serif 19 px) », filets fins, filet plus marqué en haut et en bas. |
| **Colonnes à filets** | 2 ou 3 colonnes séparées par un filet vertical, libellé en petites capitales + valeur serif. |
| **En-tête partagé** | titre à gauche, grand chiffre à droite, séparés par un filet vertical (ex. Démarches 3/8, Écrire 14). |
| **Encadré** | contour 1 px vert profond, padding 18–20 px (espace ouvert, résultat principal). |
| **Carte de réponse** | contour 1 px `--lg-line-2`, padding 15×16 px, rond de 20 px à gauche ; sélectionnée : fond lin, contour 1,5 px de la couleur d'accent, point plein dans le rond. **Même composant pour choix unique et multiple.** |
| **Champ** | libellé en petites capitales, valeur serif 21 px, filet en dessous. |
| **Barre d'humeur** | barre de 14 px en dégradé du vert profond au bleu, curseur rond crème cerclé de vert profond ; « Très dur » à gauche, « Plutôt bien » à droite. |
| **Barre d'avancement** | barre arrondie de 56 px, fond lin, remplissage corail, chiffre « 3 / 8 » en crème dans le remplissage. |
| **Bulles de Présence** | Présence : fond menthe pâle, serif 18 px, à gauche. Vous : fond bleu, sans 14,5 px, à droite. Champ « Écrivez, ou parlez » souligné avec un bouton micro rond au trait. |

---

## 6. Navigation

- **5 onglets**, dans cet ordre : Aujourd'hui · Soutien · Démarches · Mémoire · Communauté.
- Barre flottante : `left/right 16px`, `bottom 20px`, hauteur 60 px, rayon 30 px, fond vert profond.
- Onglet actif : pastille crème avec icône + libellé ; onglets inactifs : icône seule, crème à 75 %.
- **« Besoin d'aide → »** est présent en haut à droite de **tous** les écrans standard et ouvre `/crisis`.
- Le monogramme rond en haut à gauche d'Aujourd'hui ouvre « Vos espaces ».
- Chaque espace (une personne disparue, un animal, un proche malade, des questions sur la mort) a sa propre page Aujourd'hui (`f-auj-*`).

---

## 7. Règles d'écriture

- Vouvoiement, phrases courtes, mots concrets. Élégant mais **toujours compréhensible** : aucune formule abstraite.
- Toujours dire **pourquoi** une proposition est faite (« parce que vous vous sentez triste ») et **combien de temps** elle prend.
- Les boutons disent exactement ce qu'ils font (« Commencer à écrire », « Envoyer au fleuriste »).
- Permission, jamais injonction (« si vous voulez », « vous pouvez »).
- L'IA est nommée clairement : « Présence · intelligence artificielle ».
- Le texte exact de chaque écran est dans `02-ECRANS.md`. Les noms, dates et chiffres sont des **exemples** à remplacer par les vraies données.

---

## 8. Accessibilité

- Zones cliquables d'au moins 44 × 44 px.
- Contraste du texte courant ≥ 4,5:1 (le corail sert aux titres et aux remplissages, jamais au texte de 13 px).
- Les pages d'expérience respectent `prefers-reduced-motion`.

---

## 9. À conserver de l'application actuelle

1. **L'animation florale d'ouverture** (`src/routes/index.tsx`, `public/intro.mp4`) : vidéo, vitesse et minutage inchangés. Seul l'état final change : nouveau logo (dossier `assets/`) et bouton « Entrer » de l'écran 001.
2. **Le jardin peint avec les parcelles** (`src/routes/care.garden.index.tsx`, `src/assets/garden-painted-v4.png`) : une parcelle par être aimé. Il reste la première page de l'onglet Mémoire ; seuls l'en-tête, les textes et les boutons suivent le nouveau système. Toucher une parcelle ouvre l'écran 080.

---

## 10. Fonctions : ce qui change

Le cœur de Legato ne change pas (soutien au jour le jour, démarches, mémoire, communauté, Présence). Mais **plusieurs fonctions changent** avec cette maquette : de nouvelles pages, de nouveaux parcours, des pages qui disparaissent ou se transforment.

**La maquette fait foi** : pour chaque écran, `02-ECRANS.md` indique ce qu'on peut toucher et ce qui se passe. Le code actuel n'est réutilisé que pour ce qui fait la même chose. Une fonction du code actuel absente de la maquette n'est jamais supprimée sans validation.
