# Legato — inventaire des écrans

Chaque écran : capture (`ecrans/png/`), maquette HTML cliquable (`ecrans/html/`), route dans le code, et **texte exact à reprendre**. Les prénoms, dates et chiffres sont des exemples : ils viennent des données de l'utilisateur.

Statut : **existe** = la route existe déjà, mais son contenu et ses fonctions peuvent changer : la maquette fait foi ; **à créer** = nouvelle route ou nouvel état.

## Tableau récapitulatif

| # | Écran | Espace | Route | Statut | Type |
|---|---|---|---|---|---|
| 000 | Couleurs par espace | Référence | `—` | — | Standard |
| 001 | Écran d'entrée | Entrée et première ouverture | `/` | existe | Écran d'entrée (fond bleu, logo, sans barre) |
| 002 | Bienvenue | Entrée et première ouverture | `/start` | existe | Questionnaire / entrée (sans barre) |
| 003 | Comment ça marche | Entrée et première ouverture | `/presentation` | existe | Questionnaire / entrée (sans barre) |
| 004 | Se connecter | Entrée et première ouverture | `/auth` | existe | Questionnaire / entrée (sans barre) |
| 005 | Une invitation | Entrée et première ouverture | `/invite/$token` | existe | Questionnaire / entrée (sans barre) |
| 006 | 1 · Pour qui | Entrée et première ouverture | `/onboarding · étape 1` | existe | Questionnaire / entrée (sans barre) |
| 007 | 2 · Son prénom | Entrée et première ouverture | `/onboarding · étape 2` | existe | Questionnaire / entrée (sans barre) |
| 008 | 3 · Démarches | Entrée et première ouverture | `/onboarding/practical` | existe | Questionnaire / entrée (sans barre) |
| 009 | 4 · Vos besoins | Entrée et première ouverture | `/onboarding/care` | existe | Questionnaire / entrée (sans barre) |
| 010 | C'est prêt | Entrée et première ouverture | `/onboarding · fin` | existe | Questionnaire / entrée (sans barre) |
| 011 | Aujourd'hui | Aujourd'hui | `/home` | à créer | Standard |
| 012 | Le soir (mode nuit) | Aujourd'hui | `/home après 21 h` | à créer | Standard · mode nuit |
| 013 | Comment allez-vous | Aujourd'hui | `/care/emotions (et /checkin)` | existe | Standard |
| 014 | C'est noté | Aujourd'hui | `/care/emotions · après enregistrement` | à créer | Standard |
| 015 | Les jours qui viennent | Aujourd'hui | `/agenda` | existe | Standard |
| 016 | Ajouter une date | Aujourd'hui | `/agenda/new` | à créer | Standard |
| 017 | Une date difficile | Aujourd'hui | `/care/dates` | existe | Standard |
| 018 | Besoin d'aide | Aujourd'hui | `/crisis` | existe | Plein écran bordeaux (sans barre) |
| 019 | Vos espaces | Aujourd'hui | `/space` | à créer | Standard |
| 020 | Créer un espace | Aujourd'hui | `/space/new` | à créer | Questionnaire / entrée (sans barre) |
| 021 | Réglages de l'espace | Aujourd'hui | `/space/settings` | à créer | Standard |
| 022 | Votre cercle | Aujourd'hui | `/circle et /profile/proches` | existe | Standard |
| 023 | Mon compte | Aujourd'hui | `/profile` | existe | Standard |
| 024 | Notifications | Aujourd'hui | `/profile/notifications` | à créer | Standard |
| 025 | Qui voit quoi | Aujourd'hui | `/profile/privacy` | à créer | Standard |
| 105 | Aide et contact | Aujourd'hui | `/profile/help` | à créer | Standard |
| 106 | Vos données | Aujourd'hui | `/profile/data` | à créer | Standard |
| 026 | Espace Maman | Aujourd'hui | `/home · espace « proche malade »` | à créer | Standard |
| 027 | Espace Ulysse | Aujourd'hui | `/home · espace « animal »` | à créer | Standard |
| 028 | Questions sur la mort | Aujourd'hui | `/home · espace « questions sur la mort »` | à créer | Standard |
| 101 | Questions pour le médecin | Aujourd'hui | `/home/questions-medecin` | à créer | Standard |
| 102 | Ses affaires | Aujourd'hui | `/home/ses-affaires` | à créer | Standard |
| 103 | En parler à un enfant | Aujourd'hui | `/home/parler-enfant` | à créer | Standard |
| 104 | En parler avec ses proches | Aujourd'hui | `/home/en-parler` | à créer | Standard |
| 029 | Soutien | Soutien | `/care` | existe | Standard |
| 030 | Se confier | Soutien | `/care/aide` | existe | Standard |
| 031 | Présence | Soutien | `/presence` | existe | Conversation |
| 032 | Ce que Présence peut faire | Soutien | `/presence/about` | à créer | Standard |
| 033 | Respirer | Soutien | `/care/respirer` | existe | Expérience plein écran (sans barre) |
| 034 | Sons pour s'endormir | Soutien | `/care/sons` | à créer | Expérience plein écran (sans barre) |
| 035 | Se poser | Soutien | `/no-words` | existe | Standard |
| 036 | Se poser · plein écran | Soutien | `/no-words · lecture` | existe | Expérience plein écran (sans barre) |
| 037 | Écrire | Soutien | `/care/journal` | existe | Standard |
| 038 | Mon journal | Soutien | `/care/journal · page d'écriture` | existe | Standard |
| 039 | Lettre pour plus tard | Soutien | `/care/journal/later` | à créer | Standard |
| 040 | Lire, écouter | Soutien | `/care/resources et /library/$kind` | existe | Standard |
| 041 | Une ressource | Soutien | `/library/$kind · détail` | à créer | Standard |
| 042 | Trouver un professionnel | Soutien | `/care/help` | existe | Standard |
| 043 | Fiche professionnel | Soutien | `/resources/$category/$providerId` | existe | Standard |
| 044 | Rendez-vous réservé | Soutien | `/resources/confirm/$providerId` | existe | Standard |
| 045 | Vos rendez-vous | Soutien | `/appointments` | existe | Standard |
| 046 | Un rendez-vous | Soutien | `/appointments/$id` | à créer | Standard |
| 047 | Ajouter un rendez-vous | Soutien | `/appointments/new` | à créer | Standard |
| 048 | Le corps | Soutien | `/help/corps` | existe | Standard |
| 049 | Dormir | Soutien | `/help/corps/nuits` | existe | Standard |
| 050 | Manger | Soutien | `/help/corps/manger` | existe | Standard |
| 051 | Se laver | Soutien | `/help/corps/eau` | existe | Standard |
| 052 | S'habiller | Soutien | `/help/corps/habiller` | existe | Standard |
| 053 | Dormir · contenus | Soutien | `/help/corps/nuits/contenus` | à créer | Standard |
| 054 | Exercice guidé | Soutien | `/help/corps/soin/$id` | existe | Expérience plein écran (sans barre) |
| 107 | Un moment de soin | Soutien | `/help/corps/soin` | à créer | Standard |
| 055 | Démarches | Démarches | `/practical (et /practical/tasks)` | existe | Standard |
| 056 | Une démarche | Démarches | `/practical/tasks/$id (et /parcours/$taskId)` | existe | Standard |
| 057 | Mon avancement | Démarches | `/practical/progress` | à créer | Standard |
| 058 | Les grandes étapes | Démarches | `/practical/steps` | existe | Standard |
| 059 | Mes documents | Démarches | `/practical/vault` | existe | Standard |
| 060 | Un courrier expliqué | Démarches | `/practical/letter` | à créer | Standard |
| 061 | Modèle de courrier | Démarches | `/practical/tasks/$id/template` | à créer | Standard |
| 062 | Confier à un proche | Démarches | `/practical/share/$taskId` | à créer | Standard |
| 063 | Envoyer vos choix | Démarches | `/practical/share` | existe | Standard |
| 064 | Repères | Démarches | `/practical/resources` | existe | Standard |
| 065 | Les professionnels | Démarches | `/practical/pros` | existe | Standard |
| 066 | Le notaire | Démarches | `/practical/pros/$kind` | à créer | Standard |
| 067 | Organiser la cérémonie | Démarches | `/practical/ceremony` | existe | Standard |
| 068 | Pompes funèbres | Démarches | `/resources/$category` | existe | Standard |
| 069 | Un prestataire | Démarches | `/resources/$category/$providerId` | existe | Standard |
| 070 | Les détails de la cérémonie | Démarches | `/practical/atmosphere` | existe | Standard |
| 071 | Choisir les fleurs | Démarches | `/practical/flowers` | existe | Standard |
| 072 | Fleurs · questions | Démarches | `/practical/flowers · questions` | existe | Questionnaire / entrée (sans barre) |
| 073 | Fleurs · proposition | Démarches | `/practical/flowers · proposition` | existe | Standard |
| 074 | Textes et musique | Démarches | `/practical/texts` | existe | Standard |
| 075 | Textes · propositions | Démarches | `/practical/texts · propositions` | existe | Standard |
| 076 | Cercueil, urne, plaque | Démarches | `/practical/objects` | existe | Standard |
| 077 | Le livret | Démarches | `/practical/booklet` | existe | Standard |
| 078 | Volontés | Démarches | `/practical/wishes (et /wishes)` | existe | Standard |
| 079 | Volontés · obsèques | Démarches | `/practical/wishes · obsèques` | existe | Questionnaire / entrée (sans barre) |
| 080 | Mémoire | Mémoire | `/care/garden/space` | à créer | Standard |
| 081 | Tous ses souvenirs | Mémoire | `/care/garden/all` | à créer | Standard |
| 082 | Un souvenir | Mémoire | `/care/garden/$zone/$id` | à créer | Standard |
| 108 | Ses photos | Mémoire | `/care/garden/$zone (photos)` | existe | Standard |
| 083 | Sa voix | Mémoire | `/care/garden/$zone (voix)` | existe | Standard |
| 084 | Lettres et mots | Mémoire | `/care/garden/$zone (lettres)` | existe | Standard |
| 109 | Les lieux | Mémoire | `/care/garden/$zone (lieux)` | existe | Standard |
| 085 | Ajouter un souvenir | Mémoire | `/care/garden/depot` | existe | Standard |
| 086 | Composer un souvenir | Mémoire | `/compose/$zone` | existe | Standard |
| 087 | Son portrait | Mémoire | `/profile/portrait` | existe | Standard |
| 088 | Inviter des proches | Mémoire | `/care/garden/invite` | à créer | Standard |
| 089 | Un livre souvenir | Mémoire | `/care/garden/book` | à créer | Standard |
| 090 | Un geste pour elle | Mémoire | `/care/rituels` | existe | Standard |
| 091 | Son anniversaire | Mémoire | `/care/dates/$id` | à créer | Standard |
| 092 | Une bougie | Mémoire | `/care/rituels/candle` | à créer | Expérience plein écran (sans barre) |
| 093 | Une bougie · quelques mots | Mémoire | `/care/rituels/candle · mots` | à créer | Expérience plein écran (sans barre) |
| 094 | Une lanterne | Mémoire | `/care/rituels/lantern` | à créer | Expérience plein écran (sans barre) |
| 110 | Une offrande | Mémoire | `/care/rituels/offering` | à créer | Questionnaire / entrée (sans barre) |
| 095 | Communauté | Communauté | `/care/community` | existe | Standard |
| 098 | Trouver un groupe | Communauté | `/care/community/groups` | à créer | Standard |
| 096 | Un groupe | Communauté | `/care/community/$group` | existe | Standard |
| 097 | Une conversation | Communauté | `/care/community/$group/$thread` | existe | Standard |
| 111 | Écrire au groupe | Communauté | `/care/community/$group/new` | à créer | Standard |
| 099 | Les règles du groupe | Communauté | `/care/community/regles` | existe | Standard |
| 100 | Une veillée | Communauté | `/care/community/vigil/$id` | à créer | Standard |
| 112 | Veillée · inscription | Communauté | `/care/community/vigil/$id/ok` | à créer | Standard |

---

## Référence

### 000 · Couleurs par espace

- Capture : `ecrans/png/000-palette.png` · Maquette : `ecrans/html/palette.html`
- Route : `—` · **—** · Référence des couleurs
- Type : Standard
- Ce qu'on peut toucher :
- Texte de l'écran, dans l'ordre :

```text
Une couleur par espace,
toujours la même.
Fond crème, texte vert profond. Chaque espace garde son couple, ses boutons et ses blocs.
BLOC
BOUTON
TEXTE
Aujourd'hui · bloc bleu, bouton vert profond
BLOC
BOUTON
Soutien · bloc lin, bouton bleu
BLOC
ACCENT
BOUTON
Démarches · bloc lin, accents corail, bouton bleu
BLOC
BOUTON
Mémoire, Communauté, Besoin d'aide · bloc rose, bouton bordeaux
FOND
BOUTON
Le soir, après 21 h · mode nuit, bouton menthe
```


---

## Entrée et première ouverture

### 001 · Écran d'entrée

- Capture : `ecrans/png/001-entree.png` · Maquette : `ecrans/html/entree.html`
- Route : `/` · **existe** · État final de l'animation d'ouverture existante (à conserver), avec le nouveau logo et le bouton « Entrer »
- Type : Écran d'entrée (fond bleu, logo, sans barre)
- Images : `assets/logo-symbole.png` et `assets/logo-legato.png` (versions haute définition à côté)
- Ce qu'on peut toucher :
  - « Entrer » → écran 002 · Bienvenue (/start)
- Code actuel (à réutiliser seulement pour ce qui ne change pas ; la maquette décide du reste) :
  - `src/routes/index.tsx` · logique utilisée : aucune
- Texte de l'écran, dans l'ordre :

```text
Entrer
```

### 002 · Bienvenue

- Capture : `ecrans/png/002-bienvenue.png` · Maquette : `ecrans/html/bienvenue.html`
- Route : `/start` · **existe** · Remplace
- Type : Questionnaire / entrée (sans barre)
- Ce qu'on peut toucher :
  - « Créer mon espace » → écran 006 · 1 · Pour qui (/onboarding · étape 1)
  - « J'ai déjà un compte » → écran 004 · Se connecter (/auth)
- Code actuel (à réutiliser seulement pour ce qui ne change pas ; la maquette décide du reste) :
  - `src/routes/start.tsx` · logique utilisée : aucune
- Texte de l'écran, dans l'ordre :

```text
LEGATO
BIENVENUE
Préparer
un adieu,
garder une présence.
Une application pour traverser le deuil, au jour le jour, à votre rythme.
Créer mon espace
J'ai déjà un compte
```

### 003 · Comment ça marche

- Capture : `ecrans/png/003-presentation.png` · Maquette : `ecrans/html/presentation.html`
- Route : `/presentation` · **existe** · Remplace
- Type : Questionnaire / entrée (sans barre)
- Ce qu'on peut toucher :
  - « Retour » → écran 002 · Bienvenue (/start)
  - « Créer mon espace » → écran 006 · 1 · Pour qui (/onboarding · étape 1)
  - « J'ai déjà un compte » → écran 004 · Se connecter (/auth)
- Code actuel (à réutiliser seulement pour ce qui ne change pas ; la maquette décide du reste) :
  - `src/routes/presentation.tsx` · logique utilisée : aucune
- Texte de l'écran, dans l'ordre :

```text
Retour
Ce que Legato
fait pour vous.
1
Aujourd'hui
Chaque jour, une seule chose à faire, adaptée à votre humeur
2
Soutien
Parler à quelqu'un, respirer, dormir, écrire
3
Démarches
Les papiers à faire, dans l'ordre, avec des modèles
4
Mémoire
Garder ses photos, sa voix, ses mots
5
Communauté
Échanger avec des personnes qui vivent la même chose
Créer mon espace
J'ai déjà un compte
```

### 004 · Se connecter

- Capture : `ecrans/png/004-connexion.png` · Maquette : `ecrans/html/connexion.html`
- Route : `/auth` · **existe** · Remplace
- Type : Questionnaire / entrée (sans barre)
- Ce qu'on peut toucher :
  - « Retour » → écran 002 · Bienvenue (/start)
  - « Se connecter » → écran 011 · Aujourd'hui (/home)
  - « Mot de passe oublié » → action sur place (enregistrer, appeler, lire…) : brancher sur la logique existante
  - champs de saisie : la valeur s'écrit en serif sur un filet
- Code actuel (à réutiliser seulement pour ce qui ne change pas ; la maquette décide du reste) :
  - `src/routes/auth.tsx` · logique utilisée : aucune
- Texte de l'écran, dans l'ordre :

```text
Retour
Bon retour.
Votre espace vous attend, tel que vous l'avez laissé.
ADRESSE E-MAIL
victor@exemple.fr
MOT DE PASSE
••••••••••
Se connecter
Mot de passe oublié
```

### 005 · Une invitation

- Capture : `ecrans/png/005-invitation.png` · Maquette : `ecrans/html/invitation.html`
- Route : `/invite/$token` · **existe** · Remplace
- Type : Questionnaire / entrée (sans barre)
- Ce qu'on peut toucher :
  - « Rejoindre l'espace d'Anne » → écran 011 · Aujourd'hui (/home)
  - « Pas maintenant » → action sur place (enregistrer, appeler, lire…) : brancher sur la logique existante
- Code actuel (à réutiliser seulement pour ce qui ne change pas ; la maquette décide du reste) :
  - `src/routes/invite.$token.tsx` · logique utilisée : circle.functions
- Texte de l'écran, dans l'ordre :

```text
Legato
INVITATION
Claire vous invite
dans l'espace d'Anne.
Claire a créé cet espace après le décès de sa mère. Elle aimerait partager avec vous des souvenirs et quelques démarches.
Vous pourrez —
1
Voir et ajouter des souvenirs
2
Recevoir les démarches qu'elle vous confie
Son journal, son humeur et ses échanges avec Présence restent privés.
Rejoindre l'espace d'Anne
Pas maintenant
```

### 006 · 1 · Pour qui

- Capture : `ecrans/png/006-onb-1.png` · Maquette : `ecrans/html/onb-1.html`
- Route : `/onboarding · étape 1` · **existe** · Remplace
- Type : Questionnaire / entrée (sans barre)
- Ce qu'on peut toucher :
  - « Continuer » → écran 007 · 2 · Son prénom (/onboarding · étape 2)
  - cartes de réponse à sélectionner (OptionCard) : un appui sélectionne, la carte sélectionnée prend le fond lin et le point plein
- Code actuel (à réutiliser seulement pour ce qui ne change pas ; la maquette décide du reste) :
  - `src/routes/onboarding.tsx` · logique utilisée : aucune
- Texte de l'écran, dans l'ordre :

```text
Pour qui créez-vous
cet espace ?
Choisissez la situation la plus proche. Vous pourrez créer d'autres espaces plus tard.
Une personne qui est décédée
Soutien, démarches, mémoire
Un animal qui est mort
Soutien et mémoire
Un proche gravement malade
L'accompagner et prendre soin de vous
Moi, pour préparer l'avenir
Comprendre, écrire mes volontés
Continuer
```

### 007 · 2 · Son prénom

- Capture : `ecrans/png/007-onb-2.png` · Maquette : `ecrans/html/onb-2.html`
- Route : `/onboarding · étape 2` · **existe** · Remplace
- Type : Questionnaire / entrée (sans barre)
- Ce qu'on peut toucher :
  - « Continuer » → écran 008 · 3 · Démarches (/onboarding/practical)
  - « Passer cette étape » → action sur place (enregistrer, appeler, lire…) : brancher sur la logique existante
  - champs de saisie : la valeur s'écrit en serif sur un filet
- Code actuel (à réutiliser seulement pour ce qui ne change pas ; la maquette décide du reste) :
  - `src/routes/onboarding.tsx` · logique utilisée : aucune
- Texte de l'écran, dans l'ordre :

```text
Comment voulez-vous
l'appeler ?
Legato utilisera ce nom pour vous parler d'elle. Personne d'autre ne le verra.
SON PRÉNOM, OU LE NOM QUE VOUS LUI DONNEZ
Mon amour
VOTRE LIEN AVEC ELLE
Mon épouse
DATE DU DÉCÈS · FACULTATIF
8 septembre 2026
Continuer
Passer cette étape
```

### 008 · 3 · Démarches

- Capture : `ecrans/png/008-onb-3.png` · Maquette : `ecrans/html/onb-3.html`
- Route : `/onboarding/practical` · **existe** · Remplace
- Type : Questionnaire / entrée (sans barre)
- Ce qu'on peut toucher :
  - « Continuer » → écran 009 · 4 · Vos besoins (/onboarding/care)
  - « Passer cette étape » → action sur place (enregistrer, appeler, lire…) : brancher sur la logique existante
  - cartes de réponse à sélectionner (OptionCard) : un appui sélectionne, la carte sélectionnée prend le fond lin et le point plein
- Code actuel (à réutiliser seulement pour ce qui ne change pas ; la maquette décide du reste) :
  - `src/routes/onboarding.practical.tsx` · logique utilisée : aucune · redirige aujourd'hui vers /onboarding
- Texte de l'écran, dans l'ordre :

```text
Où en êtes-vous
avec les papiers ?
Pour ne vous montrer que ce qui reste à faire.
Rien n'est commencé
Le décès est très récent
Les obsèques sont passées
Il reste la banque, les organismes
Presque tout est fait
Il reste la succession
Quelqu'un s'en occupe pour moi
Les démarches resteront masquées
Continuer
Passer cette étape
```

### 009 · 4 · Vos besoins

- Capture : `ecrans/png/009-onb-4.png` · Maquette : `ecrans/html/onb-4.html`
- Route : `/onboarding/care` · **existe** · Remplace
- Type : Questionnaire / entrée (sans barre)
- Ce qu'on peut toucher :
  - « Continuer » → écran 010 · C'est prêt (/onboarding · fin)
  - « Passer cette étape » → action sur place (enregistrer, appeler, lire…) : brancher sur la logique existante
  - cartes de réponse à sélectionner (OptionCard) : un appui sélectionne, la carte sélectionnée prend le fond lin et le point plein
- Code actuel (à réutiliser seulement pour ce qui ne change pas ; la maquette décide du reste) :
  - `src/routes/onboarding.care.tsx` · logique utilisée : aucune · redirige aujourd'hui vers /onboarding
- Texte de l'écran, dans l'ordre :

```text
De quoi avez-vous
besoin en ce moment ?
Plusieurs choix possibles. Le reste restera accessible.
Tenir le coup au jour le jour
Une proposition courte chaque matin
Faire les démarches
La liste des papiers, dans l'ordre
Parler à quelqu'un
Présence, bénévoles, psychologues
Garder sa mémoire
Photos, voix, lettres
Continuer
Passer cette étape
```

### 010 · C'est prêt

- Capture : `ecrans/png/010-onb-pret.png` · Maquette : `ecrans/html/onb-pret.html`
- Route : `/onboarding · fin` · **existe** · Remplace
- Type : Questionnaire / entrée (sans barre)
- Ce qu'on peut toucher :
  - « Ouvrir mon espace » → écran 011 · Aujourd'hui (/home)
- Code actuel (à réutiliser seulement pour ce qui ne change pas ; la maquette décide du reste) :
  - `src/routes/onboarding.tsx` · logique utilisée : aucune
- Texte de l'écran, dans l'ordre :

```text
Votre espace pour Anne
est prêt.
Voici ce qui va se passer à partir de maintenant.
1
Chaque matin à 9 h, Legato vous propose une seule chose à faire. Vous pouvez l'ignorer.
2
Après 21 h, l'application passe en mode nuit : seulement du repos, aucune démarche.
3
Rien n'est partagé avec vos proches sans votre accord.
Ouvrir mon espace
```


---

## Aujourd'hui

### 011 · Aujourd'hui

- Capture : `ecrans/png/011-aujourdhui.png` · Maquette : `ecrans/html/aujourdhui.html`
- Route : `/home` · **à créer** · Nouvelle page (aujourd'hui /home ne fait que rediriger)
- Type : Standard
- Ce qu'on peut toucher :
  - « Vos espaces » → écran 019 · Vos espaces (/space)
  - « Besoin d'aide » → écran 018 · Besoin d'aide (/crisis)
  - « Tristesse » → écran 013 · Comment allez-vous (/care/emotions (et /checkin))
  - « Fatigue » → écran 013 · Comment allez-vous (/care/emotions (et /checkin))
  - « Colère » → écran 013 · Comment allez-vous (/care/emotions (et /checkin))
  - « Nostalgie » → écran 013 · Comment allez-vous (/care/emotions (et /checkin))
  - « Autre » → écran 013 · Comment allez-vous (/care/emotions (et /checkin))
  - « Commencer à écrire » → écran 038 · Mon journal (/care/journal · page d'écriture)
  - « Cette semaine 2 démarches, dont une avant vendredi » → écran 055 · Démarches (/practical (et /practical/tasks))
  - « Dans 9 jours Son anniversaire · préparer un geste » → écran 017 · Une date difficile (/care/dates)
- Code actuel (à réutiliser seulement pour ce qui ne change pas ; la maquette décide du reste) :
  - `src/routes/home.tsx` · logique utilisée : aucune · redirige aujourd'hui vers /practical, /care
- Texte de l'écran, dans l'ordre :

```text
Legato
Besoin d'aide
Bonjour Victor. Cela fait trois semaines. Comment allez-vous aujourd'hui ?
Tristesse, Fatigue, Colère, Nostalgie, Autre
Pour aujourd'hui —
Écrire une lettre à mon amour
10 minutes · parce que vous vous sentez triste
Commencer à écrire
Cette semaine
2 démarches, dont une avant vendredi
Dans 9 jours
Son anniversaire · préparer un geste
```

### 012 · Le soir (mode nuit)

- Capture : `ecrans/png/012-soir.png` · Maquette : `ecrans/html/soir.html`
- Route : `/home après 21 h` · **à créer** · Même page en mode nuit
- Type : Standard · mode nuit
- Ce qu'on peut toucher :
  - « Vos espaces » → écran 019 · Vos espaces (/space)
  - « Besoin d'aide » → écran 018 · Besoin d'aide (/crisis)
  - « Commencer » → écran 033 · Respirer (/care/respirer)
  - « Des sons pour s'endormir Pluie, mer, forêt » → écran 034 · Sons pour s'endormir (/care/sons)
  - « Écrire à Présence Elle répond à toute heure » → écran 031 · Présence (/presence)
- Code actuel (à réutiliser seulement pour ce qui ne change pas ; la maquette décide du reste) :
  - `src/routes/home.tsx` · logique utilisée : aucune · redirige aujourd'hui vers /practical, /care
- Texte de l'écran, dans l'ordre :

```text
Legato
Besoin d'aide
Bonsoir Victor.
Le soir, seulement du repos.
Aucune démarche après 21 h. Elles vous attendront demain.
Pour ce soir —
Une respiration avant de dormir
5 minutes · parce que vous dormez mal ces jours-ci
Commencer
Des sons pour s'endormir
Pluie, mer, forêt
Écrire à Présence
Elle répond à toute heure
```

### 013 · Comment allez-vous

- Capture : `ecrans/png/013-humeur.png` · Maquette : `ecrans/html/humeur.html`
- Route : `/care/emotions (et /checkin)` · **existe** · Remplace
- Type : Standard
- Ce qu'on peut toucher :
  - « Aujourd'hui » → écran 011 · Aujourd'hui (/home)
  - « Besoin d'aide » → écran 018 · Besoin d'aide (/crisis)
  - « Tristesse » → sélection sur place (reste sur cet écran)
  - « Fatigue » → sélection sur place (reste sur cet écran)
  - « Colère » → sélection sur place (reste sur cet écran)
  - « Culpabilité » → sélection sur place (reste sur cet écran)
  - « Nostalgie » → sélection sur place (reste sur cet écran)
  - « Vide » → sélection sur place (reste sur cet écran)
  - « Autre chose » → sélection sur place (reste sur cet écran)
  - « Enregistrer » → écran 014 · C'est noté (/care/emotions · après enregistrement)
  - barre d'humeur : le curseur se fait glisser de « Très dur » à « Plutôt bien »
- Code actuel (à réutiliser seulement pour ce qui ne change pas ; la maquette décide du reste) :
  - `src/routes/care.emotions.tsx` · logique utilisée : checkin-store, emotion-content, emotion-depth, emotion-intensity, legato-state
  - `src/routes/checkin.tsx` · logique utilisée : legato-state · redirige aujourd'hui vers /care/emotions
- Texte de l'écran, dans l'ordre :

```text
Aujourd'hui
Besoin d'aide
Comment allez-vous,
vraiment ?
Il n'y a pas de bonne réponse. Cela sert seulement à vous proposer ce qui peut aider.
1 · CE QUE VOUS RESSENTEZ
Tristesse, Fatigue, Colère, Culpabilité, Nostalgie, Vide, Autre chose
2 · AUJOURD'HUI, C'EST PLUTÔT
TRÈS DUR
PLUTÔT BIEN
3 · UN MOT DE PLUS, SI VOUS VOULEZ
Ce matin…
Enregistrer
```

### 014 · C'est noté

- Capture : `ecrans/png/014-humeur-merci.png` · Maquette : `ecrans/html/humeur-merci.html`
- Route : `/care/emotions · après enregistrement` · **à créer** · Nouvel état
- Type : Standard
- Ce qu'on peut toucher :
  - « Aujourd'hui » → écran 011 · Aujourd'hui (/home)
  - « Besoin d'aide » → écran 018 · Besoin d'aide (/crisis)
  - « Respirer » → écran 033 · Respirer (/care/respirer)
  - « Parler à quelqu'un, tout de suite Présence, ou une ligne d'écoute » → écran 030 · Se confier (/care/aide)
  - « Revenir à Aujourd'hui » → écran 011 · Aujourd'hui (/home)
- Code actuel (à réutiliser seulement pour ce qui ne change pas ; la maquette décide du reste) :
  - `src/routes/care.emotions.tsx` · logique utilisée : checkin-store, emotion-content, emotion-depth, emotion-intensity, legato-state
- Texte de l'écran, dans l'ordre :

```text
Aujourd'hui
Besoin d'aide
C'est noté.
Merci de l'avoir dit.
Tristesse et fatigue : une journée dure. Voici ce qui peut aider, sans obligation.
Maintenant —
Une respiration de trois minutes
Parce que la fatigue pèse sur tout le reste
Respirer
Parler à quelqu'un, tout de suite
Présence, ou une ligne d'écoute
Revenir à Aujourd'hui
```

### 015 · Les jours qui viennent

- Capture : `ecrans/png/015-agenda.png` · Maquette : `ecrans/html/agenda.html`
- Route : `/agenda` · **existe** · Remplace
- Type : Standard
- Ce qu'on peut toucher :
  - « Aujourd'hui » → écran 011 · Aujourd'hui (/home)
  - « Besoin d'aide » → écran 018 · Besoin d'aide (/crisis)
  - « 25 SEPT. Acte de décès Démarche · à faire avant ce jour » → écran 056 · Une démarche (/practical/tasks/$id (et /parcours/$taskId))
  - « 1 OCT. Veillée en visio Communauté · 20 h » → écran 100 · Une veillée (/care/community/vigil/$id)
  - « 3 OCT. Son anniversaire Une date difficile · la préparer » → écran 017 · Une date difficile (/care/dates)
  - « 6 OCT. Maître Blanc, notaire Rendez-vous · à maintenir » → écran 046 · Un rendez-vous (/appointments/$id)
  - « Ajouter une date » → écran 016 · Ajouter une date (/agenda/new)
- Code actuel (à réutiliser seulement pour ce qui ne change pas ; la maquette décide du reste) :
  - `src/routes/agenda.tsx` · logique utilisée : agenda-store, legato-state, self-care
- Texte de l'écran, dans l'ordre :

```text
Aujourd'hui
Besoin d'aide
Les jours
qui viennent.
Les dates importantes de cet espace, au même endroit.
25
SEPT.
Acte de décès
Démarche · à faire avant ce jour
1
OCT.
Veillée en visio
Communauté · 20 h
3
OCT.
Son anniversaire
Une date difficile · la préparer
6
OCT.
Maître Blanc, notaire
Rendez-vous · à maintenir
Ajouter une date
```

### 016 · Ajouter une date

- Capture : `ecrans/png/016-ajouter-date.png` · Maquette : `ecrans/html/ajouter-date.html`
- Route : `/agenda/new` · **à créer** · Formulaire
- Type : Standard
- Ce qu'on peut toucher :
  - « Les jours qui viennent » → écran 015 · Les jours qui viennent (/agenda)
  - « Besoin d'aide » → écran 018 · Besoin d'aide (/crisis)
  - « Enregistrer » → action sur place (enregistrer, appeler, lire…) : brancher sur la logique existante
  - champs de saisie : la valeur s'écrit en serif sur un filet
- Texte de l'écran, dans l'ordre :

```text
Les jours qui viennent
Besoin d'aide
Ajouter
une date.
QUELLE DATE
Son anniversaire
LE
3 octobre, chaque année
VOUS LE RAPPELER
Non
Une semaine avant
La veille
Pour une date difficile, Legato vous proposera aussi de ne pas la passer seul.
Enregistrer
```

### 017 · Une date difficile

- Capture : `ecrans/png/017-date-difficile.png` · Maquette : `ecrans/html/date-difficile.html`
- Route : `/care/dates` · **existe** · Remplace
- Type : Standard
- Ce qu'on peut toucher :
  - « Les jours qui viennent » → écran 015 · Les jours qui viennent (/agenda)
  - « Besoin d'aide » → écran 018 · Besoin d'aide (/crisis)
  - « Prévenir un proche Lui demander de passer, ou d'appeler » → action sur place (enregistrer, appeler, lire…) : brancher sur la logique existante
  - « Prévoir un moment pour elle Un lieu, une musique, une bougie » → écran 091 · Son anniversaire (/care/dates/$id)
  - « Parler à d'autres ce jour-là Veillée ou groupe » → écran 095 · Communauté (/care/community)
  - « Laisser passer la journée Legato ne vous le rappellera pas » → action sur place (enregistrer, appeler, lire…) : brancher sur la logique existante
- Code actuel (à réutiliser seulement pour ce qui ne change pas ; la maquette décide du reste) :
  - `src/routes/care.dates.tsx` · logique utilisée : date-rituals, legato-state, spaces-store
- Texte de l'écran, dans l'ordre :

```text
Les jours qui viennent
Besoin d'aide
SAMEDI 3 OCTOBRE · DANS 9 JOURS
Son anniversaire.
Mieux vaut ne pas être seul.
Ces dates sont souvent plus dures qu'on ne l'imagine. Vous pouvez les préparer un peu.
Prévenir un proche
Lui demander de passer, ou d'appeler
Prévoir un moment pour elle
Un lieu, une musique, une bougie
Parler à d'autres ce jour-là
Veillée ou groupe
Laisser passer la journée
Legato ne vous le rappellera pas
```

### 018 · Besoin d'aide

- Capture : `ecrans/png/018-aide.png` · Maquette : `ecrans/html/aide.html`
- Route : `/crisis` · **existe** · Remplace (Besoin d'aide, accessible partout)
- Type : Plein écran bordeaux (sans barre)
- Ce qu'on peut toucher :
  - « Retour » → écran 011 · Aujourd'hui (/home)
  - « Appeler » → action sur place (enregistrer, appeler, lire…) : brancher sur la logique existante
  - « Respirer avec moi » → écran 033 · Respirer (/care/respirer)
  - « Écrire à Présence » → écran 031 · Présence (/presence)
- Code actuel (à réutiliser seulement pour ce qui ne change pas ; la maquette décide du reste) :
  - `src/routes/crisis.tsx` · logique utilisée : listening-lines
- Texte de l'écran, dans l'ordre :

```text
Retour
BESOIN D'AIDE
Vous n'êtes pas seul.
Parlez à quelqu'un
maintenant.
Gratuit, anonyme, jour et nuit.
3114
Si vous pensez au suicide
ÉCOUTE PROFESSIONNELLE
Appeler
15
Urgence médicale
SAMU
Appeler
112
Toute urgence
DEPUIS TOUT TÉLÉPHONE
Appeler
Respirer avec moi
Écrire à Présence
```

### 019 · Vos espaces

- Capture : `ecrans/png/019-vous.png` · Maquette : `ecrans/html/vous.html`
- Route : `/space` · **à créer** · Nouvelle page (aujourd'hui /space redirige)
- Type : Standard
- Ce qu'on peut toucher :
  - « Aujourd'hui » → écran 011 · Aujourd'hui (/home)
  - « Besoin d'aide » → écran 018 · Besoin d'aide (/crisis)
  - « Réglages » → écran 021 · Réglages de l'espace (/space/settings)
  - « Votre cercle » → écran 022 · Votre cercle (/circle et /profile/proches)
  - « Maman Proche malade · depuis 2 mois ↗ » → écran 026 · Espace Maman (/home · espace « proche malade »)
  - « Ulysse Animal · depuis 10 jours ↗ » → écran 027 · Espace Ulysse (/home · espace « animal »)
  - « + Créer un espace » → écran 020 · Créer un espace (/space/new)
  - « Mon compte » → écran 023 · Mon compte (/profile)
- Code actuel (à réutiliser seulement pour ce qui ne change pas ; la maquette décide du reste) :
  - `src/routes/space.tsx` · logique utilisée : aucune · redirige aujourd'hui vers /home
- Texte de l'écran, dans l'ordre :

```text
Aujourd'hui
Besoin d'aide
Vos
espaces.
3
ESPACES
Ouvert en ce moment —
Mon amour
DEUIL
Depuis trois semaines
Réglages
Votre cercle
Vos autres espaces —
Maman
Proche malade · depuis 2 mois
↗
Ulysse
Animal · depuis 10 jours
↗
+ Créer un espace
Mon compte
```

### 020 · Créer un espace

- Capture : `ecrans/png/020-creer.png` · Maquette : `ecrans/html/creer.html`
- Route : `/space/new` · **à créer** · Formulaire
- Type : Questionnaire / entrée (sans barre)
- Ce qu'on peut toucher :
  - « Vos espaces » → écran 019 · Vos espaces (/space)
  - « Besoin d'aide » → écran 018 · Besoin d'aide (/crisis)
  - « Continuer » → action sur place (enregistrer, appeler, lire…) : brancher sur la logique existante
  - cartes de réponse à sélectionner (OptionCard) : un appui sélectionne, la carte sélectionnée prend le fond lin et le point plein
- Texte de l'écran, dans l'ordre :

```text
Vos espaces
Besoin d'aide
Pour qui créez-vous
cet espace ?
Un espace par personne. Chacun a ses propres démarches, souvenirs et rappels.
Une personne qui est décédée
Soutien, démarches, mémoire
Un animal qui est mort
Soutien et mémoire
Un proche gravement malade
L'accompagner et prendre soin de vous
Moi, pour préparer l'avenir
Comprendre, écrire mes volontés
Continuer
```

### 021 · Réglages de l'espace

- Capture : `ecrans/png/021-reglages-espace.png` · Maquette : `ecrans/html/reglages-espace.html`
- Route : `/space/settings` · **à créer**
- Type : Standard
- Ce qu'on peut toucher :
  - « Vos espaces » → écran 019 · Vos espaces (/space)
  - « Besoin d'aide » → écran 018 · Besoin d'aide (/crisis)
  - « Archiver cet espace » → action sur place (enregistrer, appeler, lire…) : brancher sur la logique existante
  - interrupteurs marche / arrêt (le rond menthe à droite = activé)
- Texte de l'écran, dans l'ordre :

```text
Vos espaces
Besoin d'aide
Réglages de
« Mon amour »
Ce que l'espace contient —
Les démarches
Les papiers à faire après le décès
La mémoire
Photos, voix, lettres, lieux
La communauté
Groupes et veillées
Votre rythme —
Le mode nuit
Après 21 h, seulement du repos
La proposition du matin
Chaque jour à 9 h
Archiver cet espace
```

### 022 · Votre cercle

- Capture : `ecrans/png/022-cercle.png` · Maquette : `ecrans/html/cercle.html`
- Route : `/circle et /profile/proches` · **existe** · Remplace
- Type : Standard
- Ce qu'on peut toucher :
  - « Vos espaces » → écran 019 · Vos espaces (/space)
  - « Besoin d'aide » → écran 018 · Besoin d'aide (/crisis)
  - « Inviter un proche » → action sur place (enregistrer, appeler, lire…) : brancher sur la logique existante
- Code actuel (à réutiliser seulement pour ce qui ne change pas ; la maquette décide du reste) :
  - `src/routes/_authenticated/circle.tsx` · logique utilisée : circle.functions
  - `src/routes/profile.proches.tsx` · logique utilisée : active-space, legato-state, spaces-store
- Texte de l'écran, dans l'ordre :

```text
Vos espaces
Besoin d'aide
Votre cercle.
Les proches qui partagent cet espace avec vous. Chacun ne voit que ce que vous lui ouvrez.
Claire
Votre sœur · souvenirs et démarches
MEMBRE
P
Paul
Un ami · souvenirs
MEMBRE
J
Jeanne
Invitation envoyée hier
EN ATTENTE
Votre journal, votre humeur et vos échanges avec Présence restent toujours privés.
Inviter un proche
```

### 023 · Mon compte

- Capture : `ecrans/png/023-compte.png` · Maquette : `ecrans/html/compte.html`
- Route : `/profile` · **existe** · Remplace
- Type : Standard
- Ce qu'on peut toucher :
  - « Vos espaces » → écran 019 · Vos espaces (/space)
  - « Besoin d'aide » → écran 018 · Besoin d'aide (/crisis)
  - « Modifier » → action sur place (enregistrer, appeler, lire…) : brancher sur la logique existante
  - « Notifications Une le matin à 9 h, jamais après 21 h ↗ » → écran 024 · Notifications (/profile/notifications)
  - « Qui voit quoi Ce que voient vos proches ↗ » → écran 025 · Qui voit quoi (/profile/privacy)
  - « Aide et contact Une question, un problème ↗ » → écran 105 · Aide et contact (/profile/help)
  - « Vos données Télécharger ou supprimer ↗ » → écran 106 · Vos données (/profile/data)
  - « Se déconnecter » → écran 002 · Bienvenue (/start)
- Code actuel (à réutiliser seulement pour ce qui ne change pas ; la maquette décide du reste) :
  - `src/routes/profile.tsx` · logique utilisée : aucune
- Texte de l'écran, dans l'ordre :

```text
Vos espaces
Besoin d'aide
Mon compte.
PRÉNOM
Victor
E-MAIL
victor@exemple.fr
Modifier
Notifications
Une le matin à 9 h, jamais après 21 h
↗
Qui voit quoi
Ce que voient vos proches
↗
Aide et contact
Une question, un problème
↗
Vos données
Télécharger ou supprimer
↗
Se déconnecter
```

### 024 · Notifications

- Capture : `ecrans/png/024-notifications.png` · Maquette : `ecrans/html/notifications.html`
- Route : `/profile/notifications` · **à créer**
- Type : Standard
- Ce qu'on peut toucher :
  - « Mon compte » → écran 023 · Mon compte (/profile)
  - « Besoin d'aide » → écran 018 · Besoin d'aide (/crisis)
  - interrupteurs marche / arrêt (le rond menthe à droite = activé)
- Texte de l'écran, dans l'ordre :

```text
Mon compte
Besoin d'aide
Les notifications.
Legato ne vous écrit jamais après 21 h, et jamais plus d'une fois le matin.
Ce que vous recevez —
La proposition du jour
Chaque matin à 9 h
Les échéances des démarches
La veille seulement
Les messages de vos groupes
Un résumé par jour
Les dates importantes
Son anniversaire, un mois après
```

### 025 · Qui voit quoi

- Capture : `ecrans/png/025-confidentialite.png` · Maquette : `ecrans/html/confidentialite.html`
- Route : `/profile/privacy` · **à créer**
- Type : Standard
- Ce qu'on peut toucher :
  - « Mon compte » → écran 023 · Mon compte (/profile)
  - « Besoin d'aide » → écran 018 · Besoin d'aide (/crisis)
- Texte de l'écran, dans l'ordre :

```text
Mon compte
Besoin d'aide
Qui voit quoi.
Par défaut, tout est privé. Vous choisissez ce que vous ouvrez à votre cercle.
Votre journal
VOUS SEUL
Votre humeur
VOUS SEUL
Vos échanges avec Présence
VOUS SEUL
Les souvenirs
VOUS ET VOTRE CERCLE
Une démarche confiée
LA PERSONNE CHOISIE
```

### 105 · Aide et contact

- Capture : `ecrans/png/105-aide-contact.png` · Maquette : `ecrans/html/aide-contact.html`
- Route : `/profile/help` · **à créer**
- Type : Standard
- Ce qu'on peut toucher :
  - « Mon compte » → écran 023 · Mon compte (/profile)
  - « Besoin d'aide » → écran 018 · Besoin d'aide (/crisis)
  - « Comment fonctionne Legato Les cinq espaces, en une page ↗ » → écran 003 · Comment ça marche (/presentation)
  - « Comment supprimer un souvenir ? ↗ » → action sur place (enregistrer, appeler, lire…) : brancher sur la logique existante
  - « Comment inviter un proche ? ↗ » → action sur place (enregistrer, appeler, lire…) : brancher sur la logique existante
  - « Mes données sont-elles protégées ? ↗ » → action sur place (enregistrer, appeler, lire…) : brancher sur la logique existante
  - « Écrire à l'équipe » → action sur place (enregistrer, appeler, lire…) : brancher sur la logique existante
- Texte de l'écran, dans l'ordre :

```text
Mon compte
Besoin d'aide
Aide et contact.
Une question sur l'application, un problème, une remarque.
Comment fonctionne Legato
Les cinq espaces, en une page
↗
Comment supprimer un souvenir ?
↗
Comment inviter un proche ?
↗
Mes données sont-elles protégées ?
↗
Écrire à l'équipe
```

### 106 · Vos données

- Capture : `ecrans/png/106-donnees.png` · Maquette : `ecrans/html/donnees.html`
- Route : `/profile/data` · **à créer**
- Type : Standard
- Ce qu'on peut toucher :
  - « Mon compte » → écran 023 · Mon compte (/profile)
  - « Besoin d'aide » → écran 018 · Besoin d'aide (/crisis)
  - « Télécharger tout Journal, souvenirs, documents · un fichier ↗ » → action sur place (enregistrer, appeler, lire…) : brancher sur la logique existante
  - « Supprimer un espace Ses souvenirs et ses démarches seront effacés ↗ » → action sur place (enregistrer, appeler, lire…) : brancher sur la logique existante
  - « Supprimer mon compte Tout sera effacé, définitivement ↗ » → action sur place (enregistrer, appeler, lire…) : brancher sur la logique existante
- Texte de l'écran, dans l'ordre :

```text
Mon compte
Besoin d'aide
Vos données.
Tout ce que vous avez écrit et gardé vous appartient.
Télécharger tout
Journal, souvenirs, documents · un fichier
↗
Supprimer un espace
Ses souvenirs et ses démarches seront effacés
↗
Supprimer mon compte
Tout sera effacé, définitivement
↗
Avant toute suppression, Legato vous propose de télécharger vos souvenirs.
```

### 026 · Espace Maman

- Capture : `ecrans/png/026-auj-maman.png` · Maquette : `ecrans/html/auj-maman.html`
- Route : `/home · espace « proche malade »` · **à créer** · Variante de /home selon le type d'espace
- Type : Standard
- Ce qu'on peut toucher :
  - « Vos espaces » → écran 019 · Vos espaces (/space)
  - « Besoin d'aide » → écran 018 · Besoin d'aide (/crisis)
  - « Inquiet » → écran 013 · Comment allez-vous (/care/emotions (et /checkin))
  - « Épuisé » → écran 013 · Comment allez-vous (/care/emotions (et /checkin))
  - « Serein » → écran 013 · Comment allez-vous (/care/emotions (et /checkin))
  - « Autre » → écran 013 · Comment allez-vous (/care/emotions (et /checkin))
  - « Préparer mes questions » → écran 101 · Questions pour le médecin (/home/questions-medecin)
  - « Ses rendez-vous Jeudi 10 h · hôpital de la Timone » → écran 045 · Vos rendez-vous (/appointments)
  - « Parler à d'autres aidants Un groupe, une ligne d'écoute » → écran 098 · Trouver un groupe (/care/community/groups)
- Code actuel (à réutiliser seulement pour ce qui ne change pas ; la maquette décide du reste) :
  - `src/routes/home.tsx` · logique utilisée : aucune · redirige aujourd'hui vers /practical, /care
- Texte de l'écran, dans l'ordre :

```text
Legato
Besoin d'aide
Et vous, comment allez-vous aujourd'hui ?
ESPACE « MAMAN » · ACCOMPAGNER UN PROCHE MALADE
Inquiet, Épuisé, Serein, Autre
Pour aujourd'hui —
Préparer vos questions pour l'oncologue
Rendez-vous jeudi · 10 minutes
Préparer mes questions
Ses rendez-vous
Jeudi 10 h · hôpital de la Timone
Parler à d'autres aidants
Un groupe, une ligne d'écoute
```

### 027 · Espace Ulysse

- Capture : `ecrans/png/027-auj-ulysse.png` · Maquette : `ecrans/html/auj-ulysse.html`
- Route : `/home · espace « animal »` · **à créer** · Variante de /home
- Type : Standard
- Ce qu'on peut toucher :
  - « Vos espaces » → écran 019 · Vos espaces (/space)
  - « Besoin d'aide » → écran 018 · Besoin d'aide (/crisis)
  - « Tristesse » → écran 013 · Comment allez-vous (/care/emotions (et /checkin))
  - « Culpabilité » → écran 013 · Comment allez-vous (/care/emotions (et /checkin))
  - « Vide » → écran 013 · Comment allez-vous (/care/emotions (et /checkin))
  - « Autre » → écran 013 · Comment allez-vous (/care/emotions (et /checkin))
  - « Commencer » → écran 086 · Composer un souvenir (/compose/$zone)
  - « Ses affaires Que garder, que donner, à votre rythme » → écran 102 · Ses affaires (/home/ses-affaires)
  - « En parler à un enfant Des mots simples pour expliquer » → écran 103 · En parler à un enfant (/home/parler-enfant)
- Code actuel (à réutiliser seulement pour ce qui ne change pas ; la maquette décide du reste) :
  - `src/routes/home.tsx` · logique utilisée : aucune · redirige aujourd'hui vers /practical, /care
- Texte de l'écran, dans l'ordre :

```text
Legato
Besoin d'aide
Ulysse vous manque. C'est un vrai chagrin.
ESPACE « ULYSSE » · PERTE D'UN ANIMAL
Tristesse, Culpabilité, Vide, Autre
Pour aujourd'hui —
Rassembler ses photos préférées
15 minutes · pour garder sa trace
Commencer
Ses affaires
Que garder, que donner, à votre rythme
En parler à un enfant
Des mots simples pour expliquer
```

### 028 · Questions sur la mort

- Capture : `ecrans/png/028-auj-questions.png` · Maquette : `ecrans/html/auj-questions.html`
- Route : `/home · espace « questions sur la mort »` · **à créer** · Variante de /home
- Type : Standard
- Ce qu'on peut toucher :
  - « Vos espaces » → écran 019 · Vos espaces (/space)
  - « Besoin d'aide » → écran 018 · Besoin d'aide (/crisis)
  - « Curieux » → écran 013 · Comment allez-vous (/care/emotions (et /checkin))
  - « Inquiet » → écran 013 · Comment allez-vous (/care/emotions (et /checkin))
  - « Serein » → écran 013 · Comment allez-vous (/care/emotions (et /checkin))
  - « Autre » → écran 013 · Comment allez-vous (/care/emotions (et /checkin))
  - « Commencer » → écran 078 · Volontés (/practical/wishes (et /wishes))
  - « Ce qui se passe, concrètement Les étapes après un décès, expliquées » → écran 058 · Les grandes étapes (/practical/steps)
  - « En parler avec ses proches Comment ouvrir la conversation » → écran 104 · En parler avec ses proches (/home/en-parler)
- Code actuel (à réutiliser seulement pour ce qui ne change pas ; la maquette décide du reste) :
  - `src/routes/home.tsx` · logique utilisée : aucune · redirige aujourd'hui vers /practical, /care
- Texte de l'écran, dans l'ordre :

```text
Legato
Besoin d'aide
Vos questions sur la mort.
ESPACE PERSONNEL · SANS URGENCE
Curieux, Inquiet, Serein, Autre
Pour commencer —
Écrire vos volontés, pas à pas
20 minutes · modifiable à tout moment
Commencer
Ce qui se passe, concrètement
Les étapes après un décès, expliquées
En parler avec ses proches
Comment ouvrir la conversation
```

### 101 · Questions pour le médecin

- Capture : `ecrans/png/101-questions-medecin.png` · Maquette : `ecrans/html/questions-medecin.html`
- Route : `/home/questions-medecin` · **à créer**
- Type : Standard
- Ce qu'on peut toucher :
  - « Espace Maman » → écran 026 · Espace Maman (/home · espace « proche malade »)
  - « Besoin d'aide » → écran 018 · Besoin d'aide (/crisis)
  - « Garder pour jeudi » → action sur place (enregistrer, appeler, lire…) : brancher sur la logique existante
  - cartes de réponse à sélectionner (OptionCard) : un appui sélectionne, la carte sélectionnée prend le fond lin et le point plein
- Texte de l'écran, dans l'ordre :

```text
Espace Maman
Besoin d'aide
RENDEZ-VOUS JEUDI · 10 H · TIMONE
Vos questions
pour l'oncologue.
Gardez celles qui vous parlent. Vous les retrouverez jeudi, dans le rendez-vous.
Comment va-t-elle réagir au traitement ?
Que pouvons-nous faire à la maison ?
Qui appeler en cas de doute, le soir ?
Comment prendre soin de moi aussi ?
Ajouter votre question…
Garder pour jeudi
```

### 102 · Ses affaires

- Capture : `ecrans/png/102-ses-affaires.png` · Maquette : `ecrans/html/ses-affaires.html`
- Route : `/home/ses-affaires` · **à créer**
- Type : Standard
- Ce qu'on peut toucher :
  - « Espace Ulysse » → écran 027 · Espace Ulysse (/home · espace « animal »)
  - « Besoin d'aide » → écran 018 · Besoin d'aide (/crisis)
  - « Trouver un refuge près de chez vous » → action sur place (enregistrer, appeler, lire…) : brancher sur la logique existante
- Texte de l'écran, dans l'ordre :

```text
Espace Ulysse
Besoin d'aide
Ses affaires,
à votre rythme.
Rien ne presse. Certaines personnes gardent tout un temps, d'autres préfèrent ranger vite.
Vous pouvez —
1
Garder un objet qui lui ressemble : son collier, sa balle.
2
Donner le reste à un refuge, quand vous serez prêt.
3
Laisser tout en place pour l'instant.
Trouver un refuge près de chez vous
```

### 103 · En parler à un enfant

- Capture : `ecrans/png/103-parler-enfant.png` · Maquette : `ecrans/html/parler-enfant.html`
- Route : `/home/parler-enfant` · **à créer**
- Type : Standard
- Ce qu'on peut toucher :
  - « Espace Ulysse » → écran 027 · Espace Ulysse (/home · espace « animal »)
  - « Besoin d'aide » → écran 018 · Besoin d'aide (/crisis)
  - « Lire : expliquer la mort d'un animal » → écran 041 · Une ressource (/library/$kind · détail)
- Texte de l'écran, dans l'ordre :

```text
Espace Ulysse
Besoin d'aide
En parler
à un enfant.
Les enfants comprennent mieux des mots simples et vrais que des détours.
Ce qui aide —
1
Dire « il est mort », plutôt que « il est parti ».
2
Répondre à ses questions, même si elles reviennent.
3
Lui proposer un geste : un dessin, une photo à garder.
Lire : expliquer la mort d'un animal
```

### 104 · En parler avec ses proches

- Capture : `ecrans/png/104-en-parler.png` · Maquette : `ecrans/html/en-parler.html`
- Route : `/home/en-parler` · **à créer**
- Type : Standard
- Ce qu'on peut toucher :
  - « Questions sur la mort » → écran 028 · Questions sur la mort (/home · espace « questions sur la mort »)
  - « Besoin d'aide » → écran 018 · Besoin d'aide (/crisis)
- Texte de l'écran, dans l'ordre :

```text
Questions sur la mort
Besoin d'aide
En parler
avec ses proches.
Ce n'est pas une conversation facile. Elle soulage souvent ceux qui restent.
Une phrase pour commencer —
« J'ai pensé à ce que je voudrais, plus tard. Est-ce que je peux t'en parler ? »
Ce qui aide —
1
Choisir un moment calme, sans urgence.
2
Parler de ce qui compte pour vous, pas seulement des papiers.
```


---

## Soutien

### 029 · Soutien

- Capture : `ecrans/png/029-soutien.png` · Maquette : `ecrans/html/soutien.html`
- Route : `/care` · **existe** · Remplace
- Type : Standard
- Ce qu'on peut toucher :
  - « Besoin d'aide » → écran 018 · Besoin d'aide (/crisis)
  - « Se confier À Présence, à un bénévole, à un groupe » → écran 030 · Se confier (/care/aide)
  - « Respirer, se poser Trois minutes, ou plus » → écran 033 · Respirer (/care/respirer)
  - « Prendre soin de votre corps Dormir, manger, se laver » → écran 048 · Le corps (/help/corps)
  - « Écrire Journal et lettres » → écran 037 · Écrire (/care/journal)
  - « Lire, écouter Livres et podcasts choisis » → écran 040 · Lire, écouter (/care/resources et /library/$kind)
  - « Trouver un professionnel Psychologues, associations » → écran 042 · Trouver un professionnel (/care/help)
- Code actuel (à réutiliser seulement pour ce qui ne change pas ; la maquette décide du reste) :
  - `src/routes/care.tsx` · logique utilisée : aucune
- Texte de l'écran, dans l'ordre :

```text
Soutien
Besoin d'aide
Prendre soin
de vous.
Maintenant —
Se confier
À Présence, à un bénévole, à un groupe
Respirer, se poser
Trois minutes, ou plus
Prendre soin de votre corps
Dormir, manger, se laver
Écrire
Journal et lettres
Lire, écouter
Livres et podcasts choisis
Trouver un professionnel
Psychologues, associations
```

### 030 · Se confier

- Capture : `ecrans/png/030-confier.png` · Maquette : `ecrans/html/confier.html`
- Route : `/care/aide` · **existe** · Remplace (Se confier)
- Type : Standard
- Ce qu'on peut toucher :
  - « Soutien » → écran 029 · Soutien (/care)
  - « Besoin d'aide » → écran 018 · Besoin d'aide (/crisis)
  - « Écrire à Présence » → écran 031 · Présence (/presence)
  - « Appeler » → action sur place (enregistrer, appeler, lire…) : brancher sur la logique existante
  - « Voir » → écran 095 · Communauté (/care/community)
  - « Chercher » → écran 042 · Trouver un professionnel (/care/help)
- Code actuel (à réutiliser seulement pour ce qui ne change pas ; la maquette décide du reste) :
  - `src/routes/care.aide.tsx` · logique utilisée : resources-data
- Texte de l'écran, dans l'ordre :

```text
Soutien
Besoin d'aide
À qui voulez-vous
parler ?
Tout de suite —
Présence
Une écoute à toute heure. Intelligence artificielle : elle ne remplace ni vos proches ni un professionnel.
Écrire à Présence
Ou un humain —
Un bénévole
Ligne d'écoute du deuil · 9 h – 21 h
Appeler
Un groupe
Des personnes qui vivent la même chose
Voir
Un professionnel
Psychologue, sur rendez-vous
Chercher
```

### 031 · Présence

- Capture : `ecrans/png/031-presence.png` · Maquette : `ecrans/html/presence.html`
- Route : `/presence` · **existe** · Remplace
- Type : Conversation
- Ce qu'on peut toucher :
  - « Se confier » → écran 030 · Se confier (/care/aide)
  - « Besoin d'aide » → écran 018 · Besoin d'aide (/crisis)
  - « Ce qu'elle peut faire » → écran 032 · Ce que Présence peut faire (/presence/about)
- Code actuel (à réutiliser seulement pour ce qui ne change pas ; la maquette décide du reste) :
  - `src/routes/presence.tsx` · logique utilisée : legato-state, portrait-store, presence.functions
- Texte de l'écran, dans l'ordre :

```text
Se confier
Besoin d'aide
Présence
Une écoute à toute heure · intelligence artificielle. Elle ne remplace ni vos proches ni un professionnel.
Je suis là. De quoi avez-vous envie de parler ce soir ?
Je n'arrive pas à dormir. La maison est trop silencieuse.
Le silence du soir revient souvent, les premières semaines. Voulez-vous me parler d'elle, ou plutôt essayer de vous apaiser ?
Écrivez, ou parlez
Vos conversations restent privées.
Ce qu'elle peut faire
```

### 032 · Ce que Présence peut faire

- Capture : `ecrans/png/032-presence-infos.png` · Maquette : `ecrans/html/presence-infos.html`
- Route : `/presence/about` · **à créer**
- Type : Standard
- Ce qu'on peut toucher :
  - « Présence » → écran 031 · Présence (/presence)
  - « Besoin d'aide » → écran 018 · Besoin d'aide (/crisis)
  - « Effacer mes conversations » → action sur place (enregistrer, appeler, lire…) : brancher sur la logique existante
- Texte de l'écran, dans l'ordre :

```text
Présence
Besoin d'aide
Ce que Présence
peut faire, ou non.
Elle peut —
Vous écouter à toute heure, vous aider à mettre des mots, expliquer un courrier, vous proposer des fleurs ou des textes, vous orienter.
Elle ne peut pas —
Remplacer un proche, un médecin ou un psychologue. En cas d'urgence, elle vous donnera toujours les bons numéros.
Vos échanges restent privés et vous pouvez les effacer à tout moment.
Effacer mes conversations
```

### 033 · Respirer

- Capture : `ecrans/png/033-respirer.png` · Maquette : `ecrans/html/respirer.html`
- Route : `/care/respirer` · **existe** · Remplace · plein écran, sans barre
- Type : Expérience plein écran (sans barre)
- Ce qu'on peut toucher :
  - « Soutien » → écran 029 · Soutien (/care)
  - « Fermer × » → écran 029 · Soutien (/care)
  - « Commencer · 3 min » → action sur place (enregistrer, appeler, lire…) : brancher sur la logique existante
- Code actuel (à réutiliser seulement pour ce qui ne change pas ; la maquette décide du reste) :
  - `src/routes/care.respirer.tsx` · logique utilisée : aucune
- Texte de l'écran, dans l'ordre :

```text
Soutien
Fermer ×
Inspirer quatre secondes,
expirer six.
Dix cycles. Vous pouvez arrêter à tout moment.
inspirez
Commencer · 3 min
```

### 034 · Sons pour s'endormir

- Capture : `ecrans/png/034-sons.png` · Maquette : `ecrans/html/sons.html`
- Route : `/care/sons` · **à créer** · Plein écran, sans barre
- Type : Expérience plein écran (sans barre)
- Ce qu'on peut toucher :
  - « Soutien » → écran 029 · Soutien (/care)
  - « Fermer × » → écran 029 · Soutien (/care)
- Texte de l'écran, dans l'ordre :

```text
Soutien
Fermer ×
Des sons
pour s'endormir.
L'écran s'éteindra tout seul à la fin.
24:10
Pluie sur le toit
45 MIN
La mer, la nuit
30 MIN
Forêt au matin
20 MIN
```

### 035 · Se poser

- Capture : `ecrans/png/035-se-poser.png` · Maquette : `ecrans/html/se-poser.html`
- Route : `/no-words` · **existe** · Remplace
- Type : Standard
- Ce qu'on peut toucher :
  - « Soutien » → écran 029 · Soutien (/care)
  - « Besoin d'aide » → écran 018 · Besoin d'aide (/crisis)
  - « Matin Bleu et vert pâle · 10 min » → écran 036 · Se poser · plein écran (/no-words · lecture)
  - « Nuit Vert profond et bleu · 20 min » → écran 036 · Se poser · plein écran (/no-words · lecture)
  - « Forêt Bruit de feuilles · 15 min » → écran 036 · Se poser · plein écran (/no-words · lecture)
- Code actuel (à réutiliser seulement pour ce qui ne change pas ; la maquette décide du reste) :
  - `src/routes/no-words.tsx` · logique utilisée : legato-state, text
- Texte de l'écran, dans l'ordre :

```text
Soutien
Besoin d'aide
Se poser,
sans lire ni parler.
Des couleurs qui changent lentement et un son très doux, pour les moments où tout est trop.
Matin
Bleu et vert pâle · 10 min
Nuit
Vert profond et bleu · 20 min
Forêt
Bruit de feuilles · 15 min
```

### 036 · Se poser · plein écran

- Capture : `ecrans/png/036-se-poser-exp.png` · Maquette : `ecrans/html/se-poser-exp.html`
- Route : `/no-words · lecture` · **existe** · Plein écran, sans barre
- Type : Expérience plein écran (sans barre)
- Ce qu'on peut toucher :
  - « Se poser » → écran 035 · Se poser (/no-words)
  - « Fermer × » → écran 035 · Se poser (/no-words)
- Code actuel (à réutiliser seulement pour ce qui ne change pas ; la maquette décide du reste) :
  - `src/routes/no-words.tsx` · logique utilisée : legato-state, text
- Texte de l'écran, dans l'ordre :

```text
Se poser
Fermer ×
Matin
9 MIN RESTANTES
```

### 037 · Écrire

- Capture : `ecrans/png/037-ecrire.png` · Maquette : `ecrans/html/ecrire.html`
- Route : `/care/journal` · **existe** · Remplace
- Type : Standard
- Ce qu'on peut toucher :
  - « Soutien » → écran 029 · Soutien (/care)
  - « Besoin d'aide » → écran 018 · Besoin d'aide (/crisis)
  - « Mon journal 14 pages · la dernière hier soir » → écran 038 · Mon journal (/care/journal · page d'écriture)
  - « Une lettre à mon amour Dire ce qui n'a pas été dit » → action sur place (enregistrer, appeler, lire…) : brancher sur la logique existante
  - « Une lettre pour plus tard Elle s'ouvrira à la date choisie » → écran 039 · Lettre pour plus tard (/care/journal/later)
  - « Ce matin, je… » → écran 038 · Mon journal (/care/journal · page d'écriture)
  - « Ce qui me manque le plus… » → écran 038 · Mon journal (/care/journal · page d'écriture)
- Code actuel (à réutiliser seulement pour ce qui ne change pas ; la maquette décide du reste) :
  - `src/routes/care.journal.tsx` · logique utilisée : legato-state, loved-name
- Texte de l'écran, dans l'ordre :

```text
Soutien
Besoin d'aide
Écrire,
sans relire.
Personne ne lit ce que vous écrivez ici. Aucune phrase n'a besoin d'être juste.
Mon journal
14 pages · la dernière hier soir
Une lettre à mon amour
Dire ce qui n'a pas été dit
Une lettre pour plus tard
Elle s'ouvrira à la date choisie
Si les mots ne viennent pas —
Ce matin, je…
Ce qui me manque le plus…
```

### 038 · Mon journal

- Capture : `ecrans/png/038-journal.png` · Maquette : `ecrans/html/journal.html`
- Route : `/care/journal · page d'écriture` · **existe** · Remplace
- Type : Standard
- Ce qu'on peut toucher :
  - « Écrire » → écran 037 · Écrire (/care/journal)
  - « Besoin d'aide » → écran 018 · Besoin d'aide (/crisis)
  - « Garder cette page » → action sur place (enregistrer, appeler, lire…) : brancher sur la logique existante
  - « Dicter plutôt » → action sur place (enregistrer, appeler, lire…) : brancher sur la logique existante
- Code actuel (à réutiliser seulement pour ce qui ne change pas ; la maquette décide du reste) :
  - `src/routes/care.journal.tsx` · logique utilisée : legato-state, loved-name
- Texte de l'écran, dans l'ordre :

```text
Écrire
Besoin d'aide
MARDI 29 SEPTEMBRE · 22 H
PAGE 15
Laissez venir les mots…
Garder cette page
Dicter plutôt
```

### 039 · Lettre pour plus tard

- Capture : `ecrans/png/039-lettre-plus-tard.png` · Maquette : `ecrans/html/lettre-plus-tard.html`
- Route : `/care/journal/later` · **à créer**
- Type : Standard
- Ce qu'on peut toucher :
  - « Écrire » → écran 037 · Écrire (/care/journal)
  - « Besoin d'aide » → écran 018 · Besoin d'aide (/crisis)
  - « Fermer la lettre jusqu'à cette date » → action sur place (enregistrer, appeler, lire…) : brancher sur la logique existante
  - champs de saisie : la valeur s'écrit en serif sur un filet
- Texte de l'écran, dans l'ordre :

```text
Écrire
Besoin d'aide
Une lettre
pour plus tard.
Elle restera fermée jusqu'à la date choisie. Vous la redécouvrirez à ce moment-là.
À OUVRIR LE
8 septembre 2027 · un an après
POUR
Moi, dans un an
Dans un an, j'espère que…
Fermer la lettre jusqu'à cette date
```

### 040 · Lire, écouter

- Capture : `ecrans/png/040-bibliotheque.png` · Maquette : `ecrans/html/bibliotheque.html`
- Route : `/care/resources et /library/$kind` · **existe** · Remplace
- Type : Standard
- Ce qu'on peut toucher :
  - « Soutien » → écran 029 · Soutien (/care)
  - « Besoin d'aide » → écran 018 · Besoin d'aide (/crisis)
  - « LIVRE · 280 PAGES L'année de la pensée magique Joan Didion » → écran 041 · Une ressource (/library/$kind · détail)
  - « LIVRE · 320 PAGES Vivre le deuil au jour le jour Christophe Fauré » → action sur place (enregistrer, appeler, lire…) : brancher sur la logique existante
  - « ARTICLE · 6 MINUTES Quand le silence de la maison pèse Rédaction Legato » → action sur place (enregistrer, appeler, lire…) : brancher sur la logique existante
- Code actuel (à réutiliser seulement pour ce qui ne change pas ; la maquette décide du reste) :
  - `src/routes/care.resources.tsx` · logique utilisée : aucune
  - `src/routes/library.$kind.tsx` · logique utilisée : aucune
- Texte de l'écran, dans l'ordre :

```text
Soutien
Besoin d'aide
Lire,
écouter.
Choisis pour la perte d'un conjoint, les premiers mois.
Lire
Écouter
Gardés
LIVRE · 280 PAGES
L'année de la pensée magique
Joan Didion
LIVRE · 320 PAGES
Vivre le deuil au jour le jour
Christophe Fauré
ARTICLE · 6 MINUTES
Quand le silence de la maison pèse
Rédaction Legato
```

### 041 · Une ressource

- Capture : `ecrans/png/041-ressource.png` · Maquette : `ecrans/html/ressource.html`
- Route : `/library/$kind · détail` · **à créer**
- Type : Standard
- Ce qu'on peut toucher :
  - « Lire, écouter » → écran 040 · Lire, écouter (/care/resources et /library/$kind)
  - « Besoin d'aide » → écran 018 · Besoin d'aide (/crisis)
  - « Garder pour plus tard » → action sur place (enregistrer, appeler, lire…) : brancher sur la logique existante
  - « Où le trouver » → action sur place (enregistrer, appeler, lire…) : brancher sur la logique existante
- Code actuel (à réutiliser seulement pour ce qui ne change pas ; la maquette décide du reste) :
  - `src/routes/library.$kind.tsx` · logique utilisée : aucune
- Texte de l'écran, dans l'ordre :

```text
Lire, écouter
Besoin d'aide
LIVRE · 280 PAGES · 2007
L'année de la
pensée magique.
Joan Didion
Le récit de l'année qui a suivi la mort de son mari. Pour ceux qui ne se reconnaissent plus dans leurs propres pensées.
POUR QUI
La perte d'un conjoint
QUAND
Les premiers mois
COMMENT
Par petits morceaux
Garder pour plus tard
Où le trouver
```

### 042 · Trouver un professionnel

- Capture : `ecrans/png/042-annuaire.png` · Maquette : `ecrans/html/annuaire.html`
- Route : `/care/help` · **existe** · Remplace
- Type : Standard
- Ce qu'on peut toucher :
  - « Soutien » → écran 029 · Soutien (/care)
  - « Besoin d'aide » → écran 018 · Besoin d'aide (/crisis)
  - « Changer » → action sur place (enregistrer, appeler, lire…) : brancher sur la logique existante
  - « Voir ses disponibilités » → écran 043 · Fiche professionnel (/resources/$category/$providerId)
  - « Voir les 8 autres résultats » → action sur place (enregistrer, appeler, lire…) : brancher sur la logique existante
- Code actuel (à réutiliser seulement pour ce qui ne change pas ; la maquette décide du reste) :
  - `src/routes/care.help.tsx` · logique utilisée : aucune
- Texte de l'écran, dans l'ordre :

```text
Soutien
Besoin d'aide
Trouver
un professionnel.
QUI
Un psychologue
Changer
OÙ
Marseille, moins de 5 km
Changer
Le plus proche —
Claire Rolland
Psychologue, spécialisée dans le deuil · 1,2 km
Prochain rendez-vous : mardi 30 septembre, 10 h
Voir ses disponibilités
Voir les 8 autres résultats
```

### 043 · Fiche professionnel

- Capture : `ecrans/png/043-fiche-pro.png` · Maquette : `ecrans/html/fiche-pro.html`
- Route : `/resources/$category/$providerId` · **existe** · Remplace
- Type : Standard
- Ce qu'on peut toucher :
  - « Résultats » → écran 042 · Trouver un professionnel (/care/help)
  - « Besoin d'aide » → écran 018 · Besoin d'aide (/crisis)
  - « Réserver mardi à 10 h » → écran 044 · Rendez-vous réservé (/resources/confirm/$providerId)
  - créneaux horaires : un appui en sélectionne un
- Code actuel (à réutiliser seulement pour ce qui ne change pas ; la maquette décide du reste) :
  - `src/routes/resources.$category.$providerId.tsx` · logique utilisée : resources-data
- Texte de l'écran, dans l'ordre :

```text
Résultats
Besoin d'aide
Claire Rolland
Psychologue, spécialisée dans le deuil depuis quinze ans.
ADRESSE
12 rue Paradis, Marseille 6e
TARIF
60 € · en partie remboursé
SÉANCE
50 minutes, cabinet ou visio
Choisir un créneau —
MARDI 30 SEPTEMBRE
10 h
11 h
14 h 30
JEUDI 2 OCTOBRE
9 h
17 h
Réserver mardi à 10 h
```

### 044 · Rendez-vous réservé

- Capture : `ecrans/png/044-rdv-confirme.png` · Maquette : `ecrans/html/rdv-confirme.html`
- Route : `/resources/confirm/$providerId` · **existe** · Remplace
- Type : Standard
- Ce qu'on peut toucher :
  - « Claire Rolland » → écran 043 · Fiche professionnel (/resources/$category/$providerId)
  - « Besoin d'aide » → écran 018 · Besoin d'aide (/crisis)
  - « Voir mes rendez-vous » → écran 045 · Vos rendez-vous (/appointments)
  - « Annuler » → action sur place (enregistrer, appeler, lire…) : brancher sur la logique existante
- Code actuel (à réutiliser seulement pour ce qui ne change pas ; la maquette décide du reste) :
  - `src/routes/resources.confirm.$providerId.tsx` · logique utilisée : resources-data
- Texte de l'écran, dans l'ordre :

```text
Claire Rolland
Besoin d'aide
C'est réservé.
Claire Rolland vous attend mardi. Vous recevrez un rappel doux la veille.
QUAND
Mardi 30 septembre, 10 h
OÙ
12 rue Paradis, Marseille 6e
IMPORTANCE
Peut être reporté
Premier rendez-vous ? Vous pouvez simplement dire que vous traversez un deuil. Le reste viendra.
Voir mes rendez-vous
Annuler
```

### 045 · Vos rendez-vous

- Capture : `ecrans/png/045-rendez-vous.png` · Maquette : `ecrans/html/rendez-vous.html`
- Route : `/appointments` · **existe** · Remplace
- Type : Standard
- Ce qu'on peut toucher :
  - « Soutien » → écran 029 · Soutien (/care)
  - « Besoin d'aide » → écran 018 · Besoin d'aide (/crisis)
  - « 30 SEPT. Claire Rolland, psychologue 10 h · 12 rue Paradis PEUT ÊTRE REPORTÉ » → action sur place (enregistrer, appeler, lire…) : brancher sur la logique existante
  - « 1 OCT. Veillée en visio 20 h · Le premier mois PEUT ÊTRE ANNULÉ » → écran 100 · Une veillée (/care/community/vigil/$id)
  - « 6 OCT. Maître Blanc, notaire 14 h 30 · ouvrir la succession À MAINTENIR » → écran 046 · Un rendez-vous (/appointments/$id)
  - « Ajouter un rendez-vous » → écran 047 · Ajouter un rendez-vous (/appointments/new)
- Code actuel (à réutiliser seulement pour ce qui ne change pas ; la maquette décide du reste) :
  - `src/routes/appointments.tsx` · logique utilisée : aucune · redirige aujourd'hui vers /practical/tasks
- Texte de l'écran, dans l'ordre :

```text
Soutien
Besoin d'aide
Vos rendez-vous.
Pour chacun, indiquez s'il peut être reporté. Si un jour vous n'êtes pas en état, Legato vous aidera.
30
SEPT.
Claire Rolland, psychologue
10 h · 12 rue Paradis
PEUT ÊTRE REPORTÉ
1
OCT.
Veillée en visio
20 h · Le premier mois
PEUT ÊTRE ANNULÉ
6
OCT.
Maître Blanc, notaire
14 h 30 · ouvrir la succession
À MAINTENIR
Ajouter un rendez-vous
```

### 046 · Un rendez-vous

- Capture : `ecrans/png/046-rdv-detail.png` · Maquette : `ecrans/html/rdv-detail.html`
- Route : `/appointments/$id` · **à créer**
- Type : Standard
- Ce qu'on peut toucher :
  - « Vos rendez-vous » → écran 045 · Vos rendez-vous (/appointments)
  - « Besoin d'aide » → écran 018 · Besoin d'aide (/crisis)
  - « Y aller accompagné Claire est libre ce jour-là » → action sur place (enregistrer, appeler, lire…) : brancher sur la logique existante
  - « Le faire en visio » → action sur place (enregistrer, appeler, lire…) : brancher sur la logique existante
  - « Le décaler d'une semaine » → action sur place (enregistrer, appeler, lire…) : brancher sur la logique existante
- Texte de l'écran, dans l'ordre :

```text
Vos rendez-vous
Besoin d'aide
LUNDI 6 OCTOBRE · 14 H 30
Maître Blanc,
notaire.
Pour ouvrir la succession, 3 cours Pierre Puget.
Ce rendez-vous compte —
Mieux vaut le garder : la succession doit être déclarée dans les six mois.
Si ce jour-là c'est trop dur —
Y aller accompagné
Claire est libre ce jour-là
Le faire en visio
Le décaler d'une semaine
```

### 047 · Ajouter un rendez-vous

- Capture : `ecrans/png/047-rdv-ajouter.png` · Maquette : `ecrans/html/rdv-ajouter.html`
- Route : `/appointments/new` · **à créer**
- Type : Standard
- Ce qu'on peut toucher :
  - « Vos rendez-vous » → écran 045 · Vos rendez-vous (/appointments)
  - « Besoin d'aide » → écran 018 · Besoin d'aide (/crisis)
  - « Enregistrer » → action sur place (enregistrer, appeler, lire…) : brancher sur la logique existante
  - cartes de réponse à sélectionner (OptionCard) : un appui sélectionne, la carte sélectionnée prend le fond lin et le point plein
  - champs de saisie : la valeur s'écrit en serif sur un filet
- Texte de l'écran, dans l'ordre :

```text
Vos rendez-vous
Besoin d'aide
Ajouter
un rendez-vous.
AVEC QUI
Maître Blanc, notaire
QUAND
Lundi 6 octobre, 14 h 30
SI VOUS N'ÊTES PAS EN ÉTAT CE JOUR-LÀ
À maintenir
Legato vous proposera de vous faire accompagner
Peut être reporté
Un message prêt pour décaler
Peut être annulé
Sans conséquence
Enregistrer
```

### 048 · Le corps

- Capture : `ecrans/png/048-corps.png` · Maquette : `ecrans/html/corps.html`
- Route : `/help/corps` · **existe** · Remplace
- Type : Standard
- Ce qu'on peut toucher :
  - « Soutien » → écran 029 · Soutien (/care)
  - « Besoin d'aide » → écran 018 · Besoin d'aide (/crisis)
  - « 1 Dormir Quand le sommeil ne vient pas » → écran 049 · Dormir (/help/corps/nuits)
  - « 2 Manger Même peu, même sans faim » → écran 050 · Manger (/help/corps/manger)
  - « 3 Se laver Une douche, ou juste le visage » → écran 051 · Se laver (/help/corps/eau)
  - « 4 S'habiller Sortir du pyjama, sans effort » → écran 052 · S'habiller (/help/corps/habiller)
  - « 5 Un moment de soin Dix minutes pour vous » → écran 107 · Un moment de soin (/help/corps/soin)
- Code actuel (à réutiliser seulement pour ce qui ne change pas ; la maquette décide du reste) :
  - `src/routes/help.corps.tsx` · logique utilisée : aucune
- Texte de l'écran, dans l'ordre :

```text
Soutien
Besoin d'aide
Prendre soin
de votre corps.
En deuil, on oublie souvent de dormir, de manger, de se laver. Choisissez un seul sujet.
1
Dormir
Quand le sommeil ne vient pas
2
Manger
Même peu, même sans faim
3
Se laver
Une douche, ou juste le visage
4
S'habiller
Sortir du pyjama, sans effort
5
Un moment de soin
Dix minutes pour vous
```

### 049 · Dormir

- Capture : `ecrans/png/049-corps-dormir.png` · Maquette : `ecrans/html/corps-dormir.html`
- Route : `/help/corps/nuits` · **existe** · Remplace
- Type : Standard
- Ce qu'on peut toucher :
  - « Le corps » → écran 048 · Le corps (/help/corps)
  - « Besoin d'aide » → écran 018 · Besoin d'aide (/crisis)
  - « Faire l'exercice guidé » → écran 054 · Exercice guidé (/help/corps/soin/$id)
  - « Écouter, lire, en parler » → écran 053 · Dormir · contenus (/help/corps/nuits/contenus)
- Code actuel (à réutiliser seulement pour ce qui ne change pas ; la maquette décide du reste) :
  - `src/routes/help.corps.nuits.tsx` · logique utilisée : aucune
- Texte de l'écran, dans l'ordre :

```text
Le corps
Besoin d'aide
Quand le sommeil
ne vient pas.
Mal dormir est très fréquent les premières semaines. Ce n'est pas un échec.
Ce qui aide —
1
Gardez la même heure de lever, même après une mauvaise nuit.
2
Pas de sommeil après vingt minutes ? Levez-vous un moment, puis revenez.
3
Si cela dure plus de deux semaines, parlez-en à votre médecin.
Faire l'exercice guidé
Écouter, lire, en parler
```

### 050 · Manger

- Capture : `ecrans/png/050-corps-manger.png` · Maquette : `ecrans/html/corps-manger.html`
- Route : `/help/corps/manger` · **existe** · Remplace
- Type : Standard
- Ce qu'on peut toucher :
  - « Le corps » → écran 048 · Le corps (/help/corps)
  - « Besoin d'aide » → écran 018 · Besoin d'aide (/crisis)
  - « Faire l'exercice guidé » → écran 054 · Exercice guidé (/help/corps/soin/$id)
  - « Écouter, lire, en parler » → écran 053 · Dormir · contenus (/help/corps/nuits/contenus)
- Code actuel (à réutiliser seulement pour ce qui ne change pas ; la maquette décide du reste) :
  - `src/routes/help.corps.manger.tsx` · logique utilisée : aucune
- Texte de l'écran, dans l'ordre :

```text
Le corps
Besoin d'aide
Manger,
même un peu.
L'appétit disparaît souvent avec le chagrin.
Ce qui aide —
1
Mangez peu mais souvent : une soupe, un yaourt, une banane.
2
Gardez près de vous des aliments qui ne demandent aucune préparation.
3
Si vous ne mangez presque plus depuis plusieurs jours, consultez votre médecin.
Faire l'exercice guidé
Écouter, lire, en parler
```

### 051 · Se laver

- Capture : `ecrans/png/051-corps-laver.png` · Maquette : `ecrans/html/corps-laver.html`
- Route : `/help/corps/eau` · **existe** · Remplace
- Type : Standard
- Ce qu'on peut toucher :
  - « Le corps » → écran 048 · Le corps (/help/corps)
  - « Besoin d'aide » → écran 018 · Besoin d'aide (/crisis)
  - « Faire l'exercice guidé » → écran 054 · Exercice guidé (/help/corps/soin/$id)
  - « Écouter, lire, en parler » → écran 053 · Dormir · contenus (/help/corps/nuits/contenus)
- Code actuel (à réutiliser seulement pour ce qui ne change pas ; la maquette décide du reste) :
  - `src/routes/help.corps.eau.tsx` · logique utilisée : aucune
- Texte de l'écran, dans l'ordre :

```text
Le corps
Besoin d'aide
Se laver,
un geste à la fois.
Une douche peut sembler impossible. On peut commencer beaucoup plus petit.
Ce qui aide —
1
De l'eau sur le visage et les mains, c'est déjà prendre soin de soi.
2
Préparez une serviette et des vêtements propres avant d'entrer.
3
Une douche de deux minutes compte autant qu'une longue.
Faire l'exercice guidé
Écouter, lire, en parler
```

### 052 · S'habiller

- Capture : `ecrans/png/052-corps-habiller.png` · Maquette : `ecrans/html/corps-habiller.html`
- Route : `/help/corps/habiller` · **existe** · Remplace
- Type : Standard
- Ce qu'on peut toucher :
  - « Le corps » → écran 048 · Le corps (/help/corps)
  - « Besoin d'aide » → écran 018 · Besoin d'aide (/crisis)
  - « Faire l'exercice guidé » → écran 054 · Exercice guidé (/help/corps/soin/$id)
  - « Écouter, lire, en parler » → écran 053 · Dormir · contenus (/help/corps/nuits/contenus)
- Code actuel (à réutiliser seulement pour ce qui ne change pas ; la maquette décide du reste) :
  - `src/routes/help.corps.habiller.tsx` · logique utilisée : aucune
- Texte de l'écran, dans l'ordre :

```text
Le corps
Besoin d'aide
S'habiller,
sans y penser.
Choisir des vêtements demande de l'énergie. On peut s'en épargner une partie.
Ce qui aide —
1
Préparez vos vêtements la veille au soir.
2
Choisissez ce qui est confortable, pas ce qui est beau.
3
Sortez cinq minutes, même avec un manteau sur le pyjama.
Faire l'exercice guidé
Écouter, lire, en parler
```

### 053 · Dormir · contenus

- Capture : `ecrans/png/053-corps-ressources.png` · Maquette : `ecrans/html/corps-ressources.html`
- Route : `/help/corps/nuits/contenus` · **à créer** · Même modèle pour chaque sujet
- Type : Standard
- Ce qu'on peut toucher :
  - « Dormir » → écran 049 · Dormir (/help/corps/nuits)
  - « Besoin d'aide » → écran 018 · Besoin d'aide (/crisis)
  - « ÉCOUTER Des sons pour s'endormir Pluie, mer, forêt · 20 à 45 minutes » → écran 034 · Sons pour s'endormir (/care/sons)
  - « LIRE Pourquoi le chagrin empêche de dormir Article · 5 minutes » → écran 041 · Une ressource (/library/$kind · détail)
  - « EN PARLER Groupe « Les nuits difficiles » 120 membres · modéré » → écran 096 · Un groupe (/care/community/$group)
- Texte de l'écran, dans l'ordre :

```text
Dormir
Besoin d'aide
Dormir :
écouter, lire, en parler.
Des contenus choisis pour les nuits difficiles. Prenez seulement ce qui vous fait du bien.
ÉCOUTER
Des sons pour s'endormir
Pluie, mer, forêt · 20 à 45 minutes
LIRE
Pourquoi le chagrin empêche de dormir
Article · 5 minutes
EN PARLER
Groupe « Les nuits difficiles »
120 membres · modéré
```

### 054 · Exercice guidé

- Capture : `ecrans/png/054-corps-etape.png` · Maquette : `ecrans/html/corps-etape.html`
- Route : `/help/corps/soin/$id` · **existe** · Remplace · plein écran, sans barre
- Type : Expérience plein écran (sans barre)
- Ce qu'on peut toucher :
  - « Dormir » → écran 049 · Dormir (/help/corps/nuits)
  - « Fermer × » → écran 049 · Dormir (/help/corps/nuits)
  - « C'est fait » → action sur place (enregistrer, appeler, lire…) : brancher sur la logique existante
  - « Arrêter » → écran 049 · Dormir (/help/corps/nuits)
- Code actuel (à réutiliser seulement pour ce qui ne change pas ; la maquette décide du reste) :
  - `src/routes/help.corps.soin.$id.tsx` · logique utilisée : self-care
- Texte de l'écran, dans l'ordre :

```text
Dormir
Fermer ×
Éteignez les écrans,
baissez la lumière.
Prenez le temps qu'il faut.
C'est fait
Arrêter
```

### 107 · Un moment de soin

- Capture : `ecrans/png/107-corps-soin.png` · Maquette : `ecrans/html/corps-soin.html`
- Route : `/help/corps/soin` · **à créer**
- Type : Standard
- Ce qu'on peut toucher :
  - « Le corps » → écran 048 · Le corps (/help/corps)
  - « Besoin d'aide » → écran 018 · Besoin d'aide (/crisis)
  - « 1 Les mains Une crème, lentement · 3 min » → écran 054 · Exercice guidé (/help/corps/soin/$id)
  - « 2 Le visage De l'eau tiède, une serviette chaude · 3 min » → écran 054 · Exercice guidé (/help/corps/soin/$id)
  - « 3 Les épaules Relâcher la tension · 4 min » → écran 054 · Exercice guidé (/help/corps/soin/$id)
- Texte de l'écran, dans l'ordre :

```text
Le corps
Besoin d'aide
Un moment
pour vous.
Dix minutes de soin, guidées pas à pas. Choisissez par où commencer.
1
Les mains
Une crème, lentement · 3 min
2
Le visage
De l'eau tiède, une serviette chaude · 3 min
3
Les épaules
Relâcher la tension · 4 min
```


---

## Démarches

### 055 · Démarches

- Capture : `ecrans/png/055-demarches.png` · Maquette : `ecrans/html/demarches.html`
- Route : `/practical (et /practical/tasks)` · **existe** · Remplace
- Type : Standard
- Ce qu'on peut toucher :
  - « Besoin d'aide » → écran 018 · Besoin d'aide (/crisis)
  - « Mon avancement » → écran 057 · Mon avancement (/practical/progress)
  - « 1 Commander l'acte de décès 10 min · avant vendredi 25 » → écran 056 · Une démarche (/practical/tasks/$id (et /parcours/$taskId))
  - « 2 Prévenir la banque 15 min · modèle de courrier prêt » → écran 061 · Modèle de courrier (/practical/tasks/$id/template)
  - « 1 Prévenir la caisse de retraite 20 min · en ligne » → action sur place (enregistrer, appeler, lire…) : brancher sur la logique existante
  - « Mes documents Il manque l'acte de décès » → écran 059 · Mes documents (/practical/vault)
  - « Un courrier à comprendre ? Photographiez-le » → écran 060 · Un courrier expliqué (/practical/letter)
- Code actuel (à réutiliser seulement pour ce qui ne change pas ; la maquette décide du reste) :
  - `src/routes/practical.tsx` · logique utilisée : aucune
  - `src/routes/practical.tasks.tsx` · logique utilisée : aucune
- Texte de l'écran, dans l'ordre :

```text
Démarches
Besoin d'aide
Ce qu'il reste
à faire.
3/8
Mon avancement
Cette semaine —
1
Commander l'acte de décès
10 min · avant vendredi 25
2
Prévenir la banque
15 min · modèle de courrier prêt
Ce mois-ci —
1
Prévenir la caisse de retraite
20 min · en ligne
Mes documents
Il manque l'acte de décès
Un courrier à comprendre ? Photographiez-le
```

### 056 · Une démarche

- Capture : `ecrans/png/056-une-demarche.png` · Maquette : `ecrans/html/une-demarche.html`
- Route : `/practical/tasks/$id (et /parcours/$taskId)` · **existe** · Remplace
- Type : Standard
- Ce qu'on peut toucher :
  - « Démarches » → écran 055 · Démarches (/practical (et /practical/tasks))
  - « Besoin d'aide » → écran 018 · Besoin d'aide (/crisis)
  - « Faire la demande en ligne » → action sur place (enregistrer, appeler, lire…) : brancher sur la logique existante
  - « Confier à un proche » → écran 062 · Confier à un proche (/practical/share/$taskId)
- Code actuel (à réutiliser seulement pour ce qui ne change pas ; la maquette décide du reste) :
  - `src/routes/practical.tasks.$id.tsx` · logique utilisée : journey-config, legato-state, task-guides, task-status, task-steps
  - `src/routes/parcours.$taskId.tsx` · logique utilisée : aucune · redirige aujourd'hui vers /practical/tasks/$id
- Texte de l'écran, dans l'ordre :

```text
Démarches
Besoin d'aide
AVANT LE VENDREDI 25 SEPTEMBRE
Commander l'acte
de décès.
AUPRÈS DE
Mairie du lieu de décès
COMBIEN
10 copies, gratuites
DURÉE
10 minutes
Les étapes · 1 sur 3 —
Trouver la mairie du lieu de décès
Demander l'acte, sur place ou en ligne
Ranger les copies dans Mes documents
Faire la demande en ligne
Confier à un proche
```

### 057 · Mon avancement

- Capture : `ecrans/png/057-avancement.png` · Maquette : `ecrans/html/avancement.html`
- Route : `/practical/progress` · **à créer**
- Type : Standard
- Ce qu'on peut toucher :
  - « Démarches » → écran 055 · Démarches (/practical (et /practical/tasks))
  - « Besoin d'aide » → écran 018 · Besoin d'aide (/crisis)
  - « Ouvrir la prochaine démarche » → écran 056 · Une démarche (/practical/tasks/$id (et /parcours/$taskId))
  - « Confier une démarche à un proche » → écran 062 · Confier à un proche (/practical/share/$taskId)
- Texte de l'écran, dans l'ordre :

```text
Démarches
Besoin d'aide
Vous avancez,
à votre rythme.
Trois démarches faites sur huit. Rien ne presse avant vendredi.
3 / 8
CETTE SEMAINE
1 sur 2
CE MOIS-CI
2 sur 4
PLUS TARD
0 sur 2
Ouvrir la prochaine démarche
Confier une démarche à un proche
```

### 058 · Les grandes étapes

- Capture : `ecrans/png/058-etapes.png` · Maquette : `ecrans/html/etapes.html`
- Route : `/practical/steps` · **existe** · Remplace
- Type : Standard
- Ce qu'on peut toucher :
  - « Démarches » → écran 055 · Démarches (/practical (et /practical/tasks))
  - « Besoin d'aide » → écran 018 · Besoin d'aide (/crisis)
  - « Voir les démarches en cours » → écran 055 · Démarches (/practical (et /practical/tasks))
  - « Repères, expliqués simplement » → écran 064 · Repères (/practical/resources)
- Code actuel (à réutiliser seulement pour ce qui ne change pas ; la maquette décide du reste) :
  - `src/routes/practical.steps.tsx` · logique utilisée : aucune · redirige aujourd'hui vers /practical/tasks
- Texte de l'écran, dans l'ordre :

```text
Démarches
Besoin d'aide
Les grandes étapes.
Tout le parcours en un coup d'œil.
Les premiers jours
Déclarer le décès, organiser les obsèques
Les premières semaines
Banque, employeur, organismes
VOUS ÊTES ICI
Les premiers mois
Logement, assurances, impôts
La succession
Avec le notaire, dans les six mois
Voir les démarches en cours
Repères, expliqués simplement
```

### 059 · Mes documents

- Capture : `ecrans/png/059-documents.png` · Maquette : `ecrans/html/documents.html`
- Route : `/practical/vault` · **existe** · Remplace
- Type : Standard
- Ce qu'on peut toucher :
  - « Démarches » → écran 055 · Démarches (/practical (et /practical/tasks))
  - « Besoin d'aide » → écran 018 · Besoin d'aide (/crisis)
  - « Ajouter ce document » → action sur place (enregistrer, appeler, lire…) : brancher sur la logique existante
  - « Identité et état civil 3 » → action sur place (enregistrer, appeler, lire…) : brancher sur la logique existante
  - « Banque 2 » → action sur place (enregistrer, appeler, lire…) : brancher sur la logique existante
  - « Logement 1 » → action sur place (enregistrer, appeler, lire…) : brancher sur la logique existante
  - « Assurances 2 » → action sur place (enregistrer, appeler, lire…) : brancher sur la logique existante
  - « Volontés 1 » → action sur place (enregistrer, appeler, lire…) : brancher sur la logique existante
- Code actuel (à réutiliser seulement pour ce qui ne change pas ; la maquette décide du reste) :
  - `src/routes/practical.vault.tsx` · logique utilisée : legato-state
- Texte de l'écran, dans l'ordre :

```text
Démarches
Besoin d'aide
Vos papiers,
au même endroit.
Il manque —
L'acte de décès
La banque et le notaire vous le demanderont.
Ajouter ce document
Identité et état civil
3
Banque
2
Logement
1
Assurances
2
Volontés
1
```

### 060 · Un courrier expliqué

- Capture : `ecrans/png/060-courrier.png` · Maquette : `ecrans/html/courrier.html`
- Route : `/practical/letter` · **à créer** · Résultat d'une photo de courrier analysée par Présence
- Type : Standard
- Ce qu'on peut toucher :
  - « Démarches » → écran 055 · Démarches (/practical (et /practical/tasks))
  - « Besoin d'aide » → écran 018 · Besoin d'aide (/crisis)
  - « Ajouter à mes démarches » → action sur place (enregistrer, appeler, lire…) : brancher sur la logique existante
  - « Poser une question » → écran 031 · Présence (/presence)
- Texte de l'écran, dans l'ordre :

```text
Démarches
Besoin d'aide
COURRIER PHOTOGRAPHIÉ · BANQUE
Ce que dit ce courrier.
La banque a bloqué le compte joint, comme c'est l'usage après un décès. Elle vous demande l'acte de décès pour le rouvrir à votre nom.
À FAIRE
Envoyer l'acte de décès
AVANT
Le 15 octobre
URGENT ?
Non, rien ne sera prélevé
Ajouter à mes démarches
Poser une question
```

### 061 · Modèle de courrier

- Capture : `ecrans/png/061-modele-courrier.png` · Maquette : `ecrans/html/modele-courrier.html`
- Route : `/practical/tasks/$id/template` · **à créer**
- Type : Standard
- Ce qu'on peut toucher :
  - « Démarches » → écran 055 · Démarches (/practical (et /practical/tasks))
  - « Besoin d'aide » → écran 018 · Besoin d'aide (/crisis)
  - « Envoyer par e-mail » → action sur place (enregistrer, appeler, lire…) : brancher sur la logique existante
  - « Télécharger en PDF » → action sur place (enregistrer, appeler, lire…) : brancher sur la logique existante
- Texte de l'écran, dans l'ordre :

```text
Démarches
Besoin d'aide
MODÈLE DE COURRIER · PRÊT À ENVOYER
Prévenir la banque.
Madame, Monsieur,
J'ai le regret de vous informer du décès de Anne Martin, survenu le 8 septembre 2026, titulaire du compte n° …
Vous trouverez ci-joint l'acte de décès…
Les passages surlignés sont remplis pour vous. Vérifiez-les avant d'envoyer.
Envoyer par e-mail
Télécharger en PDF
```

### 062 · Confier à un proche

- Capture : `ecrans/png/062-confier-demarche.png` · Maquette : `ecrans/html/confier-demarche.html`
- Route : `/practical/share/$taskId` · **à créer**
- Type : Standard
- Ce qu'on peut toucher :
  - « Une démarche » → écran 056 · Une démarche (/practical/tasks/$id (et /parcours/$taskId))
  - « Besoin d'aide » → écran 018 · Besoin d'aide (/crisis)
  - « Envoyer à Claire » → action sur place (enregistrer, appeler, lire…) : brancher sur la logique existante
  - « Ajouter quelqu'un » → action sur place (enregistrer, appeler, lire…) : brancher sur la logique existante
- Texte de l'écran, dans l'ordre :

```text
Une démarche
Besoin d'aide
Confier cette démarche
à un proche.
Il reçoit un message avec les étapes. Vous voyez quand c'est fait.
Claire
Votre sœur
CHOISIE
P
Paul
Un ami
MESSAGE ENVOYÉ À CLAIRE
« Pourrais-tu commander l'acte de décès à la mairie ? Tout est expliqué ici. Merci. »
Envoyer à Claire
Ajouter quelqu'un
```

### 063 · Envoyer vos choix

- Capture : `ecrans/png/063-envoyer-choix.png` · Maquette : `ecrans/html/envoyer-choix.html`
- Route : `/practical/share` · **existe** · Remplace
- Type : Standard
- Ce qu'on peut toucher :
  - « Démarches » → écran 055 · Démarches (/practical (et /practical/tasks))
  - « Besoin d'aide » → écran 018 · Besoin d'aide (/crisis)
  - « Pompes funèbres Vos choix, pour préparer le devis ENVOYÉ » → action sur place (enregistrer, appeler, lire…) : brancher sur la logique existante
  - « Officiant Le déroulé et les textes » → action sur place (enregistrer, appeler, lire…) : brancher sur la logique existante
  - « Fleuriste La proposition de fleurs » → action sur place (enregistrer, appeler, lire…) : brancher sur la logique existante
  - « Vos proches La date, le lieu, le déroulé » → action sur place (enregistrer, appeler, lire…) : brancher sur la logique existante
- Code actuel (à réutiliser seulement pour ce qui ne change pas ; la maquette décide du reste) :
  - `src/routes/practical.share.tsx` · logique utilisée : practical-store
- Texte de l'écran, dans l'ordre :

```text
Démarches
Besoin d'aide
Envoyer vos choix
aux bonnes personnes.
Legato prépare un message clair pour chacun, avec vos choix en pièce jointe. Vous relisez avant d'envoyer.
Pompes funèbres
Vos choix, pour préparer le devis
ENVOYÉ
Officiant
Le déroulé et les textes
Fleuriste
La proposition de fleurs
Vos proches
La date, le lieu, le déroulé
```

### 064 · Repères

- Capture : `ecrans/png/064-reperes.png` · Maquette : `ecrans/html/reperes.html`
- Route : `/practical/resources` · **existe** · Remplace
- Type : Standard
- Ce qu'on peut toucher :
  - « Démarches » → écran 055 · Démarches (/practical (et /practical/tasks))
  - « Besoin d'aide » → écran 018 · Besoin d'aide (/crisis)
  - « La succession Le rôle du notaire, les délais, les frais » → action sur place (enregistrer, appeler, lire…) : brancher sur la logique existante
  - « La banque Comptes bloqués, comptes joints » → action sur place (enregistrer, appeler, lire…) : brancher sur la logique existante
  - « Les assurances Assurance-vie, mutuelle, résiliations » → action sur place (enregistrer, appeler, lire…) : brancher sur la logique existante
  - « L'employeur Salaire dû, capital décès » → action sur place (enregistrer, appeler, lire…) : brancher sur la logique existante
  - « Aides et droits Pension de réversion, aides possibles » → action sur place (enregistrer, appeler, lire…) : brancher sur la logique existante
- Code actuel (à réutiliser seulement pour ce qui ne change pas ; la maquette décide du reste) :
  - `src/routes/practical.resources.tsx` · logique utilisée : aucune
- Texte de l'écran, dans l'ordre :

```text
Démarches
Besoin d'aide
Repères,
expliqués simplement.
Ce qu'il faut savoir avant chaque démarche.
La succession
Le rôle du notaire, les délais, les frais
La banque
Comptes bloqués, comptes joints
Les assurances
Assurance-vie, mutuelle, résiliations
L'employeur
Salaire dû, capital décès
Aides et droits
Pension de réversion, aides possibles
```

### 065 · Les professionnels

- Capture : `ecrans/png/065-pros.png` · Maquette : `ecrans/html/pros.html`
- Route : `/practical/pros` · **existe** · Remplace
- Type : Standard
- Ce qu'on peut toucher :
  - « Démarches » → écran 055 · Démarches (/practical (et /practical/tasks))
  - « Besoin d'aide » → écran 018 · Besoin d'aide (/crisis)
  - « 1 Pompes funèbres Dans les 24 à 48 heures » → écran 068 · Pompes funèbres (/resources/$category)
  - « 2 Officiant Avant la cérémonie » → action sur place (enregistrer, appeler, lire…) : brancher sur la logique existante
  - « 3 Fleuriste Trois ou quatre jours avant » → écran 071 · Choisir les fleurs (/practical/flowers)
  - « 4 Marbrier Après les obsèques, sans urgence » → action sur place (enregistrer, appeler, lire…) : brancher sur la logique existante
  - « 5 Notaire Dans le premier mois » → écran 066 · Le notaire (/practical/pros/$kind)
- Code actuel (à réutiliser seulement pour ce qui ne change pas ; la maquette décide du reste) :
  - `src/routes/practical.pros.tsx` · logique utilisée : resources-data
- Texte de l'écran, dans l'ordre :

```text
Démarches
Besoin d'aide
Les professionnels
et quand les appeler.
Dans l'ordre où vous en aurez besoin.
1
Pompes funèbres
Dans les 24 à 48 heures
2
Officiant
Avant la cérémonie
3
Fleuriste
Trois ou quatre jours avant
4
Marbrier
Après les obsèques, sans urgence
5
Notaire
Dans le premier mois
```

### 066 · Le notaire

- Capture : `ecrans/png/066-pro-guide.png` · Maquette : `ecrans/html/pro-guide.html`
- Route : `/practical/pros/$kind` · **à créer** · Fiche « quand l'appeler »
- Type : Standard
- Ce qu'on peut toucher :
  - « Les professionnels » → écran 065 · Les professionnels (/practical/pros)
  - « Besoin d'aide » → écran 018 · Besoin d'aide (/crisis)
  - « Trouver un notaire près de chez vous » → action sur place (enregistrer, appeler, lire…) : brancher sur la logique existante
- Texte de l'écran, dans l'ordre :

```text
Les professionnels
Besoin d'aide
À APPELER DANS LE PREMIER MOIS
Le notaire.
Il règle la succession : ce qui revient à chacun, les comptes, le logement.
Ce qu'il faut lui demander —
1
Le montant de ses honoraires.
2
Le délai pour la déclaration de succession.
3
Les documents à réunir avant le rendez-vous.
Trouver un notaire près de chez vous
```

### 067 · Organiser la cérémonie

- Capture : `ecrans/png/067-ceremonie.png` · Maquette : `ecrans/html/ceremonie.html`
- Route : `/practical/ceremony` · **existe** · Remplace
- Type : Standard
- Ce qu'on peut toucher :
  - « Démarches » → écran 055 · Démarches (/practical (et /practical/tasks))
  - « Besoin d'aide » → écran 018 · Besoin d'aide (/crisis)
  - « Continuer : le lieu et la date » → action sur place (enregistrer, appeler, lire…) : brancher sur la logique existante
- Code actuel (à réutiliser seulement pour ce qui ne change pas ; la maquette décide du reste) :
  - `src/routes/practical.ceremony.tsx` · logique utilisée : ceremony-ai.functions, ceremony-suggest, legato-state, loved-name, portrait-store, practical-store
- Texte de l'écran, dans l'ordre :

```text
Démarches
Besoin d'aide
Organiser
la cérémonie.
Les décisions à prendre, dans l'ordre. Rien ne vous oblige à tout faire vous-même.
Les décisions · 2 sur 5 —
Choisir les pompes funèbres
Inhumation ou crémation
Le lieu et la date
Les détails : fleurs, textes, musique
Prévenir les proches
Continuer : le lieu et la date
```

### 068 · Pompes funèbres

- Capture : `ecrans/png/068-pompes-funebres.png` · Maquette : `ecrans/html/pompes-funebres.html`
- Route : `/resources/$category` · **existe** · Remplace
- Type : Standard
- Ce qu'on peut toucher :
  - « La cérémonie » → écran 067 · Organiser la cérémonie (/practical/ceremony)
  - « Besoin d'aide » → écran 018 · Besoin d'aide (/crisis)
  - « Pompes funèbres du Prado 1,4 km · ouvert 7 jours sur 7 2 950 € DEVIS » → écran 069 · Un prestataire (/resources/$category/$providerId)
  - « Maison Rinaldi 2,6 km · entreprise familiale 3 180 € DEVIS » → action sur place (enregistrer, appeler, lire…) : brancher sur la logique existante
  - « Roc-Eclerc Castellane 3,1 km 3 400 € DEVIS » → action sur place (enregistrer, appeler, lire…) : brancher sur la logique existante
- Code actuel (à réutiliser seulement pour ce qui ne change pas ; la maquette décide du reste) :
  - `src/routes/resources.$category.tsx` · logique utilisée : resources-data
- Texte de l'écran, dans l'ordre :

```text
La cérémonie
Besoin d'aide
Pompes funèbres
près de chez vous.
Les prix viennent des devis publiés. Comparez sans vous presser.
Pompes funèbres du Prado
1,4 km · ouvert 7 jours sur 7
2 950 €
DEVIS
Maison Rinaldi
2,6 km · entreprise familiale
3 180 €
DEVIS
Roc-Eclerc Castellane
3,1 km
3 400 €
DEVIS
Crémation simple à Marseille : 3 200 € en moyenne.
```

### 069 · Un prestataire

- Capture : `ecrans/png/069-prestataire.png` · Maquette : `ecrans/html/prestataire.html`
- Route : `/resources/$category/$providerId` · **existe** · Remplace
- Type : Standard
- Ce qu'on peut toucher :
  - « Pompes funèbres » → écran 068 · Pompes funèbres (/resources/$category)
  - « Besoin d'aide » → écran 018 · Besoin d'aide (/crisis)
  - « Demander ce devis » → action sur place (enregistrer, appeler, lire…) : brancher sur la logique existante
  - « Appeler » → action sur place (enregistrer, appeler, lire…) : brancher sur la logique existante
- Code actuel (à réutiliser seulement pour ce qui ne change pas ; la maquette décide du reste) :
  - `src/routes/resources.$category.$providerId.tsx` · logique utilisée : resources-data
- Texte de l'écran, dans l'ordre :

```text
Pompes funèbres
Besoin d'aide
POMPES FUNÈBRES · 1,4 KM
Pompes funèbres
du Prado.
HORAIRES
7 jours sur 7, 8 h – 19 h
ADRESSE
82 avenue du Prado
SE DÉPLACE
À domicile, à l'hôpital
Total estimé —
2 950 €
Crémation simple, cercueil en bois clair, urne en céramique, sans cérémonie religieuse.
Demander ce devis
Appeler
```

### 070 · Les détails de la cérémonie

- Capture : `ecrans/png/070-details-ceremonie.png` · Maquette : `ecrans/html/details-ceremonie.html`
- Route : `/practical/atmosphere` · **existe** · Remplace
- Type : Standard
- Ce qu'on peut toucher :
  - « La cérémonie » → écran 067 · Organiser la cérémonie (/practical/ceremony)
  - « Besoin d'aide » → écran 018 · Besoin d'aide (/crisis)
  - « 1 Les fleurs Décrire, ou répondre à trois questions CHOISIES » → écran 071 · Choisir les fleurs (/practical/flowers)
  - « 2 Textes et musique Des propositions qui lui ressemblent » → écran 074 · Textes et musique (/practical/texts)
  - « 3 Cercueil, urne, plaque Les options et leur prix moyen » → écran 076 · Cercueil, urne, plaque (/practical/objects)
  - « 4 Le livret Sa photo et le déroulé, à imprimer » → écran 077 · Le livret (/practical/booklet)
  - « Envoyer mes choix » → écran 063 · Envoyer vos choix (/practical/share)
- Code actuel (à réutiliser seulement pour ce qui ne change pas ; la maquette décide du reste) :
  - `src/routes/practical.atmosphere.tsx` · logique utilisée : aucune
- Texte de l'écran, dans l'ordre :

```text
La cérémonie
Besoin d'aide
Les détails
de la cérémonie.
Présence peut vous faire des propositions à partir de ce que vous lui dites d'elle.
1
Les fleurs
Décrire, ou répondre à trois questions
CHOISIES
2
Textes et musique
Des propositions qui lui ressemblent
3
Cercueil, urne, plaque
Les options et leur prix moyen
4
Le livret
Sa photo et le déroulé, à imprimer
Envoyer mes choix
```

### 071 · Choisir les fleurs

- Capture : `ecrans/png/071-fleurs.png` · Maquette : `ecrans/html/fleurs.html`
- Route : `/practical/flowers` · **existe** · Remplace
- Type : Standard
- Ce qu'on peut toucher :
  - « Les détails » → écran 070 · Les détails de la cérémonie (/practical/atmosphere)
  - « Besoin d'aide » → écran 018 · Besoin d'aide (/crisis)
  - « Voir la proposition » → écran 073 · Fleurs · proposition (/practical/flowers · proposition)
  - « Répondre aux questions » → écran 072 · Fleurs · questions (/practical/flowers · questions)
- Code actuel (à réutiliser seulement pour ce qui ne change pas ; la maquette décide du reste) :
  - `src/routes/practical.flowers.tsx` · logique utilisée : practical-store
- Texte de l'écran, dans l'ordre :

```text
Les détails
Besoin d'aide
Choisir les fleurs.
Décrivez ce que vous imaginez, avec vos mots. Présence vous proposera une composition à montrer au fleuriste.
Des fleurs simples, blanches et vertes, comme dans son jardin…
Voir la proposition
Vous ne savez pas quoi imaginer ? Répondez à trois questions, Présence s'occupe du reste.
Répondre aux questions
```

### 072 · Fleurs · questions

- Capture : `ecrans/png/072-fleurs-questions.png` · Maquette : `ecrans/html/fleurs-questions.html`
- Route : `/practical/flowers · questions` · **existe** · Questionnaire
- Type : Questionnaire / entrée (sans barre)
- Ce qu'on peut toucher :
  - « Choisir les fleurs » → écran 071 · Choisir les fleurs (/practical/flowers)
  - « Besoin d'aide » → écran 018 · Besoin d'aide (/crisis)
  - « Continuer » → action sur place (enregistrer, appeler, lire…) : brancher sur la logique existante
  - « Passer cette étape » → action sur place (enregistrer, appeler, lire…) : brancher sur la logique existante
  - cartes de réponse à sélectionner (OptionCard) : un appui sélectionne, la carte sélectionnée prend le fond lin et le point plein
- Code actuel (à réutiliser seulement pour ce qui ne change pas ; la maquette décide du reste) :
  - `src/routes/practical.flowers.tsx` · logique utilisée : practical-store
- Texte de l'écran, dans l'ordre :

```text
Choisir les fleurs
Besoin d'aide
Quelles couleurs
lui ressemblent ?
Une seule réponse. Présence s'adaptera à la saison.
Blanc et vert
Sobre, lumineux
Tons chauds
Orange, rouge, jaune
Tons doux
Rose pâle, mauve, crème
Je ne sais pas
Présence choisira des fleurs de saison
Continuer
Passer cette étape
```

### 073 · Fleurs · proposition

- Capture : `ecrans/png/073-fleurs-proposition.png` · Maquette : `ecrans/html/fleurs-proposition.html`
- Route : `/practical/flowers · proposition` · **existe** · Résultat généré par l'IA
- Type : Standard
- Ce qu'on peut toucher :
  - « Choisir les fleurs » → écran 071 · Choisir les fleurs (/practical/flowers)
  - « Besoin d'aide » → écran 018 · Besoin d'aide (/crisis)
  - « Envoyer au fleuriste » → action sur place (enregistrer, appeler, lire…) : brancher sur la logique existante
  - « Modifier » → écran 071 · Choisir les fleurs (/practical/flowers)
- Code actuel (à réutiliser seulement pour ce qui ne change pas ; la maquette décide du reste) :
  - `src/routes/practical.flowers.tsx` · logique utilisée : practical-store
- Texte de l'écran, dans l'ordre :

```text
Choisir les fleurs
Besoin d'aide
PROPOSITION DE PRÉSENCE
Un bouquet blanc et vert,
simple et posé.
Des roses blanches, de l'eucalyptus et quelques branches d'olivier, en rappel de son jardin. Une forme basse, posée devant le cercueil.
FLEURS
Roses, eucalyptus, olivier
FORME
Bouquet bas, 60 cm
PRIX ESTIMÉ
120 à 180 €
Envoyer au fleuriste
Modifier
```

### 074 · Textes et musique

- Capture : `ecrans/png/074-textes.png` · Maquette : `ecrans/html/textes.html`
- Route : `/practical/texts` · **existe** · Remplace
- Type : Standard
- Ce qu'on peut toucher :
  - « Les détails » → écran 070 · Les détails de la cérémonie (/practical/atmosphere)
  - « Besoin d'aide » → écran 018 · Besoin d'aide (/crisis)
  - « Voir les propositions » → écran 075 · Textes · propositions (/practical/texts · propositions)
- Code actuel (à réutiliser seulement pour ce qui ne change pas ; la maquette décide du reste) :
  - `src/routes/practical.texts.tsx` · logique utilisée : aucune
- Texte de l'écran, dans l'ordre :

```text
Les détails
Besoin d'aide
Choisir les textes
et la musique.
Parlez-nous d'elle : ce qu'elle aimait, ce qui la faisait rire. Présence vous proposera des lectures et des morceaux qui lui ressemblent.
Elle aimait la mer, Barbara, les poèmes appris à l'école…
Voir les propositions
Vous préférez écrire votre propre texte ? Présence peut vous aider à le commencer.
```

### 075 · Textes · propositions

- Capture : `ecrans/png/075-textes-proposition.png` · Maquette : `ecrans/html/textes-proposition.html`
- Route : `/practical/texts · propositions` · **existe** · Résultat généré par l'IA
- Type : Standard
- Ce qu'on peut toucher :
  - « Textes et musique » → écran 074 · Textes et musique (/practical/texts)
  - « Besoin d'aide » → écran 018 · Besoin d'aide (/crisis)
- Code actuel (à réutiliser seulement pour ce qui ne change pas ; la maquette décide du reste) :
  - `src/routes/practical.texts.tsx` · logique utilisée : aucune
- Texte de l'écran, dans l'ordre :

```text
Textes et musique
Besoin d'aide
PROPOSITIONS DE PRÉSENCE
Pour Anne.
Lectures —
Demain, dès l'aube
Victor Hugo · elle aimait les poèmes appris à l'école
1 MIN
Garder
Un texte sur la mer
Court, sur l'absence
1 MIN
Garder
Musiques —
Ma plus belle histoire d'amour
Barbara · pour l'entrée
4 MIN
Garder
Une pièce au piano
Pour le moment de silence
3 MIN
Garder
```

### 076 · Cercueil, urne, plaque

- Capture : `ecrans/png/076-objets.png` · Maquette : `ecrans/html/objets.html`
- Route : `/practical/objects` · **existe** · Remplace
- Type : Standard
- Ce qu'on peut toucher :
  - « Les détails » → écran 070 · Les détails de la cérémonie (/practical/atmosphere)
  - « Besoin d'aide » → écran 018 · Besoin d'aide (/crisis)
  - « Bois clair, lignes simples Cercueil · 800 à 1 200 € CHOISI » → action sur place (enregistrer, appeler, lire…) : brancher sur la logique existante
  - « Bois noble, finitions soignées Cercueil · 1 500 à 3 000 € » → action sur place (enregistrer, appeler, lire…) : brancher sur la logique existante
  - « Urne en céramique ou biodégradable 150 à 400 € » → action sur place (enregistrer, appeler, lire…) : brancher sur la logique existante
  - « Plaque en granit ou lave émaillée 200 à 600 € » → action sur place (enregistrer, appeler, lire…) : brancher sur la logique existante
- Code actuel (à réutiliser seulement pour ce qui ne change pas ; la maquette décide du reste) :
  - `src/routes/practical.objects.tsx` · logique utilisée : aucune
- Texte de l'écran, dans l'ordre :

```text
Les détails
Besoin d'aide
Cercueil, urne,
plaque.
Les principales options et leur prix moyen, pour arriver préparé chez les pompes funèbres.
Bois clair, lignes simples
Cercueil · 800 à 1 200 €
CHOISI
Bois noble, finitions soignées
Cercueil · 1 500 à 3 000 €
Urne en céramique ou biodégradable
150 à 400 €
Plaque en granit ou lave émaillée
200 à 600 €
Rien n'est à payer ici. Ces choix servent seulement à préparer le devis.
```

### 077 · Le livret

- Capture : `ecrans/png/077-livret.png` · Maquette : `ecrans/html/livret.html`
- Route : `/practical/booklet` · **existe** · Remplace
- Type : Standard
- Ce qu'on peut toucher :
  - « Les détails » → écran 070 · Les détails de la cérémonie (/practical/atmosphere)
  - « Besoin d'aide » → écran 018 · Besoin d'aide (/crisis)
  - « La photo Choisie dans ses souvenirs CHOISIE » → action sur place (enregistrer, appeler, lire…) : brancher sur la logique existante
  - « Le déroulé Accueil, textes, musique, hommage » → action sur place (enregistrer, appeler, lire…) : brancher sur la logique existante
  - « Télécharger le livret » → action sur place (enregistrer, appeler, lire…) : brancher sur la logique existante
  - « Imprimer » → action sur place (enregistrer, appeler, lire…) : brancher sur la logique existante
- Code actuel (à réutiliser seulement pour ce qui ne change pas ; la maquette décide du reste) :
  - `src/routes/practical.booklet.tsx` · logique utilisée : practical-store
- Texte de l'écran, dans l'ordre :

```text
Les détails
Besoin d'aide
Le livret
de la cérémonie.
Une feuille pliée avec sa photo, le déroulé et un texte. À imprimer ou à envoyer.
Anne Martin
1958 – 2026
La photo
Choisie dans ses souvenirs
CHOISIE
Le déroulé
Accueil, textes, musique, hommage
Télécharger le livret
Imprimer
```

### 078 · Volontés

- Capture : `ecrans/png/078-volontes.png` · Maquette : `ecrans/html/volontes.html`
- Route : `/practical/wishes (et /wishes)` · **existe** · Remplace
- Type : Standard
- Ce qu'on peut toucher :
  - « Mes documents » → écran 059 · Mes documents (/practical/vault)
  - « Besoin d'aide » → écran 018 · Besoin d'aide (/crisis)
  - « 1 Obsèques Inhumation, crémation, cérémonie » → écran 079 · Volontés · obsèques (/practical/wishes · obsèques)
  - « 2 Don d'organes et du corps Ce qui a été exprimé » → action sur place (enregistrer, appeler, lire…) : brancher sur la logique existante
  - « 3 Messages à transmettre Lettres pour des proches » → action sur place (enregistrer, appeler, lire…) : brancher sur la logique existante
  - « 4 Qui prévenir Une liste de personnes » → action sur place (enregistrer, appeler, lire…) : brancher sur la logique existante
  - « Choisir cette personne » → action sur place (enregistrer, appeler, lire…) : brancher sur la logique existante
- Code actuel (à réutiliser seulement pour ce qui ne change pas ; la maquette décide du reste) :
  - `src/routes/practical.wishes.tsx` · logique utilisée : legato-state
  - `src/routes/wishes.tsx` · logique utilisée : legato-state · redirige aujourd'hui vers /practical/wishes
- Texte de l'écran, dans l'ordre :

```text
Mes documents
Besoin d'aide
Ses volontés,
ou les vôtres.
Rangées au même endroit, partagées seulement si vous le décidez.
1
Obsèques
Inhumation, crémation, cérémonie
2
Don d'organes et du corps
Ce qui a été exprimé
3
Messages à transmettre
Lettres pour des proches
4
Qui prévenir
Une liste de personnes
Vous pouvez désigner une personne de confiance qui y aura accès.
Choisir cette personne
```

### 079 · Volontés · obsèques

- Capture : `ecrans/png/079-volontes-obseques.png` · Maquette : `ecrans/html/volontes-obseques.html`
- Route : `/practical/wishes · obsèques` · **existe** · Questionnaire
- Type : Questionnaire / entrée (sans barre)
- Ce qu'on peut toucher :
  - « Volontés » → écran 078 · Volontés (/practical/wishes (et /wishes))
  - « Besoin d'aide » → écran 018 · Besoin d'aide (/crisis)
  - « Continuer » → action sur place (enregistrer, appeler, lire…) : brancher sur la logique existante
  - « Passer cette étape » → action sur place (enregistrer, appeler, lire…) : brancher sur la logique existante
  - cartes de réponse à sélectionner (OptionCard) : un appui sélectionne, la carte sélectionnée prend le fond lin et le point plein
  - champs de saisie : la valeur s'écrit en serif sur un filet
- Code actuel (à réutiliser seulement pour ce qui ne change pas ; la maquette décide du reste) :
  - `src/routes/practical.wishes.tsx` · logique utilisée : legato-state
- Texte de l'écran, dans l'ordre :

```text
Volontés
Besoin d'aide
Pour les obsèques.
Ce que vous souhaitez, ou ce qu'elle avait exprimé.
Crémation
Les cendres dispersées en mer
Inhumation
Dans le caveau familial
Je ne sais pas encore
Les proches choisiront
UN SOUHAIT DE PLUS · FACULTATIF
Une chanson, un lieu, une couleur…
Continuer
Passer cette étape
```


---

## Mémoire

### 080 · Mémoire

- Capture : `ecrans/png/080-memoire.png` · Maquette : `ecrans/html/memoire.html`
- Route : `/care/garden/space` · **à créer** · Page d'une parcelle : s'ouvre quand on touche une parcelle du jardin peint (/care/garden, à conserver)
- Type : Standard
- Ce qu'on peut toucher :
  - « Besoin d'aide » → écran 018 · Besoin d'aide (/crisis)
  - « Son portrait » → écran 087 · Son portrait (/profile/portrait)
  - « Un livre souvenir » → écran 089 · Un livre souvenir (/care/garden/book)
  - « DERNIER SOUVENIR · PHOTO Le dimanche à Cassis « Elle voulait toujours rester jusqu'au coucher du soleil. » » → écran 082 · Un souvenir (/care/garden/$zone/$id)
  - « Tous ses souvenirs Photos, voix, lettres, lieux » → écran 081 · Tous ses souvenirs (/care/garden/all)
  - « Un geste pour elle Une bougie, une lanterne » → écran 090 · Un geste pour elle (/care/rituels)
  - « Son anniversaire, le 3 octobre » → écran 091 · Son anniversaire (/care/dates/$id)
  - « Ajouter un souvenir » → écran 085 · Ajouter un souvenir (/care/garden/depot)
- Code actuel (à réutiliser seulement pour ce qui ne change pas) : `src/routes/care.garden.index.tsx` (choix de la parcelle, `setActiveSpaceId`) et `src/lib/memories-store.ts`
- Texte de l'écran, dans l'ordre :

```text
Mémoire
Besoin d'aide
Le jardin
de mon amour.
Douze souvenirs gardés. Le dernier, hier.
Son portrait
Un livre souvenir
DERNIER SOUVENIR · PHOTO
Le dimanche à Cassis
« Elle voulait toujours rester jusqu'au coucher du soleil. »
Tous ses souvenirs
Photos, voix, lettres, lieux
Un geste pour elle
Une bougie, une lanterne
Son anniversaire, le 3 octobre
Ajouter un souvenir
```

### 081 · Tous ses souvenirs

- Capture : `ecrans/png/081-souvenirs.png` · Maquette : `ecrans/html/souvenirs.html`
- Route : `/care/garden/all` · **à créer** · Liste de tous les souvenirs
- Type : Standard
- Ce qu'on peut toucher :
  - « Mémoire » → écran 080 · Mémoire (/care/garden/space)
  - « Besoin d'aide » → écran 018 · Besoin d'aide (/crisis)
  - « Photos » → écran 108 · Ses photos (/care/garden/$zone (photos))
  - « Sa voix » → écran 083 · Sa voix (/care/garden/$zone (voix))
  - « Lettres » → écran 084 · Lettres et mots (/care/garden/$zone (lettres))
  - « Lieux » → écran 109 · Les lieux (/care/garden/$zone (lieux))
  - « Le dimanche à Cassis Photo · juillet 2024 » → écran 082 · Un souvenir (/care/garden/$zone/$id)
  - « Sa voix, au téléphone Message vocal · 42 secondes » → écran 083 · Sa voix (/care/garden/$zone (voix))
  - « « Tu verras, ça ira » Une phrase qu'elle disait » → écran 084 · Lettres et mots (/care/garden/$zone (lettres))
  - « Lisbonne Photo · 2019 » → action sur place (enregistrer, appeler, lire…) : brancher sur la logique existante
  - « Ajouter un souvenir » → écran 085 · Ajouter un souvenir (/care/garden/depot)
- Texte de l'écran, dans l'ordre :

```text
Mémoire
Besoin d'aide
Tous ses
souvenirs.
Du plus récent au plus ancien.
Photos
Sa voix
Lettres
Lieux
Le dimanche à Cassis
Photo · juillet 2024
Sa voix, au téléphone
Message vocal · 42 secondes
« Tu verras, ça ira »
Une phrase qu'elle disait
Lisbonne
Photo · 2019
Ajouter un souvenir
```

### 082 · Un souvenir

- Capture : `ecrans/png/082-souvenir.png` · Maquette : `ecrans/html/souvenir.html`
- Route : `/care/garden/$zone/$id` · **à créer** · Détail d'un souvenir
- Type : Standard
- Ce qu'on peut toucher :
  - « Tous ses souvenirs » → écran 081 · Tous ses souvenirs (/care/garden/all)
  - « Besoin d'aide » → écran 018 · Besoin d'aide (/crisis)
  - « Ajouter un mot » → action sur place (enregistrer, appeler, lire…) : brancher sur la logique existante
  - « Partager avec un proche » → action sur place (enregistrer, appeler, lire…) : brancher sur la logique existante
- Texte de l'écran, dans l'ordre :

```text
Tous ses souvenirs
Besoin d'aide
PHOTO
JUILLET 2024 · AJOUTÉE HIER
Le dimanche à Cassis.
« Elle voulait toujours rester jusqu'au coucher du soleil. »
Ajouter un mot
Partager avec un proche
```

### 108 · Ses photos

- Capture : `ecrans/png/108-photos.png` · Maquette : `ecrans/html/photos.html`
- Route : `/care/garden/$zone (photos)` · **existe** · Remplace
- Type : Standard
- Ce qu'on peut toucher :
  - « Tous ses souvenirs » → écran 081 · Tous ses souvenirs (/care/garden/all)
  - « Besoin d'aide » → écran 018 · Besoin d'aide (/crisis)
  - « Ajouter une photo » → écran 086 · Composer un souvenir (/compose/$zone)
- Code actuel (à réutiliser seulement pour ce qui ne change pas ; la maquette décide du reste) :
  - `src/routes/care.garden.$zone.tsx` · logique utilisée : loved-name, memories-store
- Texte de l'écran, dans l'ordre :

```text
Tous ses souvenirs
Besoin d'aide
Ses photos.
Touchez une photo pour ajouter la date, le lieu ou un mot.
Cassis · 2024
Notre mariage · 2011
Le jardin · 2023
Lisbonne · 2019
Ajouter une photo
```

### 083 · Sa voix

- Capture : `ecrans/png/083-voix.png` · Maquette : `ecrans/html/voix.html`
- Route : `/care/garden/$zone (voix)` · **existe** · Remplace
- Type : Standard
- Ce qu'on peut toucher :
  - « Tous ses souvenirs » → écran 081 · Tous ses souvenirs (/care/garden/all)
  - « Besoin d'aide » → écran 018 · Besoin d'aide (/crisis)
  - « Ajouter un mot » → action sur place (enregistrer, appeler, lire…) : brancher sur la logique existante
  - « Garder hors connexion » → action sur place (enregistrer, appeler, lire…) : brancher sur la logique existante
- Code actuel (à réutiliser seulement pour ce qui ne change pas ; la maquette décide du reste) :
  - `src/routes/care.garden.$zone.tsx` · logique utilisée : loved-name, memories-store
- Texte de l'écran, dans l'ordre :

```text
Tous ses souvenirs
Besoin d'aide
MESSAGE VOCAL · MARS 2026
Sa voix,
au téléphone.
0:14
0:42
« Je rentre vers sept heures, garde-moi une part. »
Ajouter un mot
Garder hors connexion
```

### 084 · Lettres et mots

- Capture : `ecrans/png/084-lettres.png` · Maquette : `ecrans/html/lettres.html`
- Route : `/care/garden/$zone (lettres)` · **existe** · Remplace
- Type : Standard
- Ce qu'on peut toucher :
  - « Tous ses souvenirs » → écran 081 · Tous ses souvenirs (/care/garden/all)
  - « Besoin d'aide » → écran 018 · Besoin d'aide (/crisis)
  - « Ajouter un mot » → écran 086 · Composer un souvenir (/compose/$zone)
- Code actuel (à réutiliser seulement pour ce qui ne change pas ; la maquette décide du reste) :
  - `src/routes/care.garden.$zone.tsx` · logique utilisée : loved-name, memories-store
- Texte de l'écran, dans l'ordre :

```text
Tous ses souvenirs
Besoin d'aide
Lettres et mots.
Ses phrases, les vôtres, celles de vos proches.
UNE PHRASE QU'ELLE DISAIT
SOUVENT
« Tu verras, ça ira. »
UN MESSAGE
MARS 2026
« Garde-moi une part, je rentre vers sept heures. »
ÉCRIT PAR CLAIRE
HIER
« Elle riait toujours la première. »
Ajouter un mot
```

### 109 · Les lieux

- Capture : `ecrans/png/109-lieux.png` · Maquette : `ecrans/html/lieux.html`
- Route : `/care/garden/$zone (lieux)` · **existe** · Remplace
- Type : Standard
- Ce qu'on peut toucher :
  - « Tous ses souvenirs » → écran 081 · Tous ses souvenirs (/care/garden/all)
  - « Besoin d'aide » → écran 018 · Besoin d'aide (/crisis)
  - « La calanque de Port-Miou Cassis · ses dimanches d'été ↗ » → action sur place (enregistrer, appeler, lire…) : brancher sur la logique existante
  - « Le marché du Prado Marseille · chaque samedi matin ↗ » → action sur place (enregistrer, appeler, lire…) : brancher sur la logique existante
  - « Le Miradouro da Graça Lisbonne · leur voyage de 2019 ↗ » → action sur place (enregistrer, appeler, lire…) : brancher sur la logique existante
  - « Ajouter un lieu » → action sur place (enregistrer, appeler, lire…) : brancher sur la logique existante
- Code actuel (à réutiliser seulement pour ce qui ne change pas ; la maquette décide du reste) :
  - `src/routes/care.garden.$zone.tsx` · logique utilisée : loved-name, memories-store
- Texte de l'écran, dans l'ordre :

```text
Tous ses souvenirs
Besoin d'aide
Les lieux
qui comptent.
Là où elle aimait aller. Vous pourrez y retourner, ou simplement vous en souvenir.
La calanque de Port-Miou
Cassis · ses dimanches d'été
↗
Le marché du Prado
Marseille · chaque samedi matin
↗
Le Miradouro da Graça
Lisbonne · leur voyage de 2019
↗
Ajouter un lieu
```

### 085 · Ajouter un souvenir

- Capture : `ecrans/png/085-ajouter.png` · Maquette : `ecrans/html/ajouter.html`
- Route : `/care/garden/depot` · **existe** · Remplace
- Type : Standard
- Ce qu'on peut toucher :
  - « Mémoire » → écran 080 · Mémoire (/care/garden/space)
  - « Besoin d'aide » → écran 018 · Besoin d'aide (/crisis)
  - « 1 Une photo Depuis votre téléphone » → écran 086 · Composer un souvenir (/compose/$zone)
  - « 2 Sa voix Un message, un enregistrement » → action sur place (enregistrer, appeler, lire…) : brancher sur la logique existante
  - « 3 Un texte Une phrase qu'elle disait, une lettre » → action sur place (enregistrer, appeler, lire…) : brancher sur la logique existante
  - « 4 Un lieu Un endroit qui compte » → action sur place (enregistrer, appeler, lire…) : brancher sur la logique existante
  - « Les inviter » → écran 088 · Inviter des proches (/care/garden/invite)
- Code actuel (à réutiliser seulement pour ce qui ne change pas ; la maquette décide du reste) :
  - `src/routes/care.garden.depot.tsx` · logique utilisée : loved-name, memories-store
- Texte de l'écran, dans l'ordre :

```text
Mémoire
Besoin d'aide
Que voulez-vous
garder ?
Un souvenir peut être très simple : une phrase, un son, une image.
1
Une photo
Depuis votre téléphone
2
Sa voix
Un message, un enregistrement
3
Un texte
Une phrase qu'elle disait, une lettre
4
Un lieu
Un endroit qui compte
Vos proches peuvent aussi ajouter leurs souvenirs. Les inviter
```

### 086 · Composer un souvenir

- Capture : `ecrans/png/086-composer.png` · Maquette : `ecrans/html/composer.html`
- Route : `/compose/$zone` · **existe** · Remplace
- Type : Standard
- Ce qu'on peut toucher :
  - « Ajouter un souvenir » → écran 085 · Ajouter un souvenir (/care/garden/depot)
  - « Besoin d'aide » → écran 018 · Besoin d'aide (/crisis)
  - « Garder ce souvenir » → action sur place (enregistrer, appeler, lire…) : brancher sur la logique existante
  - champs de saisie : la valeur s'écrit en serif sur un filet
- Code actuel (à réutiliser seulement pour ce qui ne change pas ; la maquette décide du reste) :
  - `src/routes/compose.$zone.tsx` · logique utilisée : elements, legato-state, memories-store
- Texte de l'écran, dans l'ordre :

```text
Ajouter un souvenir
Besoin d'aide
Une photo.
Choisir une photo
UN TITRE
Le dimanche à Cassis
QUAND
Juillet 2024
QUELQUES MOTS · FACULTATIF
Ce que vous voulez garder de ce moment…
Garder ce souvenir
```

### 087 · Son portrait

- Capture : `ecrans/png/087-portrait.png` · Maquette : `ecrans/html/portrait.html`
- Route : `/profile/portrait` · **existe** · Remplace
- Type : Standard
- Ce qu'on peut toucher :
  - « Mémoire » → écran 080 · Mémoire (/care/garden/space)
  - « Besoin d'aide » → écran 018 · Besoin d'aide (/crisis)
  - « Modifier son portrait Ce que vous voulez que Legato sache » → action sur place (enregistrer, appeler, lire…) : brancher sur la logique existante
  - « Dates importantes Anniversaire le 3 octobre » → écran 015 · Les jours qui viennent (/agenda)
- Code actuel (à réutiliser seulement pour ce qui ne change pas ; la maquette décide du reste) :
  - `src/routes/profile.portrait.tsx` · logique utilisée : loved-name, portrait-store
- Texte de l'écran, dans l'ordre :

```text
Mémoire
Besoin d'aide
Anne, mon amour.
1958 – 2026 · VOTRE ÉPOUSE
Ce que Legato retient d'elle —
Elle aimait la mer à Cassis, les dimanches lents, le clafoutis de sa mère.
Modifier son portrait
Ce que vous voulez que Legato sache
Dates importantes
Anniversaire le 3 octobre
```

### 088 · Inviter des proches

- Capture : `ecrans/png/088-inviter.png` · Maquette : `ecrans/html/inviter.html`
- Route : `/care/garden/invite` · **à créer**
- Type : Standard
- Ce qu'on peut toucher :
  - « Mémoire » → écran 080 · Mémoire (/care/garden/space)
  - « Besoin d'aide » → écran 018 · Besoin d'aide (/crisis)
  - « Claire Votre sœur · a ajouté 2 souvenirs INVITÉE » → action sur place (enregistrer, appeler, lire…) : brancher sur la logique existante
  - « Paul Un ami · pas encore répondu EN ATTENTE » → action sur place (enregistrer, appeler, lire…) : brancher sur la logique existante
  - « Inviter quelqu'un » → action sur place (enregistrer, appeler, lire…) : brancher sur la logique existante
- Texte de l'écran, dans l'ordre :

```text
Mémoire
Besoin d'aide
Inviter des proches
à se souvenir.
Ils pourront ajouter leurs photos et leurs mots. Vous choisissez ce qui reste visible.
Claire
Votre sœur · a ajouté 2 souvenirs
INVITÉE
Paul
Un ami · pas encore répondu
EN ATTENTE
Inviter quelqu'un
Rien n'est publié sans votre accord. Vous pouvez retirer un souvenir à tout moment.
```

### 089 · Un livre souvenir

- Capture : `ecrans/png/089-livre.png` · Maquette : `ecrans/html/livre.html`
- Route : `/care/garden/book` · **à créer**
- Type : Standard
- Ce qu'on peut toucher :
  - « Mémoire » → écran 080 · Mémoire (/care/garden/space)
  - « Besoin d'aide » → écran 018 · Besoin d'aide (/crisis)
  - « Choisir les souvenirs » → action sur place (enregistrer, appeler, lire…) : brancher sur la logique existante
  - « Voir l'aperçu » → action sur place (enregistrer, appeler, lire…) : brancher sur la logique existante
- Texte de l'écran, dans l'ordre :

```text
Mémoire
Besoin d'aide
Un livre
pour elle.
Ses souvenirs, rassemblés dans un livre imprimé.
LEGATO
Mon amour
2026
CONTENU
12 souvenirs, 32 pages
FORMAT
21 × 21 cm, couverture rigide
PRIX
À partir de 29 €
Choisir les souvenirs
Voir l'aperçu
```

### 090 · Un geste pour elle

- Capture : `ecrans/png/090-gestes.png` · Maquette : `ecrans/html/gestes.html`
- Route : `/care/rituels` · **existe** · Remplace
- Type : Standard
- Ce qu'on peut toucher :
  - « Mémoire » → écran 080 · Mémoire (/care/garden/space)
  - « Besoin d'aide » → écran 018 · Besoin d'aide (/crisis)
  - « 1 Allumer une bougie Elle reste allumée jusqu'au lendemain » → écran 092 · Une bougie (/care/rituels/candle)
  - « 2 Une lanterne sur l'eau Quelques mots qui s'éloignent » → écran 094 · Une lanterne (/care/rituels/lantern)
  - « 3 Une bougie de 24 heures Pour un anniversaire, une date » → écran 092 · Une bougie (/care/rituels/candle)
  - « 4 Une petite offrande Une fleur, un objet, une photo » → écran 110 · Une offrande (/care/rituels/offering)
- Code actuel (à réutiliser seulement pour ce qui ne change pas ; la maquette décide du reste) :
  - `src/routes/care.rituels.tsx` · logique utilisée : legato-state, loved-name, portrait-store, rituals.functions
- Texte de l'écran, dans l'ordre :

```text
Mémoire
Besoin d'aide
Un geste
pour elle.
Un petit rituel, seul ou avec vos proches. Il reste visible dans son jardin de souvenirs.
1
Allumer une bougie
Elle reste allumée jusqu'au lendemain
2
Une lanterne sur l'eau
Quelques mots qui s'éloignent
3
Une bougie de 24 heures
Pour un anniversaire, une date
4
Une petite offrande
Une fleur, un objet, une photo
```

### 091 · Son anniversaire

- Capture : `ecrans/png/091-anniversaire.png` · Maquette : `ecrans/html/anniversaire.html`
- Route : `/care/dates/$id` · **à créer**
- Type : Standard
- Ce qu'on peut toucher :
  - « Mémoire » → écran 080 · Mémoire (/care/garden/space)
  - « Besoin d'aide » → écran 018 · Besoin d'aide (/crisis)
  - « 1 Un moment seul Un lieu, une musique, une lettre » → action sur place (enregistrer, appeler, lire…) : brancher sur la logique existante
  - « 2 Avec des proches Inviter quelques personnes, simplement » → action sur place (enregistrer, appeler, lire…) : brancher sur la logique existante
  - « 3 Un geste pour elle Des fleurs, une bougie, un don » → écran 090 · Un geste pour elle (/care/rituels)
  - « 4 Laisser passer ce jour Legato ne vous le rappellera pas » → action sur place (enregistrer, appeler, lire…) : brancher sur la logique existante
- Texte de l'écran, dans l'ordre :

```text
Mémoire
Besoin d'aide
SAMEDI 3 OCTOBRE · DANS 9 JOURS
Son anniversaire.
Que voulez-vous faire ?
Rien n'est obligatoire. Certaines personnes préfèrent laisser passer la journée.
1
Un moment seul
Un lieu, une musique, une lettre
2
Avec des proches
Inviter quelques personnes, simplement
3
Un geste pour elle
Des fleurs, une bougie, un don
4
Laisser passer ce jour
Legato ne vous le rappellera pas
```

### 092 · Une bougie

- Capture : `ecrans/png/092-bougie.png` · Maquette : `ecrans/html/bougie.html`
- Route : `/care/rituels/candle` · **à créer** · Plein écran, sans barre
- Type : Expérience plein écran (sans barre)
- Ce qu'on peut toucher :
  - « Un geste » → écran 090 · Un geste pour elle (/care/rituels)
  - « Fermer × » → écran 090 · Un geste pour elle (/care/rituels)
  - « Allumer la bougie » → écran 093 · Une bougie · quelques mots (/care/rituels/candle · mots)
- Texte de l'écran, dans l'ordre :

```text
Un geste
Fermer ×
Une bougie
pour mon amour.
Elle reste allumée jusqu'à demain matin, dans son jardin de souvenirs.
Allumer la bougie
Vous pourrez ajouter quelques mots ensuite
```

### 093 · Une bougie · quelques mots

- Capture : `ecrans/png/093-bougie-mots.png` · Maquette : `ecrans/html/bougie-mots.html`
- Route : `/care/rituels/candle · mots` · **à créer** · Plein écran, sans barre
- Type : Expérience plein écran (sans barre)
- Ce qu'on peut toucher :
  - « Un geste » → écran 090 · Un geste pour elle (/care/rituels)
  - « Fermer × » → écran 090 · Un geste pour elle (/care/rituels)
  - « Garder ces mots » → écran 080 · Mémoire (/care/garden/space)
  - « Non merci » → écran 080 · Mémoire (/care/garden/space)
- Texte de l'écran, dans l'ordre :

```text
Un geste
Fermer ×
BOUGIE ALLUMÉE · 21 H 40
Quelques mots
pour elle ?
Ce soir, j'ai repensé à…
Garder ces mots
Non merci
```

### 094 · Une lanterne

- Capture : `ecrans/png/094-lanterne.png` · Maquette : `ecrans/html/lanterne.html`
- Route : `/care/rituels/lantern` · **à créer** · Plein écran, sans barre
- Type : Expérience plein écran (sans barre)
- Ce qu'on peut toucher :
  - « Un geste » → écran 090 · Un geste pour elle (/care/rituels)
  - « Fermer × » → écran 090 · Un geste pour elle (/care/rituels)
  - « Laisser partir la lanterne » → action sur place (enregistrer, appeler, lire…) : brancher sur la logique existante
- Texte de l'écran, dans l'ordre :

```text
Un geste
Fermer ×
Une lanterne
sur l'eau.
Écrivez-lui quelques mots, puis laissez la lanterne s'éloigner.
Ce soir, je voulais te dire…
Laisser partir la lanterne
```

### 110 · Une offrande

- Capture : `ecrans/png/110-offrande.png` · Maquette : `ecrans/html/offrande.html`
- Route : `/care/rituels/offering` · **à créer**
- Type : Questionnaire / entrée (sans barre)
- Ce qu'on peut toucher :
  - « Un geste pour elle » → écran 090 · Un geste pour elle (/care/rituels)
  - « Besoin d'aide » → écran 018 · Besoin d'aide (/crisis)
  - « Déposer dans son jardin » → écran 080 · Mémoire (/care/garden/space)
  - cartes de réponse à sélectionner (OptionCard) : un appui sélectionne, la carte sélectionnée prend le fond lin et le point plein
- Texte de l'écran, dans l'ordre :

```text
Un geste pour elle
Besoin d'aide
Que voulez-vous
déposer pour elle ?
Elle restera visible dans son jardin de souvenirs.
Une fleur
Choisie parmi ses préférées
Un objet
Une photo de quelque chose qui lui ressemble
Quelques mots
Une phrase, juste pour elle
Déposer dans son jardin
```


---

## Communauté

### 095 · Communauté

- Capture : `ecrans/png/095-communaute.png` · Maquette : `ecrans/html/communaute.html`
- Route : `/care/community` · **existe** · Remplace
- Type : Standard
- Ce qu'on peut toucher :
  - « Besoin d'aide » → écran 018 · Besoin d'aide (/crisis)
  - « Perte d'un conjoint 3 nouveaux messages » → écran 096 · Un groupe (/care/community/$group)
  - « Les premiers mois Pas de nouveau message » → action sur place (enregistrer, appeler, lire…) : brancher sur la logique existante
  - « Trouver un autre groupe » → écran 098 · Trouver un groupe (/care/community/groups)
  - « Voir la veillée » → écran 100 · Une veillée (/care/community/vigil/$id)
- Code actuel (à réutiliser seulement pour ce qui ne change pas ; la maquette décide du reste) :
  - `src/routes/care.community.tsx` · logique utilisée : aucune
- Texte de l'écran, dans l'ordre :

```text
Communauté
Besoin d'aide
Parler avec d'autres
personnes en deuil.
Groupes modérés. Un pseudonyme suffit.
Mes groupes —
Perte d'un conjoint
3 nouveaux messages
Les premiers mois
Pas de nouveau message
Trouver un autre groupe
Prochaine veillée —
JEUDI · 20 H
Le premier mois, en parler ensemble
Voir la veillée
```

### 098 · Trouver un groupe

- Capture : `ecrans/png/098-trouver-groupe.png` · Maquette : `ecrans/html/trouver-groupe.html`
- Route : `/care/community/groups` · **à créer**
- Type : Standard
- Ce qu'on peut toucher :
  - « Communauté » → écran 095 · Communauté (/care/community)
  - « Besoin d'aide » → écran 018 · Besoin d'aide (/crisis)
  - « Perte d'un conjoint 48 membres · très actif » → action sur place (enregistrer, appeler, lire…) : brancher sur la logique existante
  - « Perte d'un parent 112 membres » → action sur place (enregistrer, appeler, lire…) : brancher sur la logique existante
  - « Perte d'un enfant 36 membres · avec une psychologue » → action sur place (enregistrer, appeler, lire…) : brancher sur la logique existante
  - « Après un suicide 22 membres · avec une psychologue » → action sur place (enregistrer, appeler, lire…) : brancher sur la logique existante
  - « Aidants d'un proche malade 57 membres » → action sur place (enregistrer, appeler, lire…) : brancher sur la logique existante
- Texte de l'écran, dans l'ordre :

```text
Communauté
Besoin d'aide
Trouver
un groupe.
Des personnes qui vivent quelque chose de proche. Tous les groupes sont modérés.
Perte d'un conjoint
48 membres · très actif
Perte d'un parent
112 membres
Perte d'un enfant
36 membres · avec une psychologue
Après un suicide
22 membres · avec une psychologue
Aidants d'un proche malade
57 membres
```

### 096 · Un groupe

- Capture : `ecrans/png/096-groupe.png` · Maquette : `ecrans/html/groupe.html`
- Route : `/care/community/$group` · **existe** · Remplace
- Type : Standard
- Ce qu'on peut toucher :
  - « Communauté » → écran 095 · Communauté (/care/community)
  - « Besoin d'aide » → écran 018 · Besoin d'aide (/crisis)
  - « HÉLÈNE IL Y A 1 H Le plus dur, ce sont les dimanches. Comment les traversez-vous ? Répondre Je pense à vous » → écran 097 · Une conversation (/care/community/$group/$thread)
  - « MARC IL Y A 3 H Trois mois aujourd'hui. J'ai rouvert son atelier pour la première fois. Répondre Je pense à vous » → action sur place (enregistrer, appeler, lire…) : brancher sur la logique existante
  - « Écrire au groupe Publier » → écran 111 · Écrire au groupe (/care/community/$group/new)
  - « Les règles du groupe » → écran 099 · Les règles du groupe (/care/community/regles)
- Code actuel (à réutiliser seulement pour ce qui ne change pas ; la maquette décide du reste) :
  - `src/routes/care.community.$group.index.tsx` · logique utilisée : community-data, community-store
- Texte de l'écran, dans l'ordre :

```text
Communauté
Besoin d'aide
Perte d'un conjoint
Groupe modéré · 48 membres · vous écrivez en tant que « V. »
HÉLÈNE
IL Y A 1 H
Le plus dur, ce sont les dimanches. Comment les traversez-vous ?
Répondre
Je pense à vous
MARC
IL Y A 3 H
Trois mois aujourd'hui. J'ai rouvert son atelier pour la première fois.
Répondre
Je pense à vous
Écrire au groupe
Publier
Les règles du groupe
```

### 097 · Une conversation

- Capture : `ecrans/png/097-fil.png` · Maquette : `ecrans/html/fil.html`
- Route : `/care/community/$group/$thread` · **existe** · Remplace
- Type : Standard
- Ce qu'on peut toucher :
  - « Perte d'un conjoint » → écran 096 · Un groupe (/care/community/$group)
  - « Besoin d'aide » → écran 018 · Besoin d'aide (/crisis)
  - « Répondre à Hélène Envoyer » → écran 111 · Écrire au groupe (/care/community/$group/new)
- Code actuel (à réutiliser seulement pour ce qui ne change pas ; la maquette décide du reste) :
  - `src/routes/care.community.$group.$thread.tsx` · logique utilisée : community-data, community-store
- Texte de l'écran, dans l'ordre :

```text
Perte d'un conjoint
Besoin d'aide
HÉLÈNE · IL Y A 1 H
Le plus dur, ce sont les dimanches. Comment les traversez-vous ?
3 réponses
12 « je pense à vous »
MARC
IL Y A 40 MIN
Je marche le long de la mer, tôt, avant que la ville se réveille.
HÉLÈNE
IL Y A 20 MIN
Merci Marc. Je vais essayer demain.
ANNE-SOPHIE
IL Y A 5 MIN
Moi, j'appelle ma sœur. Toujours à la même heure.
Répondre à Hélène
Envoyer
```

### 111 · Écrire au groupe

- Capture : `ecrans/png/111-nouveau-message.png` · Maquette : `ecrans/html/nouveau-message.html`
- Route : `/care/community/$group/new` · **à créer**
- Type : Standard
- Ce qu'on peut toucher :
  - « Perte d'un conjoint » → écran 096 · Un groupe (/care/community/$group)
  - « Besoin d'aide » → écran 018 · Besoin d'aide (/crisis)
  - « Publier » → écran 096 · Un groupe (/care/community/$group)
  - « Les règles du groupe » → écran 099 · Les règles du groupe (/care/community/regles)
  - champs de saisie : la valeur s'écrit en serif sur un filet
- Texte de l'écran, dans l'ordre :

```text
Perte d'un conjoint
Besoin d'aide
Écrire
au groupe.
Vous écrivez en tant que « V. ». Les messages sont relus par une modératrice.
UN TITRE · FACULTATIF
Les dimanches
Ce que vous voulez partager…
Publier
Les règles du groupe
```

### 099 · Les règles du groupe

- Capture : `ecrans/png/099-regles.png` · Maquette : `ecrans/html/regles.html`
- Route : `/care/community/regles` · **existe** · Remplace
- Type : Standard
- Ce qu'on peut toucher :
  - « Un groupe » → écran 096 · Un groupe (/care/community/$group)
  - « Besoin d'aide » → écran 018 · Besoin d'aide (/crisis)
- Code actuel (à réutiliser seulement pour ce qui ne change pas ; la maquette décide du reste) :
  - `src/routes/care.community.regles.tsx` · logique utilisée : community-store
- Texte de l'écran, dans l'ordre :

```text
Un groupe
Besoin d'aide
Les règles
du groupe.
1
On écoute sans juger : chaque deuil est différent.
2
On partage ce qu'on a vécu, sans conseil médical.
3
Ce qui est dit ici reste ici.
4
Si quelqu'un va très mal, on le signale : une modératrice répond vite.
```

### 100 · Une veillée

- Capture : `ecrans/png/100-veillee.png` · Maquette : `ecrans/html/veillee.html`
- Route : `/care/community/vigil/$id` · **à créer**
- Type : Standard
- Ce qu'on peut toucher :
  - « Communauté » → écran 095 · Communauté (/care/community)
  - « Besoin d'aide » → écran 018 · Besoin d'aide (/crisis)
  - « S'inscrire » → écran 112 · Veillée · inscription (/care/community/vigil/$id/ok)
- Texte de l'écran, dans l'ordre :

```text
Communauté
Besoin d'aide
Le premier mois,
en parler ensemble.
QUAND
Jeudi 1er octobre, 20 h
DURÉE
Une heure
OÙ
En visio, caméra facultative
ANIMÉE PAR
Une psychologue
Comment ça se passe —
Chacun se présente s'il le souhaite, puis un thème : ce qui a changé depuis un mois.
S'inscrire
7 PLACES RESTANTES
```

### 112 · Veillée · inscription

- Capture : `ecrans/png/112-veillee-inscrit.png` · Maquette : `ecrans/html/veillee-inscrit.html`
- Route : `/care/community/vigil/$id/ok` · **à créer**
- Type : Standard
- Ce qu'on peut toucher :
  - « Une veillée » → écran 100 · Une veillée (/care/community/vigil/$id)
  - « Besoin d'aide » → écran 018 · Besoin d'aide (/crisis)
  - « Ajouter à mon agenda » → écran 015 · Les jours qui viennent (/agenda)
  - « Me désinscrire » → action sur place (enregistrer, appeler, lire…) : brancher sur la logique existante
- Texte de l'écran, dans l'ordre :

```text
Une veillée
Besoin d'aide
Vous êtes inscrit.
Le lien de la visio vous sera envoyé jeudi matin. Vous pourrez garder la caméra éteinte.
QUAND
Jeudi 1er octobre, 20 h
DURÉE
Une heure
ANIMÉE PAR
Une psychologue
Ajouter à mon agenda
Me désinscrire
```
