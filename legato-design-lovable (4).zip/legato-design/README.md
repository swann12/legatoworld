# Legato — dossier de design pour Lovable

## Contenu

| Fichier | Rôle |
|---|---|
| `00-PROMPTS-LOVABLE.md` | Les 9 prompts à envoyer à Lovable, dans l'ordre |
| `01-SYSTEME-DE-DESIGN.md` | Toutes les règles : couleurs par espace, typographies, composants, navigation, écriture |
| `02-ECRANS.md` | Les 113 écrans : route, statut (existe / à créer), ce qu'on peut toucher et où cela mène, code actuel réutilisable, texte exact |
| `assets/` | Le logo : symbole et nom, en PNG transparent (normal et haute définition) |
| `polices/` | Les 3 polices (Instrument Serif, Instrument Sans, Space Mono), libres de droits (licence OFL) |
| `tokens.css` | Les valeurs exactes à fusionner dans `src/styles.css` |
| `ecrans/png/` | Les 113 captures, numérotées dans l'ordre de `02-ECRANS.md` |
| `apercu-1.png`, `apercu-2.png` | Vue d'ensemble des 113 écrans |
| `ecrans/html/` | Les maquettes HTML, cliquables entre elles (ouvrir `entree.html` dans un navigateur) |

## Mode d'emploi

1. **Mettre l'état actuel à l'abri.** Sur GitHub, dépôt `legatoworld` → bouton de branche « main » → taper `avant-refonte` → « Create branch ». Cette copie ne bouge plus et permet de tout récupérer.
2. **Mettre le dossier dans le dépôt.** Toujours sur `main` : « Add file » → « Upload files » → glisser le dossier `legato-design` entier → « Commit changes ». Lovable se synchronise tout seul.
3. **Dans Lovable, envoyer le prompt 0.** Il ne doit modifier aucun code et te répondre par un résumé : vérifie qu'il cite bien les couleurs par espace et les deux éléments à conserver (animation d'ouverture, jardin à parcelles).
4. **Envoyer les prompts 1 à 14 un par un**, en joignant à chaque fois les captures citées dans le titre du prompt. Après chaque étape, ouvrir l'aperçu sur mobile et comparer avec les captures.
5. **Si un écran ne correspond pas** : « L'écran 045 ne correspond pas à `ecrans/png/045-rendez-vous.png` : [ce qui diffère]. Corrige seulement cet écran. »
6. **Si une étape casse quelque chose** : revenir à la version précédente dans l'historique de Lovable, puis renvoyer le prompt en le précisant.

## Les polices

Les maquettes HTML chargent les polices depuis le dossier `polices/`. Elles s'affichent donc correctement même sans connexion, à condition de garder la structure du dossier : ouvrir `ecrans/html/entree.html` dans Chrome ou Safari. L'aperçu rapide du Finder n'affiche pas les polices.

Pour les utiliser dans tes logiciels (Figma, Keynote…), double-clique sur chaque fichier `.ttf` du dossier `polices/`, puis sur « Installer ».
