# Prompts Lovable — refonte du design de Legato

Envoie ces prompts **un par un, dans l'ordre**. Après chacun, vérifie le résultat sur mobile avant de passer au suivant.

Pour chaque prompt, joins dans le message les captures citées (dossier `legato-design/ecrans/png/`), si possible toutes. Lovable lit les fichiers texte du dépôt, mais il comprend mieux une image jointe au message.

---

## Prompt 0 — Le cadre (à envoyer en premier)

```
Tu vas refaire entièrement l'interface de Legato à partir d'une maquette validée, construite écran par écran.
Le dossier `legato-design/` à la racine du dépôt contient tout :
- `01-SYSTEME-DE-DESIGN.md` : les règles (couleurs, typographies, composants, navigation, écriture). C'est la référence absolue.
- `tokens.css` : les valeurs exactes. `polices/` : les trois polices. `assets/` : le logo.
- `02-ECRANS.md` : les 113 écrans, avec pour chacun la capture, la maquette HTML, la route et le texte exact.
- `ecrans/png/` : les captures (390 × 844). `ecrans/html/` : les maquettes HTML.

Règles de travail :
1. Pour la mise en page, la source exacte est le fichier HTML de chaque écran (`ecrans/html/`) : il contient les mesures en pixels, les couleurs et l'ordre des éléments. La capture PNG sert à vérifier le rendu. Reproduis les deux à l'identique.
1 bis. Les fonctions ont changé. Le cœur de l'application reste le même, mais la maquette définit les nouvelles fonctions : c'est elle qui fait foi, pas le code actuel. Pour chaque écran, `02-ECRANS.md` donne « Ce qu'on peut toucher » (chaque élément et ce qu'il fait ou l'écran vers lequel il mène) et « Code actuel » (la page qui existe aujourd'hui et la logique qu'elle utilise). Réutilise le code actuel seulement pour ce qui fait la même chose (données, enregistrements, appels à l'IA). Ce qui est différent dans la maquette, tu le modifies ; ce qui est nouveau, tu le crées.
1 ter. Si le code actuel contient une fonction qui n'apparaît pas dans la maquette, ne décide pas seul de la garder ou de la supprimer : demande-moi.
2. Reprends le texte exact de `02-ECRANS.md`. Les prénoms, dates et chiffres sont des exemples : affiche les vraies données de l'utilisateur.
3. Ne casse pas les fondations techniques : stores `src/lib/*-store.ts`, espaces (`spaces-store.ts`, `active-space.ts`), fonctions IA (`src/lib/*.functions.ts`), authentification Lovable, tables Supabase (`profiles`, `circles`, `circle_members`, `circle_invites`, `shared_items`, `emotional_state`).
4. Deux éléments existants sont À CONSERVER, seulement restylés autour :
   a. L'animation florale d'ouverture : `src/routes/index.tsx` + `public/intro.mp4` (vidéo, vitesse, minutage, apparition du logo puis du bouton « Entrer »). Seuls le logo final et le bouton changent (écran 001).
   b. Le jardin peint avec les parcelles : `src/routes/care.garden.index.tsx` + `src/assets/garden-painted-v4.png` (une parcelle par être aimé, positions, ajout de parcelle). Il reste la première page de l'onglet Mémoire.
   Ne supprime pas non plus `BloomFlower.tsx`, `LivingPatch.tsx`, ni les images `src/assets/garden-*` et `intro-*`.
5. Garde les routes existantes et leurs redirections ; crée seulement les routes marquées « à créer » dans `02-ECRANS.md`.
6. Ne touche pas à `src/routes/vitrine.tsx` (site ordinateur) ni à `src/routes/api/`.
7. Mobile d'abord, largeur de référence 390 px.
8. Je t'enverrai une étape à la fois. Pour cette première réponse, ne modifie aucun code : lis le dossier et résume-moi en 12 lignes ce que tu as compris (couleurs par espace, trois types d'écrans, navigation, les deux éléments à conserver).
```

---

## Prompt 1 — Les fondations

```
Étape 1 sur 13 : les fondations, sans encore refaire les pages.

1. Installe les polices en local : copie `legato-design/polices/*.ttf` dans `public/fonts/` et déclare-les avec @font-face (modèle : `legato-design/polices/polices.css`, chemins en /fonts/...). Familles : Instrument Serif (normal et italique), Instrument Sans, Space Mono. Aucune autre police.
2. Fusionne `legato-design/tokens.css` dans `src/styles.css` (variables :root, bloc @theme, classes .lg-*). Ne supprime pas les variables shadcn existantes.
3. Crée les composants du §5 de `01-SYSTEME-DE-DESIGN.md` dans `src/components/legato/ds/` : PageHeader, PageTitle, Lead, SectionLabel, Row, ArrowRow, Tip, Block, PrimaryButton, OutlineButton, TextLink, Spec, Columns, SplitHeader, Boxed, OptionCard, StepBar, QuestionFooter, Field, TextArea, MoodBar, ProgressBar, ChatBubble.
4. Chaque composant reçoit une prop `space` : "today" | "support" | "practical" | "memory" | "community" | "night", qui applique le couple de couleurs du §3. Aucune couleur en dur dans les pages.
5. Crée les gabarits StandardLayout, QuestionLayout et ExperienceLayout (§4).
6. Refais la barre de navigation (§6) : Aujourd'hui · Soutien · Démarches · Mémoire · Communauté → /home, /care, /practical, /care/garden, /care/community. Variante nuit.
7. Ajoute une route cachée /dev/design qui montre tous les composants dans les 6 variantes, pour que je vérifie.
Compare avec les captures 000, 011, 029, 055, 080 et 095.
```

---

## Prompt 2 — Entrée et première ouverture (captures 001, 002, 003, 004, 005, 006, 007, 008, 009, 010)

```
Étape 2 sur 13 : Entrée et première ouverture. Refais ces écrans en suivant leur capture et `02-ECRANS.md` :
   - 001 · Écran d'entrée → / (existe)
   - 002 · Bienvenue → /start (existe)
   - 003 · Comment ça marche → /presentation (existe)
   - 004 · Se connecter → /auth (existe)
   - 005 · Une invitation → /invite/$token (existe)
   - 006 · 1 · Pour qui → /onboarding · étape 1 (existe)
   - 007 · 2 · Son prénom → /onboarding · étape 2 (existe)
   - 008 · 3 · Démarches → /onboarding/practical (existe)
   - 009 · 4 · Vos besoins → /onboarding/care (existe)
   - 010 · C'est prêt → /onboarding · fin (existe)

- 001 · Écran d'entrée : CONSERVE l'animation d'ouverture de `src/routes/index.tsx` (vidéo `public/intro.mp4`, vitesse 0,7, apparition du logo à 6,2 s, puis bouton). Ne change ni la vidéo ni son minutage. Remplace seulement ce qui apparaît à la fin : le symbole (`legato-design/assets/logo-symbole.png`, 58 px de large) et le nom LEGATO (`legato-design/assets/logo-legato.png`, 262 px de large), placés comme sur la capture 001, et le bouton « Entrer » (pleine largeur dans les marges de 28 px, 52 px de haut, Instrument Sans 15 px, contour 1 px vert profond, fond transparent) qui mène à /start. Copie les deux images dans `src/assets/`.
- Les 4 questions et « C'est prêt » utilisent QuestionLayout : même barre d'étapes sans libellés, mêmes OptionCard (choix unique et choix multiple ont la même apparence), même QuestionFooter.
- Branche les réponses sur la logique existante (onboarding.index, onboarding.care, onboarding.practical) et sur la création de l'espace actif. « C'est prêt » mène à /home.
Avant de coder, écris pour chaque écran quatre courtes listes : 1) ce que tu réutilises du code actuel ; 2) ce que tu modifies pour suivre la maquette ; 3) ce que tu crées parce que c'est nouveau ; 4) ce qui existe dans le code actuel mais pas dans la maquette (pour cette dernière liste, attends ma réponse avant de supprimer quoi que ce soit). Ensuite, code les points 1 à 3.
Quand c'est fini, dis-moi quels fichiers tu as modifiés et si un écran n'a pas pu être fait à l'identique.
```

---

## Prompt 3 — Aujourd'hui (1/2) (captures 011, 012, 013, 014, 015, 016, 017, 018)

```
Étape 3 sur 13 : Aujourd'hui (1/2). Refais ces écrans en suivant leur capture et `02-ECRANS.md` :
   - 011 · Aujourd'hui → /home (à créer)
   - 012 · Le soir (mode nuit) → /home après 21 h (à créer)
   - 013 · Comment allez-vous → /care/emotions (et /checkin) (existe)
   - 014 · C'est noté → /care/emotions · après enregistrement (à créer)
   - 015 · Les jours qui viennent → /agenda (existe)
   - 016 · Ajouter une date → /agenda/new (à créer)
   - 017 · Une date difficile → /care/dates (existe)
   - 018 · Besoin d'aide → /crisis (existe)

- /home devient une vraie page « Aujourd'hui » au lieu de rediriger.
- Mode nuit entre 21 h et 6 h (heure locale) : /home s'affiche comme l'écran 012, sans aucune démarche.
- Humeur : garde la logique de check-in existante (checkin-store, table emotional_state).
- Besoin d'aide (/crisis) : plein écran bordeaux, sans barre de navigation.
Avant de coder, écris pour chaque écran quatre courtes listes : 1) ce que tu réutilises du code actuel ; 2) ce que tu modifies pour suivre la maquette ; 3) ce que tu crées parce que c'est nouveau ; 4) ce qui existe dans le code actuel mais pas dans la maquette (pour cette dernière liste, attends ma réponse avant de supprimer quoi que ce soit). Ensuite, code les points 1 à 3.
Quand c'est fini, dis-moi quels fichiers tu as modifiés et si un écran n'a pas pu être fait à l'identique.
```

---

## Prompt 4 — Aujourd'hui (2/2) : espaces, compte, autres types d'espace (captures 019, 020, 021, 022, 023, 024, 025, 105, 106, 026, 027, 028, 101, 102, 103, 104)

```
Étape 4 sur 13 : Aujourd'hui (2/2) : espaces, compte, autres types d'espace. Refais ces écrans en suivant leur capture et `02-ECRANS.md` :
   - 019 · Vos espaces → /space (à créer)
   - 020 · Créer un espace → /space/new (à créer)
   - 021 · Réglages de l'espace → /space/settings (à créer)
   - 022 · Votre cercle → /circle et /profile/proches (existe)
   - 023 · Mon compte → /profile (existe)
   - 024 · Notifications → /profile/notifications (à créer)
   - 025 · Qui voit quoi → /profile/privacy (à créer)
   - 105 · Aide et contact → /profile/help (à créer)
   - 106 · Vos données → /profile/data (à créer)
   - 026 · Espace Maman → /home · espace « proche malade » (à créer)
   - 027 · Espace Ulysse → /home · espace « animal » (à créer)
   - 028 · Questions sur la mort → /home · espace « questions sur la mort » (à créer)
   - 101 · Questions pour le médecin → /home/questions-medecin (à créer)
   - 102 · Ses affaires → /home/ses-affaires (à créer)
   - 103 · En parler à un enfant → /home/parler-enfant (à créer)
   - 104 · En parler avec ses proches → /home/en-parler (à créer)

- /home s'adapte au type de l'espace actif : personne disparue → 011, proche malade → 026, animal → 027, questions sur la mort → 028.
- /space/new utilise QuestionLayout. Garde spaces-store, active-space et les tables circles / circle_members / circle_invites.
Avant de coder, écris pour chaque écran quatre courtes listes : 1) ce que tu réutilises du code actuel ; 2) ce que tu modifies pour suivre la maquette ; 3) ce que tu crées parce que c'est nouveau ; 4) ce qui existe dans le code actuel mais pas dans la maquette (pour cette dernière liste, attends ma réponse avant de supprimer quoi que ce soit). Ensuite, code les points 1 à 3.
Quand c'est fini, dis-moi quels fichiers tu as modifiés et si un écran n'a pas pu être fait à l'identique.
```

---

## Prompt 5 — Soutien (1/3) (captures 029, 030, 031, 032, 033, 034, 035, 036, 037, 038)

```
Étape 5 sur 13 : Soutien (1/3). Refais ces écrans en suivant leur capture et `02-ECRANS.md` :
   - 029 · Soutien → /care (existe)
   - 030 · Se confier → /care/aide (existe)
   - 031 · Présence → /presence (existe)
   - 032 · Ce que Présence peut faire → /presence/about (à créer)
   - 033 · Respirer → /care/respirer (existe)
   - 034 · Sons pour s'endormir → /care/sons (à créer)
   - 035 · Se poser → /no-words (existe)
   - 036 · Se poser · plein écran → /no-words · lecture (existe)
   - 037 · Écrire → /care/journal (existe)
   - 038 · Mon journal → /care/journal · page d'écriture (existe)

- Couleurs Soutien : bloc lin, bouton bleu à texte vert profond, accent vert profond.
- Présence : bulles de Présence en menthe pâle, les vôtres en bleu, champ « Écrivez, ou parlez » souligné avec micro. Garde `presence.functions.ts`.
- Respirer, Sons et Se poser (lecture) : ExperienceLayout, sans barre de navigation.
Avant de coder, écris pour chaque écran quatre courtes listes : 1) ce que tu réutilises du code actuel ; 2) ce que tu modifies pour suivre la maquette ; 3) ce que tu crées parce que c'est nouveau ; 4) ce qui existe dans le code actuel mais pas dans la maquette (pour cette dernière liste, attends ma réponse avant de supprimer quoi que ce soit). Ensuite, code les points 1 à 3.
Quand c'est fini, dis-moi quels fichiers tu as modifiés et si un écran n'a pas pu être fait à l'identique.
```

---

## Prompt 6 — Soutien (2/3) (captures 039, 040, 041, 042, 043, 044, 045, 046, 047)

```
Étape 6 sur 13 : Soutien (2/3). Refais ces écrans en suivant leur capture et `02-ECRANS.md` :
   - 039 · Lettre pour plus tard → /care/journal/later (à créer)
   - 040 · Lire, écouter → /care/resources et /library/$kind (existe)
   - 041 · Une ressource → /library/$kind · détail (à créer)
   - 042 · Trouver un professionnel → /care/help (existe)
   - 043 · Fiche professionnel → /resources/$category/$providerId (existe)
   - 044 · Rendez-vous réservé → /resources/confirm/$providerId (existe)
   - 045 · Vos rendez-vous → /appointments (existe)
   - 046 · Un rendez-vous → /appointments/$id (à créer)
   - 047 · Ajouter un rendez-vous → /appointments/new (à créer)

- Rendez-vous : ajoute un champ « importance » (à maintenir / peut être reporté / peut être annulé), choisi à la création (047), et la partie « Si ce jour-là c'est trop dur » sur le détail (046).
Avant de coder, écris pour chaque écran quatre courtes listes : 1) ce que tu réutilises du code actuel ; 2) ce que tu modifies pour suivre la maquette ; 3) ce que tu crées parce que c'est nouveau ; 4) ce qui existe dans le code actuel mais pas dans la maquette (pour cette dernière liste, attends ma réponse avant de supprimer quoi que ce soit). Ensuite, code les points 1 à 3.
Quand c'est fini, dis-moi quels fichiers tu as modifiés et si un écran n'a pas pu être fait à l'identique.
```

---

## Prompt 7 — Soutien (3/3) : le corps (captures 048, 049, 050, 051, 052, 053, 054, 107)

```
Étape 7 sur 13 : Soutien (3/3) : le corps. Refais ces écrans en suivant leur capture et `02-ECRANS.md` :
   - 048 · Le corps → /help/corps (existe)
   - 049 · Dormir → /help/corps/nuits (existe)
   - 050 · Manger → /help/corps/manger (existe)
   - 051 · Se laver → /help/corps/eau (existe)
   - 052 · S'habiller → /help/corps/habiller (existe)
   - 053 · Dormir · contenus → /help/corps/nuits/contenus (à créer)
   - 054 · Exercice guidé → /help/corps/soin/$id (existe)
   - 107 · Un moment de soin → /help/corps/soin (à créer)

- Une page par sujet avec trois conseils numérotés (1, 2, 3). La page de contenus (053) suit le même modèle pour chaque sujet.
- L'exercice guidé (054) est en ExperienceLayout, sans barre de navigation. Garde self-care et CorpsPage pour la logique.
Avant de coder, écris pour chaque écran quatre courtes listes : 1) ce que tu réutilises du code actuel ; 2) ce que tu modifies pour suivre la maquette ; 3) ce que tu crées parce que c'est nouveau ; 4) ce qui existe dans le code actuel mais pas dans la maquette (pour cette dernière liste, attends ma réponse avant de supprimer quoi que ce soit). Ensuite, code les points 1 à 3.
Quand c'est fini, dis-moi quels fichiers tu as modifiés et si un écran n'a pas pu être fait à l'identique.
```

---

## Prompt 8 — Démarches (1/3) (captures 055, 056, 057, 058, 059, 060, 061, 062, 063, 064)

```
Étape 8 sur 13 : Démarches (1/3). Refais ces écrans en suivant leur capture et `02-ECRANS.md` :
   - 055 · Démarches → /practical (et /practical/tasks) (existe)
   - 056 · Une démarche → /practical/tasks/$id (et /parcours/$taskId) (existe)
   - 057 · Mon avancement → /practical/progress (à créer)
   - 058 · Les grandes étapes → /practical/steps (existe)
   - 059 · Mes documents → /practical/vault (existe)
   - 060 · Un courrier expliqué → /practical/letter (à créer)
   - 061 · Modèle de courrier → /practical/tasks/$id/template (à créer)
   - 062 · Confier à un proche → /practical/share/$taskId (à créer)
   - 063 · Envoyer vos choix → /practical/share (existe)
   - 064 · Repères → /practical/resources (existe)

- Couleurs Démarches : bloc lin, accent corail (#D9653F pour les titres et chiffres, #F4805A pour les remplissages), bouton bleu à texte vert profond. Aucun orange clair.
- Mon avancement : une seule barre arrondie + trois colonnes. Les grandes étapes : une ligne verticale avec un point par étape.
- Garde practical-store, task-steps, task-status, task-guides.
Avant de coder, écris pour chaque écran quatre courtes listes : 1) ce que tu réutilises du code actuel ; 2) ce que tu modifies pour suivre la maquette ; 3) ce que tu crées parce que c'est nouveau ; 4) ce qui existe dans le code actuel mais pas dans la maquette (pour cette dernière liste, attends ma réponse avant de supprimer quoi que ce soit). Ensuite, code les points 1 à 3.
Quand c'est fini, dis-moi quels fichiers tu as modifiés et si un écran n'a pas pu être fait à l'identique.
```

---

## Prompt 9 — Démarches (2/3) : professionnels et cérémonie (captures 065, 066, 067, 068, 069, 070, 071, 072, 073)

```
Étape 9 sur 13 : Démarches (2/3) : professionnels et cérémonie. Refais ces écrans en suivant leur capture et `02-ECRANS.md` :
   - 065 · Les professionnels → /practical/pros (existe)
   - 066 · Le notaire → /practical/pros/$kind (à créer)
   - 067 · Organiser la cérémonie → /practical/ceremony (existe)
   - 068 · Pompes funèbres → /resources/$category (existe)
   - 069 · Un prestataire → /resources/$category/$providerId (existe)
   - 070 · Les détails de la cérémonie → /practical/atmosphere (existe)
   - 071 · Choisir les fleurs → /practical/flowers (existe)
   - 072 · Fleurs · questions → /practical/flowers · questions (existe)
   - 073 · Fleurs · proposition → /practical/flowers · proposition (existe)

- Fleurs : l'utilisateur décrit ce qu'il imagine ou répond aux questions ; l'IA existante (ceremony-ai, ambiance) renvoie la proposition affichée comme sur la capture 073. Garde resources-data pour les prestataires.
Avant de coder, écris pour chaque écran quatre courtes listes : 1) ce que tu réutilises du code actuel ; 2) ce que tu modifies pour suivre la maquette ; 3) ce que tu crées parce que c'est nouveau ; 4) ce qui existe dans le code actuel mais pas dans la maquette (pour cette dernière liste, attends ma réponse avant de supprimer quoi que ce soit). Ensuite, code les points 1 à 3.
Quand c'est fini, dis-moi quels fichiers tu as modifiés et si un écran n'a pas pu être fait à l'identique.
```

---

## Prompt 10 — Démarches (3/3) (captures 074, 075, 076, 077, 078, 079)

```
Étape 10 sur 13 : Démarches (3/3). Refais ces écrans en suivant leur capture et `02-ECRANS.md` :
   - 074 · Textes et musique → /practical/texts (existe)
   - 075 · Textes · propositions → /practical/texts · propositions (existe)
   - 076 · Cercueil, urne, plaque → /practical/objects (existe)
   - 077 · Le livret → /practical/booklet (existe)
   - 078 · Volontés → /practical/wishes (et /wishes) (existe)
   - 079 · Volontés · obsèques → /practical/wishes · obsèques (existe)

- Textes et musique : même principe que les fleurs (description, puis propositions de l'IA).
- Volontés · obsèques : QuestionLayout.
Avant de coder, écris pour chaque écran quatre courtes listes : 1) ce que tu réutilises du code actuel ; 2) ce que tu modifies pour suivre la maquette ; 3) ce que tu crées parce que c'est nouveau ; 4) ce qui existe dans le code actuel mais pas dans la maquette (pour cette dernière liste, attends ma réponse avant de supprimer quoi que ce soit). Ensuite, code les points 1 à 3.
Quand c'est fini, dis-moi quels fichiers tu as modifiés et si un écran n'a pas pu être fait à l'identique.
```

---

## Prompt 11 — Mémoire (1/2) (captures 080, 081, 082, 108, 083, 084, 109, 085, 086, 087, 088, 089)

```
Étape 11 sur 13 : Mémoire (1/2). Refais ces écrans en suivant leur capture et `02-ECRANS.md` :
   - 080 · Mémoire → /care/garden/space (à créer)
   - 081 · Tous ses souvenirs → /care/garden/all (à créer)
   - 082 · Un souvenir → /care/garden/$zone/$id (à créer)
   - 108 · Ses photos → /care/garden/$zone (photos) (existe)
   - 083 · Sa voix → /care/garden/$zone (voix) (existe)
   - 084 · Lettres et mots → /care/garden/$zone (lettres) (existe)
   - 109 · Les lieux → /care/garden/$zone (lieux) (existe)
   - 085 · Ajouter un souvenir → /care/garden/depot (existe)
   - 086 · Composer un souvenir → /compose/$zone (existe)
   - 087 · Son portrait → /profile/portrait (existe)
   - 088 · Inviter des proches → /care/garden/invite (à créer)
   - 089 · Un livre souvenir → /care/garden/book (à créer)

- CONSERVE le jardin peint avec les parcelles sur /care/garden (`src/routes/care.garden.index.tsx`, image `src/assets/garden-painted-v4.png`, une parcelle par être aimé, positions des parcelles, « Ajouter une parcelle »). C'est la première page de l'onglet Mémoire. N'y change que l'en-tête, les titres, les textes et les boutons pour suivre le système (couleurs Mémoire, typographies).
- Quand on touche une parcelle : l'espace correspondant devient actif et on arrive sur l'écran 080 « Le jardin de … » (nouvelle route /care/garden/space).
- Couleurs Mémoire : bloc rose, bouton bordeaux à texte rose, accent bordeaux. Garde memories-store, portrait-store, compose-auto, LivingPatch.
Avant de coder, écris pour chaque écran quatre courtes listes : 1) ce que tu réutilises du code actuel ; 2) ce que tu modifies pour suivre la maquette ; 3) ce que tu crées parce que c'est nouveau ; 4) ce qui existe dans le code actuel mais pas dans la maquette (pour cette dernière liste, attends ma réponse avant de supprimer quoi que ce soit). Ensuite, code les points 1 à 3.
Quand c'est fini, dis-moi quels fichiers tu as modifiés et si un écran n'a pas pu être fait à l'identique.
```

---

## Prompt 12 — Mémoire (2/2) : les gestes (captures 090, 091, 092, 093, 094, 110)

```
Étape 12 sur 13 : Mémoire (2/2) : les gestes. Refais ces écrans en suivant leur capture et `02-ECRANS.md` :
   - 090 · Un geste pour elle → /care/rituels (existe)
   - 091 · Son anniversaire → /care/dates/$id (à créer)
   - 092 · Une bougie → /care/rituels/candle (à créer)
   - 093 · Une bougie · quelques mots → /care/rituels/candle · mots (à créer)
   - 094 · Une lanterne → /care/rituels/lantern (à créer)
   - 110 · Une offrande → /care/rituels/offering (à créer)

- Bougie et lanterne : ExperienceLayout en dégradé bordeaux → rose, un simple rond de lumière, sans barre de navigation. Garde rituals-catalog et rituals.functions. Garde le composant BloomFlower.
Avant de coder, écris pour chaque écran quatre courtes listes : 1) ce que tu réutilises du code actuel ; 2) ce que tu modifies pour suivre la maquette ; 3) ce que tu crées parce que c'est nouveau ; 4) ce qui existe dans le code actuel mais pas dans la maquette (pour cette dernière liste, attends ma réponse avant de supprimer quoi que ce soit). Ensuite, code les points 1 à 3.
Quand c'est fini, dis-moi quels fichiers tu as modifiés et si un écran n'a pas pu être fait à l'identique.
```

---

## Prompt 13 — Communauté (captures 095, 096, 097, 098, 099, 100, 111, 112)

```
Étape 13 sur 13 : Communauté. Refais ces écrans en suivant leur capture et `02-ECRANS.md` :
   - 095 · Communauté → /care/community (existe)
   - 096 · Un groupe → /care/community/$group (existe)
   - 097 · Une conversation → /care/community/$group/$thread (existe)
   - 098 · Trouver un groupe → /care/community/groups (à créer)
   - 099 · Les règles du groupe → /care/community/regles (existe)
   - 100 · Une veillée → /care/community/vigil/$id (à créer)
   - 111 · Écrire au groupe → /care/community/$group/new (à créer)
   - 112 · Veillée · inscription → /care/community/vigil/$id/ok (à créer)

- Mêmes couleurs que Mémoire (rose et bordeaux). La veillée est mise en avant dans un bloc bordeaux à texte rose. Garde community-store et community-data.
Avant de coder, écris pour chaque écran quatre courtes listes : 1) ce que tu réutilises du code actuel ; 2) ce que tu modifies pour suivre la maquette ; 3) ce que tu crées parce que c'est nouveau ; 4) ce qui existe dans le code actuel mais pas dans la maquette (pour cette dernière liste, attends ma réponse avant de supprimer quoi que ce soit). Ensuite, code les points 1 à 3.
Quand c'est fini, dis-moi quels fichiers tu as modifiés et si un écran n'a pas pu être fait à l'identique.
```

---

## Prompt 14 — Vérification finale

```
Dernière étape : vérifie toute l'application avec `01-SYSTEME-DE-DESIGN.md` et `02-ECRANS.md`, puis corrige :
1. Chaque route du tableau existe et ressemble à sa capture.
2. Aucune couleur d'un autre espace sur un écran (exceptions : mode nuit, Présence, Mes documents).
3. Un seul bouton plein par écran.
4. « Besoin d'aide → » sur tous les écrans standard ; absent des pages d'expérience, des questionnaires et de l'écran d'entrée.
5. Barre de navigation absente des pages d'expérience, des questionnaires, de l'entrée et de Besoin d'aide.
6. Aucun émoji, aucun pictogramme décoratif, aucune liste en « i. ii. ».
7. Aucun lien mort.
8. L'animation d'ouverture et le jardin peint avec ses parcelles fonctionnent comme avant.
Donne-moi la liste de ce que tu as corrigé.
```
