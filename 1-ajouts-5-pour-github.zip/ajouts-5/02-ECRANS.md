# Ajouts n° 5 — inventaire des écrans

Les écrans de référence de la nouvelle logique : **E001 à E012**. Ce sont des exemples ; les règles complètes sont dans `01-REGLES.md` et `donnees/regles-aujourdhui-soutien-demarches.json`.

| # | Écran | Route | Statut | Note |
|---|---|---|---|---|
| | **Première ouverture, émotions, découverte** | | | |
| E001 | Première ouverture · comment est-ce arrivé ? | `/onboarding · après « son prénom »` | à créer | Question facultative |
| E002 | Aujourd'hui · choisir ses émotions | `/home · fenêtre « Modifier »` | à créer | Plusieurs émotions possibles |
| E003 | Visiteur · reprendre ou recommencer | `/start/decouverte` | à créer | S'il reste une découverte sur le téléphone |
| | **Aujourd'hui, selon les réponses** | | | |
| E004 | Aujourd'hui · 3 jours, rien n'est commencé, besoin de tout | `/home` | modifié | Période 1 |
| E005 | Aujourd'hui · 5 semaines, une échéance dans 5 jours, fatigue | `/home` | modifié | Période 2, échéance proche |
| E006 | Aujourd'hui · 6 semaines, sans échéance, fatigue et tristesse | `/home` | modifié | Période 2, sans échéance |
| E007 | Aujourd'hui · 4 mois, presque tout est fait, mémoire, manque | `/home` | modifié | Période 3, date proche |
| E008 | Aujourd'hui · papiers confiés, colère et culpabilité | `/home` | modifié | Papiers confiés à un proche |
| | **Soutien, selon la période** | | | |
| E009 | Soutien · les premiers jours | `/care` | modifié | Période 1 |
| E010 | Soutien · après les obsèques, « parler à quelqu'un » demandé | `/care` | modifié | Période 2, « parler » coché |
| E011 | Soutien · les mois qui suivent, le point du mois en bas | `/care` | modifié | Période 3, point du mois tout à la fin |
| | **Démarches : une carte « En premier », « Je suis bloqué », Présence** | | | |
| E012 | Démarches · les premiers jours, avec « Je suis bloqué » | `/practical` | modifié | Même structure pour les quatre états |

## Première ouverture, émotions, découverte

### E001 · Première ouverture · comment est-ce arrivé ?

- Capture : `E001-question-comment.png` · Maquette : `maquettes.html`, section E001
- Route : `/onboarding · après « son prénom »` · **à créer** · Question facultative
- Texte exact :

```text
Comment est-ce
arrivé ?
Pour vous proposer la bonne aide au bon moment. Vous pouvez passer cette question.
Soudainement
un accident, un malaise, sans s'y attendre
Après une maladie
on savait que cela pouvait arriver
Je préfère ne pas répondre
Continuer
Passer cette étape
```

### E002 · Aujourd'hui · choisir ses émotions

- Capture : `E002-emotions.png` · Maquette : `maquettes.html`, section E002
- Route : `/home · fenêtre « Modifier »` · **à créer** · Plusieurs émotions possibles
- Texte exact :

```text
Aujourd'hui
Fermer ×
Comment allez-vous
aujourd'hui ?
Plusieurs choix possibles. Aucune réponse n'est fausse, et elle reste privée.
SidéréJe ne réalise pasAngoissePeurFatigueVideSeulColèreCulpabilitéTristesseManqueApaiséSoulagéAutre…
Valider
```

### E003 · Visiteur · reprendre ou recommencer

- Capture : `E003-decouverte-reprendre.png` · Maquette : `maquettes.html`, section E003
- Route : `/start/decouverte` · **à créer** · S'il reste une découverte sur le téléphone
- Texte exact :

```text
DÉCOUVERTE
Une découverte
est en cours.
Vous aviez commencé sur ce téléphone le 12 octobre. Voulez-vous reprendre, ou repartir de zéro ?
Recommencer
Reprendre là où j'en étais
```


## Aujourd'hui, selon les réponses

### E004 · Aujourd'hui · 3 jours, rien n'est commencé, besoin de tout

- Capture : `E004-aujourdhui-premiers-jours.png` · Maquette : `maquettes.html`, section E004
- Route : `/home` · **modifié** · Période 1
- Texte exact :

```text
Besoin d'aide
Bonjour Victor. Une seule chose aujourd'hui.
Vous vous sentez : sidéré, angoissé
Modifier
Aujourd'hui
Choisir les pompes funèbres
20 minutes · les obsèques ont lieu dans les 14 jours
Voir comment
Ensuite —
Demander à un proche de venir
un message prêt à envoyer
Dire à vos proches ce qui vous aiderait
repas, courses, enfants
Je suis bloqué
mot de passe, argent, papier introuvable
Une question ? Écrivez à Présence…
```

### E005 · Aujourd'hui · 5 semaines, une échéance dans 5 jours, fatigue

- Capture : `E005-aujourdhui-echeance.png` · Maquette : `maquettes.html`, section E005
- Route : `/home` · **modifié** · Période 2, échéance proche
- Texte exact :

```text
Besoin d'aide
Bonjour Victor. Une démarche a un délai.
Vous vous sentez : fatigué
Modifier
Avant le 8 octobre · dans 5 jours
Demander le capital décès
10 minutes · le formulaire est déjà rempli
Faire la demande
Ensuite —
Mieux dormir cette nuit
3 conseils, 2 minutes
Voir un psychologue
12 séances remboursées par an
Une question ? Écrivez à Présence…
```

### E006 · Aujourd'hui · 6 semaines, sans échéance, fatigue et tristesse

- Capture : `E006-aujourdhui-fatigue.png` · Maquette : `maquettes.html`, section E006
- Route : `/home` · **modifié** · Période 2, sans échéance
- Texte exact :

```text
Besoin d'aide
Bonjour Victor. On commence par vous.
Vous vous sentez : fatigué, triste
Modifier
Pour vous, aujourd'hui
Mieux dormir cette nuit
3 conseils simples · 2 minutes
Lire les conseils
Ensuite —
Écrire une lettre à Anne
10 minutes
Ce que le deuil fait au corps
fatigue, gorge serrée : c'est fréquent
Une question ? Écrivez à Présence…
```

### E007 · Aujourd'hui · 4 mois, presque tout est fait, mémoire, manque

- Capture : `E007-aujourdhui-quatre-mois.png` · Maquette : `maquettes.html`, section E007
- Route : `/home` · **modifié** · Période 3, date proche
- Texte exact :

```text
Besoin d'aide
Bonjour Victor. Son anniversaire approche.
Vous vous sentez : elle me manque
Modifier
Dans 9 jours, le 3 octobre
Préparer un geste pour elle
seul ou avec vos proches · 3 idées
Voir les idées
Ensuite —
Ajouter un souvenir d'elle
une photo, sa voix, une phrase
La succession
dernière démarche · avant le 8 mars
Une question ? Écrivez à Présence…
```

### E008 · Aujourd'hui · papiers confiés, colère et culpabilité

- Capture : `E008-aujourdhui-papiers-confies.png` · Maquette : `maquettes.html`, section E008
- Route : `/home` · **modifié** · Papiers confiés à un proche
- Texte exact :

```text
Besoin d'aide
Bonjour Victor. Claire s'occupe des papiers.
Vous vous sentez : en colère, coupable
Modifier
Pour vous, aujourd'hui
Écrire ce qui pèse
10 minutes · personne ne le lira
Commencer
Ensuite —
Claire attend votre signature
le mandat pour la banque · 2 minutes
Dire à vos proches ce qui vous aiderait
repas, courses, enfants
Une question ? Écrivez à Présence…
```


## Soutien, selon la période

### E009 · Soutien · les premiers jours

- Capture : `E009-soutien-premiers-jours.png` · Maquette : `maquettes.html`, section E009
- Route : `/care` · **modifié** · Période 1
- Texte exact :

```text
Soutien
Besoin d'aide
Ce qui peut vous aider.
Utile maintenant
Dire à vos proches ce qui vous aiderait
Ils veulent aider : vous choisissez quoi.
Faire ma liste
Être entouré
Voir un psychologue
12 séances remboursées par an
Un groupe de parole
avec d'autres personnes en deuil
Tenir ces premiers jours
Dormir, manger
l'essentiel en 2 minutes
Ce que le deuil fait au corps
c'est fréquent
Une question ? Écrivez à Présence…
```

### E010 · Soutien · après les obsèques, « parler à quelqu'un » demandé

- Capture : `E010-soutien-apres-obseques.png` · Maquette : `maquettes.html`, section E010
- Route : `/care` · **modifié** · Période 2, « parler » coché
- Texte exact :

```text
Soutien
Besoin d'aide
Ce qui peut vous aider.
Utile maintenant
Voir un psychologue
Vous avez demandé à parler · 12 séances remboursées.
Trouver un psychologue
Être entouré
Dire à vos proches ce qui vous aiderait
ils choisissent quoi faire
Un groupe de parole
avec d'autres personnes en deuil
Comprendre ce que vous vivez
Ce que le deuil fait au corps
fatigue, gorge serrée
Quand consulter un médecin
les signes d'alerte
Une question ? Écrivez à Présence…
```

### E011 · Soutien · les mois qui suivent, le point du mois en bas

- Capture : `E011-soutien-mois-suivants.png` · Maquette : `maquettes.html`, section E011
- Route : `/care` · **modifié** · Période 3, point du mois tout à la fin
- Texte exact :

```text
Soutien
Besoin d'aide
Ce qui peut vous aider.
Utile maintenant
Un groupe de parole
Près de chez vous ou en visio.
Voir les groupes
Être entouré
Voir un psychologue
12 séances remboursées par an
Avancer
Reprendre le travail
messages prêts, reprise progressive
Une question ? Écrivez à Présence…
Faire le point sur ce mois
Trois questions, si vous le souhaitez.
Commencer
```


## Démarches : une carte « En premier », « Je suis bloqué », Présence

### E012 · Démarches · les premiers jours, avec « Je suis bloqué »

- Capture : `E012-demarches-premiers-jours.png` · Maquette : `maquettes.html`, section E012
- Route : `/practical` · **modifié** · Même structure pour les quatre états
- Texte exact :

```text
Démarches
Besoin d'aide
Les premiers jours, dans l'ordre.
En premier
Choisir les pompes funèbres
20 minutes · elles déclarent aussi le décès
Voir comment
Ensuite —
2
Organiser la cérémonie
le lieu, la date
3
Prévenir les proches
un seul message
Je suis bloqué
mot de passe, argent bloqué, papier introuvable : la solution pas à pas
Une question ? Écrivez à Présence…
```
