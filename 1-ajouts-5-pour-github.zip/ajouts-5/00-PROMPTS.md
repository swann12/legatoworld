# Prompts Lovable — ajouts n° 5

À envoyer **après** ceux de `ajouts-4`, un par un, dans l'ordre. Joins les images citées dans le titre de chaque message (dossier `ajouts-5-images` sur ton ordinateur).

---

## Message E0 — Le cadre

```
Le dossier `legato-design/ajouts-5/` change la façon dont Aujourd'hui, Soutien et Démarches choisissent ce qu'ils montrent. C'est la partie la plus importante de l'application.
Lis `01-REGLES.md` en entier, puis `donnees/regles-aujourdhui-soutien-demarches.json` (la seule source de vérité dans le code) et `donnees/scenarios-test.json` (14 situations avec le résultat attendu). Ouvre `simulateur-reference.html` : c'est une version qui fonctionne de cette logique ; ses fonctions phaseOf, aujourdhui, soutien et demarches sont la référence.
Ne modifie aucun code pour cette première réponse : résume-moi en 10 lignes la logique (périodes, ordre des règles, émotions, une seule carte par écran, Présence en fin de page).
```

---

## Message E1 — Trois corrections techniques

```
Applique `01-REGLES.md` §1 :
1. Polices : charge Instrument Serif et Instrument Sans depuis `legato-design/polices/`, précharge Instrument Serif (normal et italique) dans le <head>, et n'affiche la page Bienvenue qu'après `document.fonts.ready`, pendant l'animation florale. Aucun texte ne doit s'afficher dans une autre police puis changer.
2. La barre de navigation est toujours vert profond #2C4B40, dans tous les espaces. Corrige l'endroit où elle devient rose.
3. Le mode découverte repart de zéro : aucune réponse ne doit être pré-sélectionnée. S'il reste une découverte sur le téléphone, affiche l'écran E003 (Recommencer / Reprendre).
Dis-moi précisément ce que tu as changé pour chacun des trois points.
```

---

## Message E2 — Le moteur de décision (captures regles-aujourdhui.png, regles-soutien-demarches.png, regles-emotions.png)

```
Crée le moteur qui décide ce qu'affichent Aujourd'hui, Soutien et Démarches, à partir de `donnees/regles-aujourdhui-soutien-demarches.json` : un seul module (par exemple src/lib/moteur-legato.ts) qui reçoit les réponses de la personne, ses émotions du jour et les signaux du moment, et renvoie : la période ; le titre du jour ; la carte d'Aujourd'hui ; les lignes « Ensuite » ; la carte du haut de Soutien et ses rubriques ; la carte « En premier » de Démarches.
Reproduis exactement la logique de `simulateur-reference.html`. Écris un test automatique pour chacune des 14 situations de `donnees/scenarios-test.json` : les 14 doivent passer.
Ne touche pas encore aux écrans.
```

---

## Message E3 — Première ouverture, émotions, découverte (captures E001 à E003)

```
1. Ajoute la question facultative « Comment est-ce arrivé ? » (E001) juste après celle du prénom, dans la première ouverture d'un espace « personne décédée ». La réponse est enregistrée avec l'espace.
2. Remplace le choix d'humeur par le choix de plusieurs émotions (E002) : les 14 choix de `01-REGLES.md` §5, plusieurs possibles, enregistrés chaque jour. Sur Aujourd'hui, la ligne devient « Vous vous sentez : … · Modifier », avec les adjectifs du fichier de données.
3. L'écran E003 pour le mode découverte.
```

---

## Message E4 — Aujourd'hui (captures E004 à E008)

```
Refais Aujourd'hui avec la structure de `01-REGLES.md` §4, alimentée par le moteur : titre du jour, ligne des émotions, une seule carte bleue (étiquette, titre, une ligne, un bouton : rien de plus), « Ensuite » (deux lignes au plus), la ligne « Je suis bloqué » en période 1, le champ Présence en fin de page.
Les écrans E004 à E008 sont cinq résultats du moteur : vérifie que tu obtiens exactement les mêmes avec les mêmes réponses.
Supprime de Aujourd'hui « Inviter un proche » seul, et tout ce qui n'est pas dans cette structure (dis-moi ce que tu retires).
```

---

## Message E5 — Soutien (captures E009 à E011)

```
Refais l'accueil de Soutien selon `01-REGLES.md` §6 : toujours une carte « Utile maintenant » en haut (une seule), les rubriques de la période avec de l'air entre elles, le champ Présence, puis tout à la fin « Faire le point sur ce mois » à partir du 2e mois. Respirer n'est jamais mis en avant.
```

---

## Message E6 — Démarches et Présence partout (capture E012)

```
1. Démarches, pour les quatre réponses « papiers » : une seule carte lin « En premier », la liste numérotée, la ligne « Je suis bloqué » sous la liste, le champ Présence (`01-REGLES.md` §7).
2. Ajoute le champ « Une question ? Écrivez à Présence… » à la fin de chaque écran principal (Aujourd'hui, Soutien, Démarches, Mémoire, Communauté). Supprime tout bouton flottant vers Présence.
3. Vérifie sur chaque écran : une seule carte mise en avant, un seul encart beige au plus (§9).
```

---

## Message E7 — Vérification

```
1. Les 14 tests de `donnees/scenarios-test.json` passent.
2. Pour les situations 1, 3, 5, 7, 8 et 10, montre-moi une capture de Aujourd'hui, Soutien et Démarches, à comparer avec `simulateur-reference.html` réglé sur les mêmes réponses.
3. La page Bienvenue s'affiche directement dans la bonne police ; le menu est vert profond partout ; une nouvelle découverte ne garde aucune réponse.
4. Aucun écran n'a deux cartes mises en avant ; Respirer n'apparaît jamais en carte ; « Faire le point sur ce mois » est toujours tout à la fin de Soutien, après Présence.
Donne-moi la liste de ce que tu as corrigé.
```
