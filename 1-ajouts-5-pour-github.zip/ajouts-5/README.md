# Legato — ajouts n° 5 pour Lovable

La logique qui décide ce que voit la personne, selon ses réponses : Aujourd'hui, Soutien, Démarches. Plus trois corrections techniques (police du titre, menu toujours vert, découverte qui repart de zéro).

**À envoyer après `ajouts-4`.** Si `ajouts-4` n'est pas encore envoyé, envoie-le d'abord.

| Fichier | Rôle |
|---|---|
| `00-PROMPTS.md` | Les 8 messages à envoyer (E0 à E7) |
| `01-REGLES.md` | Toute la logique, en mots |
| `02-ECRANS.md` | Les 12 écrans de référence, E001 à E012 |
| `donnees/regles-aujourdhui-soutien-demarches.json` | La logique en données : la seule source de vérité dans le code |
| `donnees/scenarios-test.json` | 14 situations et le résultat attendu |
| `simulateur-reference.html` | La logique qui fonctionne : à ouvrir dans un navigateur |
| `regles-*.png` | Les trois planches de règles |
| `maquettes.html` | Les maquettes HTML des 12 écrans |
| `assets/` | Le logo |

Les captures sont dans le dossier à part `ajouts-5-images`.
