# Ajouts n° 5 — ce que voit la personne, selon ses réponses

Ce dossier remplace la façon dont Aujourd'hui, Soutien et Démarches choisissent quoi montrer. **C'est la partie la plus importante de l'application** : une personne en deuil doit arriver directement sur ce qui l'aide, au bon moment, sans page inutile.

Trois sources disent la même chose, de trois façons :
- ce fichier, en mots ;
- `donnees/regles-aujourdhui-soutien-demarches.json`, en données : **c'est la seule source de vérité dans le code** ;
- `simulateur-reference.html` : une version qui fonctionne. Ouvre-le dans un navigateur, change les réponses, regarde le résultat. Sa logique (fonctions `phaseOf`, `aujourdhui`, `soutien`, `demarches`) est la référence à reproduire.

## 1. Trois corrections techniques, à faire en premier
1. **La police du titre « Préparer un adieu… » arrive en retard.** Charge les polices depuis les fichiers du projet (`legato-design/polices/`), pas depuis Google. Précharge Instrument Serif (normal et italique) dans le `<head>` avec `<link rel="preload" as="font" type="font/woff2" crossorigin>`. Pendant l'animation florale d'ouverture, attends `document.fonts.ready` : la page Bienvenue ne s'affiche qu'une fois la police prête. Aucun texte ne doit apparaître dans une autre police puis changer.
2. **La barre de navigation est toujours vert profond `#2C4B40`**, dans tous les espaces. Les règles de couleur d'un espace (par exemple « tout en rose » pour « je pense à la mort ») ne s'appliquent jamais au menu.
3. **Le mode découverte repart de zéro.** Les réponses d'une découverte ne doivent jamais apparaître déjà sélectionnées. S'il reste une découverte sur le téléphone, affiche E003 : « Recommencer » (efface tout) ou « Reprendre là où j'en étais ».

## 2. Ce que Legato sait de la personne
- Les réponses de la première ouverture : pour qui ; son prénom, votre lien, **la date du décès** (facultative) ; **où en êtes-vous avec les papiers** ; **de quoi avez-vous besoin** (plusieurs choix).
- **Nouvelle question facultative, après le prénom (E001) : « Comment est-ce arrivé ? »** Soudainement · Après une maladie · Je préfère ne pas répondre.
- **Les émotions du jour, plusieurs possibles (E002)**, enregistrées chaque jour.
- Les signaux du moment : une échéance proche, une date difficile, la reprise du travail, la fatigue plusieurs jours de suite, l'heure (après 21 h), un signal de danger venu de Présence.

## 3. Trois périodes
| Période | Quand |
|---|---|
| 1 · Les premiers jours | « Rien n'est commencé », ou décès il y a moins de 15 jours |
| 2 · Après les obsèques | « Les obsèques sont passées », ou décès il y a 15 jours à 3 mois |
| 3 · Les mois qui suivent | « Presque tout est fait », ou décès il y a plus de 3 mois |
Si « rien n'est commencé » mais le décès date de plus de 15 jours : demande d'abord « Les obsèques ont-elles eu lieu ? ». Le lendemain de la date de la cérémonie, pose la même question pour passer en période 2.

## 4. Aujourd'hui (E004 à E008)
**Structure fixe, dans cet ordre :** le titre du jour (une phrase) · la ligne « Vous vous sentez : … · Modifier » · **une seule carte bleue** · « Ensuite » (deux lignes au plus) · en période 1, la ligne « Je suis bloqué » · le champ « Une question ? Écrivez à Présence… ».

**La carte : la première règle vraie.**
1. Signal de danger → « Appeler le 3114 » (carte bordeaux).
2. Après 21 h → « Un son pour s'endormir » (mode nuit).
3. Période 1 et « rien n'est commencé » → « Choisir les pompes funèbres », puis la cérémonie, puis prévenir les proches. **Avant les émotions** : le délai est obligatoire.
4. Une échéance dans moins de 7 jours (sauf papiers confiés) → cette échéance.
5. Une date difficile dans les 10 jours → « Préparer un geste pour elle ».
6. Période 2 et « faire les démarches » (sauf papiers confiés) → la démarche suivante.
7. Une émotion choisie → la proposition de la famille la plus urgente (§5).
8. Sinon → selon la période et les besoins (voir le fichier de données).

**Anatomie d'une carte, et rien de plus :** une étiquette en italique (« Aujourd'hui », « Avant le 8 octobre · dans 5 jours », « Pour vous, aujourd'hui ») · un titre (une action précise, moins de 40 caractères) · **une seule ligne** (durée · pourquoi maintenant, moins de 55 caractères) · **un bouton** qui fait exactement l'action. Les papiers à prévoir et les explications sont sur la page qui s'ouvre, pas dans la carte.

**« Ensuite » :** la première émotion non utilisée par la carte, puis les lignes de la période, puis les autres émotions, puis une ligne par défaut. Jamais de doublon. Deux lignes au plus. Le détail est dans le fichier de données.

## 5. Les émotions (voir `regles-emotions.png`)
14 choix, **plusieurs possibles** : Sidéré, Je ne réalise pas, Angoisse, Peur, Fatigue, Vide, Seul, Colère, Culpabilité, Tristesse, Manque, Apaisé, Soulagé, Autre. Rangées en 7 familles, de la plus urgente à la plus calme : Angoisse · Choc · Épuisement · Solitude · Colère et culpabilité · Peine · Apaisement. La famille la plus urgente donne la carte (si aucune règle pratique ne passe avant) ; la suivante donne la première ligne « Ensuite ». **En période 1, « Choc » passe avant « Angoisse »** : ne pas rester seul vient d'abord. Affichage dans la ligne du jour : des adjectifs (« sidéré, angoissé »). **Respirer n'est jamais mis en avant** : il reste dans « Prendre soin de vous ». Il n'y a pas de bouton pour les idées de mort : Présence les détecte (signal de danger).

## 6. Soutien (E009 à E011)
- **En haut, toujours une carte « Utile maintenant », une seule** : danger → 3114 ; fatigue 3 jours de suite → « Mieux dormir cette nuit » ; reprise du travail → « Préparer votre retour lundi » ; 3 premières semaines → « Dire à vos proches ce qui vous aiderait » ; besoin « parler » → « Voir un psychologue » ; sinon → « Un groupe de parole ».
- **Puis les rubriques de la période**, avec un espace de 24 px au moins entre elles et deux lignes au plus : période 1 « Être entouré », « Tenir ces premiers jours » ; période 2 « Être entouré », « Comprendre ce que vous vivez » ; période 3 « Être entouré », « Avancer ». Jamais la même ligne que la carte du haut.
- **Puis le champ Présence.**
- **Tout à la fin, après Présence** : « Faire le point sur ce mois » (titre centré en italique, « Trois questions, si vous le souhaitez. », bouton au trait « Commencer »), seulement à partir du 2e mois. Il ne revient chaque mois que si la personne l'a activé, et n'apparaît jamais sur Aujourd'hui de lui-même.

## 7. Démarches (E012)
Même structure pour les quatre réponses « papiers » : le titre · **une seule carte lin « En premier »** avec son bouton · la liste numérotée de la suite · la ligne « Je suis bloqué » (pictogramme ? menthe sur cercle vert profond, « mot de passe, argent bloqué, papier introuvable : la solution pas à pas ») · le champ Présence. « En premier » : pompes funèbres (rien commencé) ; acte de décès (obsèques passées) ; déclaration de succession (presque fini) ; la demande du proche (papiers confiés).

## 8. Présence, toujours accessible
**Chaque écran se termine par le champ « Une question ? Écrivez à Présence… »** (bord fin, coins arrondis, texte en Instrument Serif italique, petite flèche dans un rond bleu). Le toucher ouvre la conversation. **Aucun bouton flottant.**

## 9. Règles de mise en page
- **Une seule carte mise en avant par écran**, et **un seul encart beige** au plus.
- Pas de texte long dans les cartes ; les sous-titres de lignes tiennent sur une ligne.
- Les pictogrammes du menu (soleil, cœur, liste, fleur, personnes) ne changent pas.

## 10. Ce que ce dossier remplace dans `ajouts-4`
| ajouts-4 | Remplacé par |
|---|---|
| D050 Soutien (accueil, avec « Pour vous, en ce moment ») | E009 à E011 et §6 |
| D071 et D075 (cartes « Je suis bloqué » et « échéance » sur Aujourd'hui) | §4 : elles deviennent la carte ou une ligne selon les règles |
| `donnees/moments.json` (ordre des cartes) | `donnees/regles-aujourdhui-soutien-demarches.json` |
| Le point du mois en haut de Soutien | §6 : tout à la fin, après Présence |
| L'encadré « Je suis bloqué » en haut de Démarches | §7 : une ligne sous la liste |
